const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_devotee_108";
const BOB_UID = "bob_devotee_108";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write user profile, tasks, sadhana logs, or temples", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const past = new Date(Date.now() - 1000);
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("tasks").get());
  await assertFails(unauthDb.collection("temples").get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Unauth",
      routineMode: "CONGREGATIONAL",
      wakeTime: "05:00",
      sleepTime: "22:00",
      japaTargetRounds: 16,
      createdAt: past,
      updatedAt: past,
    })
  );
});

test("User profile: owner create, partial update, cross-user denial, and shadow field rejection", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Radha Das",
      email: "radha@example.com",
      routineMode: "TEMPLE_RESIDENT",
      wakeTime: "04:00",
      sleepTime: "22:00",
      japaTargetRounds: 16,
      readingTargetMinutes: 30,
      hearingTargetMinutes: 30,
      attendOnlineMangalAarti: true,
      gayatriInitiated: true,
      gayatriMorningTime: "06:00",
      gayatriAfternoonTime: "12:15",
      gayatriEveningTime: "18:15",
      responsibilities: ["Mangal Aarti Seva", "Deity Kitchen"],
      distractingPackages: ["com.instagram.android"],
      focusStrictness: "BALANCED",
      calendarTradition: "ISKCON_MAYAPUR",
      locationName: "Mayapur, India",
      latitude: 23.423,
      longitude: 88.388,
      timezoneId: "Asia/Kolkata",
      followedTempleId: "mayapur_chandrodaya",
      activeFestivalMode: "",
      themeStyle: "IVORY_MAROON",
      darkModePreference: "SYSTEM",
      fontScaleLevel: "NORMAL",
      bedtimeModeEnabled: true,
      onboardingCompleted: true,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Partial update allowed
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      japaTargetRounds: 20,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Cross-user read/write blocked (PII isolation)
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({
      japaTargetRounds: 1,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Ghost field & future timestamp rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      japaTargetRounds: 24,
      updatedAt: new Date(Date.now() + 120000),
    })
  );
});

test("User subcollections: schedule_items, tasks, sadhana_logs, focus_logs owner CRUD & isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 10000);

  // Schedule item
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("schedule_items").doc("sched_1").set({
      userId: ALICE_UID,
      title: "Mangal Aarti",
      description: "Morning temple prayers",
      startTime: "04:30",
      endTime: "05:00",
      category: "SPIRITUAL",
      routineMode: "TEMPLE_RESIDENT",
      essential: true,
      reminderEnabled: true,
      completedToday: false,
      lastCompletedDate: "",
      sortOrder: 1,
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("schedule_items").get()
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("schedule_items").get()
  );

  // Reject redundant @DocumentId `id` field inside map
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("tasks").doc("task_bad").set({
      id: "task_bad",
      userId: ALICE_UID,
      title: "Bad Task",
      dateIso: "2026-11-18",
      repeatFrequency: "ONCE",
      reminderEnabled: true,
      priority: "HIGH",
      completed: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Valid Task
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("tasks").doc("task_1").set({
      userId: ALICE_UID,
      title: "Prepare Ekadashi Prasadam",
      description: "Simple fruits and sabudana",
      dateIso: "2026-11-18",
      startTime: "09:30",
      endTime: "10:30",
      repeatFrequency: "EKADASHI",
      reminderEnabled: true,
      priority: "HIGH",
      completed: false,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Valid Sadhana Log
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("sadhana_logs").doc("2026-11-18").set({
      userId: ALICE_UID,
      dateIso: "2026-11-18",
      roundsChanted: 16,
      targetRounds: 16,
      readingMinutes: 35,
      hearingMinutes: 45,
      mangalAartiAttended: true,
      gayatriMorningDone: true,
      gayatriAfternoonDone: false,
      gayatriEveningDone: false,
      sevaMinutes: 60,
      sevaNotes: "Tulsi care",
      wakeUpStatus: "ON_TIME",
      wakeUpActualTime: "03:58",
      wakeUpMethod: "MANTRA_CHECKIN",
      wakeUpReflection: "Slept by 10 PM cleanly.",
      focusMinutes: 120,
      distractionsBlocked: 3,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Valid Focus Log (immutable after create)
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("focus_logs").doc("focus_1").set({
      userId: ALICE_UID,
      packageName: "com.instagram.android",
      appName: "Instagram",
      scheduledActivity: "Japa Meditation",
      userReason: "Checked message",
      outcome: "RETURNED",
      durationMinutes: 0,
      dateIso: "2026-11-18",
      createdAt: created,
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("focus_logs").doc("focus_1").update({
      outcome: "TEMP_EXCEPTION",
    })
  );
});

test("Temple Community: admin creates temple & posts; devotees can read & volunteer on SEVA", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection("temples").doc("mayapur_dhama").set({
      name: "ISKCON Sri Mayapur Chandrodaya Mandir",
      city: "Mayapur, West Bengal",
      tradition: "ISKCON Mayapur",
      adminUid: ALICE_UID,
      adminName: "Gauranga Das",
      mangalAartiTime: "04:30",
      tulasiAartiTime: "05:00",
      darshanTime: "07:15",
      bhagavatamClassTime: "08:00",
      sandhyaAartiTime: "18:30",
      description: "World Headquarters of ISKCON.",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Non-admin Bob cannot update temple timings
  await assertFails(
    bobDb.collection("temples").doc("mayapur_dhama").update({
      mangalAartiTime: "05:00",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Admin Alice creates a SEVA post
  await assertSucceeds(
    aliceDb.collection("temples").doc("mayapur_dhama").collection("posts").doc("seva_1").set({
      templeId: "mayapur_dhama",
      authorUid: ALICE_UID,
      authorName: "Gauranga Das",
      postType: "SEVA",
      title: "Ekadashi Garland Making",
      body: "Join morning flower garland seva after Bhagavatam class.",
      eventDate: "2026-11-20",
      eventTime: "09:15",
      sevaSlotsTotal: 12,
      volunteerUids: [],
      createdAt: created,
      updatedAt: created,
    })
  );

  // Bob can volunteer himself for SEVA post
  await assertSucceeds(
    bobDb.collection("temples").doc("mayapur_dhama").collection("posts").doc("seva_1").update({
      volunteerUids: [BOB_UID],
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Bob cannot edit post title or impersonate another user in volunteerUids
  await assertFails(
    bobDb.collection("temples").doc("mayapur_dhama").collection("posts").doc("seva_1").update({
      title: "Hijacked",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(
    bobDb.collection("temples").doc("mayapur_dhama").collection("posts").doc("seva_1").update({
      volunteerUids: [BOB_UID, "fake_uid"],
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});
