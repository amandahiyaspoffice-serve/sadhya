package com.example.calendar

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.location.LocationManager
import com.example.data.model.CalendarTradition
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

data class SacredCityPreset(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val timezoneId: String
)

data class VaishnavaFestival(
    val title: String,
    val category: String, // EKADASHI, APPEARANCE, DISAPPEARANCE, MAJOR_FESTIVAL, VRATA
    val fastingNote: String,
    val description: String,
    val isEkadashi: Boolean = false
)

data class VaishnavaDayInfo(
    val date: LocalDate,
    val masaName: String,
    val paksha: String, // Shukla or Krishna
    val tithiNumber: Int, // 1..15
    val tithiName: String,
    val sunriseTime: String,
    val sunsetTime: String,
    val isEkadashiFast: Boolean,
    val ekadashiName: String?,
    val isParanaDay: Boolean,
    val paranaWindow: String?, // e.g. "06:14 – 09:48"
    val festivals: List<VaishnavaFestival>,
    val isKartikMonth: Boolean,
    val chaturmasyaPhase: String?
)

object VaishnavaCalendarEngine {

    val cityPresets = listOf(
        SacredCityPreset("Sri Mayapur, India", 23.4231, 88.3880, "Asia/Kolkata"),
        SacredCityPreset("Sri Vrindavan, India", 27.5800, 77.7000, "Asia/Kolkata"),
        SacredCityPreset("Mumbai, India", 19.0760, 72.8777, "Asia/Kolkata"),
        SacredCityPreset("New Delhi, India", 28.6139, 77.2090, "Asia/Kolkata"),
        SacredCityPreset("London, UK", 51.5074, -0.1278, "Europe/London"),
        SacredCityPreset("New York, USA", 40.7128, -74.0060, "America/New_York"),
        SacredCityPreset("Los Angeles, USA", 34.0522, -118.2437, "America/Los_Angeles"),
        SacredCityPreset("Sydney, Australia", -33.8688, 151.2093, "Australia/Sydney"),
        SacredCityPreset("Tokyo, Japan", 35.6762, 139.6503, "Asia/Tokyo")
    )

    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm", Locale.US)

    private val tithiNames = listOf(
        "Pratipada", "Dvitiya", "Tritiya", "Chaturthi", "Panchami",
        "Shashthi", "Saptami", "Ashtami", "Navami", "Dashami",
        "Ekadashi", "Dvadashi", "Trayodashi", "Chaturdashi", "Purnima/Amavasya"
    )

    private val vaishnavaMasas = listOf(
        "Vishnu",       // 0: Chaitra
        "Madhusudana",  // 1: Vaishakha
        "Trivikrama",   // 2: Jyeshtha
        "Vamana",       // 3: Ashadha
        "Sridhara",     // 4: Shravana
        "Hrishikesha",  // 5: Bhadrapada
        "Padmanabha",   // 6: Ashvina
        "Damodara",     // 7: Kartika
        "Keshava",      // 8: Margashirsha
        "Narayana",     // 9: Pausha
        "Madhava",      // 10: Magha
        "Govinda"       // 11: Phalguna
    )

    fun computeMonth(
        year: Int,
        month: Int,
        latitude: Double,
        longitude: Double,
        timezoneId: String,
        tradition: CalendarTradition
    ): List<VaishnavaDayInfo> {
        val zone = runCatching { ZoneId.of(timezoneId) }.getOrElse { ZoneId.systemDefault() }
        val firstDay = LocalDate.of(year, month, 1)
        val daysInMonth = firstDay.lengthOfMonth()
        val result = mutableListOf<VaishnavaDayInfo>()
        for (d in 1..daysInMonth) {
            val date = LocalDate.of(year, month, d)
            result.add(computeDay(date, latitude, longitude, zone, tradition))
        }
        return result
    }

    fun computeDay(
        date: LocalDate,
        latitude: Double,
        longitude: Double,
        zone: ZoneId,
        tradition: CalendarTradition
    ): VaishnavaDayInfo {
        val (sunrise, sunset) = computeSunriseSunset(date, latitude, longitude, zone)
        val arunodaya = sunrise.minusMinutes(96)
        val arunodayaOffset = when (tradition) {
            CalendarTradition.ISKCON_MAYAPUR -> arunodaya
            CalendarTradition.GAUDIYA_MATH -> arunodaya
            CalendarTradition.VRINDAVAN -> sunrise.minusMinutes(72)
        }

        val tithiAtSunrise = tithiIndexAt(sunrise)
        val tithiAtArunodaya = tithiIndexAt(arunodayaOffset)

        val paksha = if (tithiAtSunrise < 15) "Shukla" else "Krishna"
        val tithiInPaksha = (tithiAtSunrise % 15) + 1
        val tithiLabel = when {
            tithiAtSunrise == 14 -> "Purnima"
            tithiAtSunrise == 29 -> "Amavasya"
            else -> tithiNames[(tithiInPaksha - 1).coerceIn(0, 14)]
        }

        val masaIdx = computeVaishnavaMasaIndex(sunrise)
        val masaName = vaishnavaMasas[masaIdx]

        // Shuddha Ekadashi Check: today vs yesterday vs tomorrow
        val yesterday = date.minusDays(1)
        val tomorrow = date.plusDays(1)
        val isTodayEkadashi = isEkadashiFastDay(date, latitude, longitude, zone, tradition)
        val wasYesterdayEkadashi = isEkadashiFastDay(yesterday, latitude, longitude, zone, tradition)

        val ekadashiTitle = if (isTodayEkadashi) {
            getEkadashiName(masaName, paksha)
        } else null

        val isParanaDay = wasYesterdayEkadashi && !isTodayEkadashi
        val paranaWindow = if (isParanaDay) {
            computeParanaWindow(date, sunrise, sunset)
        } else null

        val festivals = mutableListOf<VaishnavaFestival>()
        if (isTodayEkadashi && ekadashiTitle != null) {
            festivals.add(
                VaishnavaFestival(
                    title = ekadashiTitle,
                    category = "EKADASHI",
                    fastingNote = "Abstain from grains, beans & legumes; increase Hari-nama japa.",
                    description = "Observed on $masaName $paksha Ekadashi ($tithiLabel).",
                    isEkadashi = true
                )
            )
        }

        // Major verified Vaishnava festivals by (Masa, Paksha, Tithi)
        festivals.addAll(lookupFestivalsForTithi(masaName, paksha, tithiInPaksha, tithiAtSunrise))

        // Check if yesterday's festival fell only during night/skipped sunrise? Handled by sunrise tithi standard
        val isKartik = masaName == "Damodara"
        val chaturmasya = when (masaName) {
            "Sridhara" -> "Chaturmasya Month 1 (Shravana — No spinach/leafy greens)"
            "Hrishikesha" -> "Chaturmasya Month 2 (Bhadrapada — No yogurt)"
            "Padmanabha" -> "Chaturmasya Month 3 (Ashvina — No milk)"
            "Damodara" -> "Chaturmasya Month 4 / Kartik Vrata (Damodara — Offer ghee lamp)"
            else -> null
        }

        return VaishnavaDayInfo(
            date = date,
            masaName = masaName,
            paksha = paksha,
            tithiNumber = tithiInPaksha,
            tithiName = tithiLabel,
            sunriseTime = sunrise.toLocalTime().format(timeFormatter),
            sunsetTime = sunset.toLocalTime().format(timeFormatter),
            isEkadashiFast = isTodayEkadashi,
            ekadashiName = ekadashiTitle,
            isParanaDay = isParanaDay,
            paranaWindow = paranaWindow,
            festivals = festivals,
            isKartikMonth = isKartik,
            chaturmasyaPhase = chaturmasya
        )
    }

    private fun isEkadashiFastDay(
        date: LocalDate,
        latitude: Double,
        longitude: Double,
        zone: ZoneId,
        tradition: CalendarTradition
    ): Boolean {
        val (sunrise, _) = computeSunriseSunset(date, latitude, longitude, zone)
        val arunodaya = sunrise.minusMinutes(if (tradition == CalendarTradition.VRINDAVAN) 72L else 96L)
        val tSunrise = tithiIndexAt(sunrise)
        val tArun = tithiIndexAt(arunodaya)
        val isEkadashiAtSunrise = (tSunrise == 10 || tSunrise == 25)
        val isEkadashiAtArunodaya = (tArun == 10 || tArun == 25)
        val isDvadashiAtSunrise = (tSunrise == 11 || tSunrise == 26)

        // Pure Ekadashi at Arunodaya -> fast today
        if (isEkadashiAtArunodaya && isEkadashiAtSunrise) return true

        // Dashami-viddha: if Dashami at Arunodaya and Ekadashi at Sunrise, fast moves to Dvadashi (tomorrow)
        if (!isEkadashiAtArunodaya && isEkadashiAtSunrise) return false

        // Mahadvadashi: yesterday had Dashami at Arunodaya and Ekadashi at Sunrise
        if (isDvadashiAtSunrise) {
            val (ySunrise, _) = computeSunriseSunset(date.minusDays(1), latitude, longitude, zone)
            val yArun = ySunrise.minusMinutes(if (tradition == CalendarTradition.VRINDAVAN) 72L else 96L)
            val yTSunrise = tithiIndexAt(ySunrise)
            val yTArun = tithiIndexAt(yArun)
            val yEkadashiAtSunrise = (yTSunrise == 10 || yTSunrise == 25)
            val yEkadashiAtArun = (yTArun == 10 || yTArun == 25)
            if (yEkadashiAtSunrise && !yEkadashiAtArun) return true
        }
        return false
    }

    private fun computeParanaWindow(
        paranaDate: LocalDate,
        sunrise: ZonedDateTime,
        sunset: ZonedDateTime
    ): String {
        val tithiSunrise = tithiIndexAt(sunrise)
        // Find end of Dvadashi (tithi 11 or 26) and Hari-vasara (first quarter of Dvadashi)
        val dvadashiIndex = if (tithiSunrise < 15) 11 else 26
        val targetEndPhase = (dvadashiIndex + 1) * 12.0
        val dvadashiStartPhase = dvadashiIndex * 12.0
        val hariVasaraEndPhase = dvadashiStartPhase + 3.0 // first 1/4 of Dvadashi

        val dvadashiEndTime = findTimeForPhase(sunrise.minusHours(18), targetEndPhase)
        val hariVasaraEndTime = findTimeForPhase(sunrise.minusHours(24), hariVasaraEndPhase)

        val dayDurationMinutes = java.time.Duration.between(sunrise, sunset).toMinutes().coerceAtLeast(360)
        val oneThirdDayEnd = sunrise.plusMinutes(dayDurationMinutes / 3)

        val paranaStart = if (hariVasaraEndTime != null && hariVasaraEndTime.isAfter(sunrise) && hariVasaraEndTime.isBefore(oneThirdDayEnd)) {
            hariVasaraEndTime
        } else {
            sunrise
        }
        val paranaEnd = if (dvadashiEndTime != null && dvadashiEndTime.isBefore(oneThirdDayEnd) && dvadashiEndTime.isAfter(paranaStart)) {
            dvadashiEndTime
        } else {
            oneThirdDayEnd
        }

        return "${paranaStart.toLocalTime().format(timeFormatter)} – ${paranaEnd.toLocalTime().format(timeFormatter)}"
    }

    private fun findTimeForPhase(startSearch: ZonedDateTime, targetDeg: Double): ZonedDateTime? {
        var cur = startSearch
        for (step in 0..96) { // search up to 48 hours in 30-min steps, then refine
            val next = cur.plusMinutes(30)
            val p1 = lunarSolarPhaseDeg(cur)
            val p2 = lunarSolarPhaseDeg(next)
            if (crossedAngle(p1, p2, targetDeg % 360.0)) {
                // Binary search to 1 minute precision
                var lo = cur
                var hi = next
                repeat(6) {
                    val mid = lo.plusSeconds(java.time.Duration.between(lo, hi).seconds / 2)
                    if (crossedAngle(lunarSolarPhaseDeg(lo), lunarSolarPhaseDeg(mid), targetDeg % 360.0)) {
                        hi = mid
                    } else {
                        lo = mid
                    }
                }
                return hi
            }
            cur = next
        }
        return null
    }

    private fun crossedAngle(a: Double, b: Double, target: Double): Boolean {
        val diff = ((b - a) + 360.0) % 360.0
        val dist = ((target - a) + 360.0) % 360.0
        return dist <= diff
    }

    private fun computeVaishnavaMasaIndex(zdt: ZonedDateTime): Int {
        // Find approximate previous Amavasya (New Moon) to determine solar sidereal sign (Amanta Masa)
        val phase = lunarSolarPhaseDeg(zdt)
        val daysSinceNewMoon = phase / 12.19075
        val approxNewMoon = zdt.minusHours((daysSinceNewMoon * 24.0).toLong())
        val nirayanaSun = siderealSolarLongitude(approxNewMoon)
        val sign = (floor(nirayanaSun / 30.0).toInt() % 12 + 12) % 12
        // Sun in Meena (11) -> Vishnu (0, Chaitra); Sun in Mesha (0) -> Madhusudana (1, Vaishakha)
        return (sign + 1) % 12
    }

    private fun getEkadashiName(masa: String, paksha: String): String {
        val key = "$masa-$paksha"
        return when (key) {
            "Vishnu-Krishna" -> "Papamochani Ekadashi"
            "Vishnu-Shukla" -> "Kamada Ekadashi"
            "Madhusudana-Krishna" -> "Varuthini Ekadashi"
            "Madhusudana-Shukla" -> "Mohini Ekadashi"
            "Trivikrama-Krishna" -> "Apara Ekadashi"
            "Trivikrama-Shukla" -> "Pandava Nirjala Ekadashi"
            "Vamana-Krishna" -> "Yogini Ekadashi"
            "Vamana-Shukla" -> "Shayana Ekadashi"
            "Sridhara-Krishna" -> "Kamika Ekadashi"
            "Sridhara-Shukla" -> "Pavitropana Ekadashi"
            "Hrishikesha-Krishna" -> "Annada (Aja) Ekadashi"
            "Hrishikesha-Shukla" -> "Parsva Ekadashi"
            "Padmanabha-Krishna" -> "Indira Ekadashi"
            "Padmanabha-Shukla" -> "Pashankusha Ekadashi"
            "Damodara-Krishna" -> "Rama Ekadashi"
            "Damodara-Shukla" -> "Utthana (Haribodhini) Ekadashi"
            "Keshava-Krishna" -> "Utpanna Ekadashi"
            "Keshava-Shukla" -> "Mokshada Ekadashi"
            "Narayana-Krishna" -> "Saphala Ekadashi"
            "Narayana-Shukla" -> "Putrada Ekadashi"
            "Madhava-Krishna" -> "Shat-tila Ekadashi"
            "Madhava-Shukla" -> "Bhaimi (Jaya) Ekadashi"
            "Govinda-Krishna" -> "Vijaya Ekadashi"
            "Govinda-Shukla" -> "Amalaki Ekadashi"
            else -> "$masa $paksha Ekadashi"
        }
    }

    private fun lookupFestivalsForTithi(
        masa: String,
        paksha: String,
        tithiInPaksha: Int,
        fullTithiIndex: Int
    ): List<VaishnavaFestival> {
        val list = mutableListOf<VaishnavaFestival>()
        when ("$masa-$paksha-$tithiInPaksha") {
            "Govinda-Shukla-15" -> list.add(
                VaishnavaFestival(
                    "Sri Gaura Purnima",
                    "MAJOR_FESTIVAL",
                    "Fast until moonrise, then honor Ekadashi-style anukalpa prasadam.",
                    "Appearance Day of Lord Sri Caitanya Mahaprabhu."
                )
            )
            "Madhava-Shukla-13" -> list.add(
                VaishnavaFestival(
                    "Sri Nityananda Trayodashi",
                    "APPEARANCE",
                    "Fast until noon; celebrate with kirtan and feast.",
                    "Appearance Day of Lord Nityananda Prabhu."
                )
            )
            "Madhava-Shukla-7" -> list.add(
                VaishnavaFestival(
                    "Sri Advaita Acharya Appearance",
                    "APPEARANCE",
                    "Fast until noon.",
                    "Appearance Day of Sri Advaita Acharya."
                )
            )
            "Vishnu-Shukla-9" -> list.add(
                VaishnavaFestival(
                    "Sri Rama Navami",
                    "MAJOR_FESTIVAL",
                    "Fast until sunset.",
                    "Appearance Day of Lord Sri Ramachandra."
                )
            )
            "Madhusudana-Shukla-14" -> list.add(
                VaishnavaFestival(
                    "Sri Nrsimha Chaturdashi",
                    "MAJOR_FESTIVAL",
                    "Fast until dusk.",
                    "Appearance Day of Lord Sri Nrsimhadeva."
                )
            )
            "Vamana-Shukla-2" -> list.add(
                VaishnavaFestival(
                    "Sri Jagannatha Ratha Yatra",
                    "MAJOR_FESTIVAL",
                    "Festival of the Chariots.",
                    "Lord Jagannatha, Baladeva & Subhadra Devi festival."
                )
            )
            "Sridhara-Shukla-15" -> list.add(
                VaishnavaFestival(
                    "Sri Balarama Purnima",
                    "APPEARANCE",
                    "Fast until noon.",
                    "Appearance Day of Lord Balarama."
                )
            )
            "Hrishikesha-Krishna-8" -> list.add(
                VaishnavaFestival(
                    "Sri Krishna Janmashtami",
                    "MAJOR_FESTIVAL",
                    "Fast until midnight, followed by anukalpa prasadam.",
                    "Appearance Day of Lord Sri Krishna."
                )
            )
            "Hrishikesha-Krishna-9" -> list.add(
                VaishnavaFestival(
                    "Srila Prabhupada Appearance & Nandotsava",
                    "APPEARANCE",
                    "Fast until noon in honor of His Divine Grace A.C. Bhaktivedanta Swami Prabhupada.",
                    "Vyasa Puja celebration & Nandotsava feast."
                )
            )
            "Hrishikesha-Shukla-8" -> list.add(
                VaishnavaFestival(
                    "Sri Radhastami",
                    "MAJOR_FESTIVAL",
                    "Fast until noon.",
                    "Appearance Day of Srimati Radharani."
                )
            )
            "Hrishikesha-Shukla-12" -> list.add(
                VaishnavaFestival(
                    "Sri Vamana Dvadashi",
                    "APPEARANCE",
                    "Fast until noon (observe with Ekadashi parana rules).",
                    "Appearance Day of Lord Vamanadeva."
                )
            )
            "Damodara-Krishna-15" -> list.add(
                VaishnavaFestival(
                    "Dipavali (Diwali) & Lamp Offering",
                    "MAJOR_FESTIVAL",
                    "Offer ghee lamps to Lord Damodara.",
                    "Sacred Kartik lamp offering."
                )
            )
            "Damodara-Shukla-1" -> list.add(
                VaishnavaFestival(
                    "Govardhana Puja (Annakuta)",
                    "MAJOR_FESTIVAL",
                    "Go Puja & celebration of Sri Govardhana Hill.",
                    "Honor Govardhana Hill and cows."
                )
            )
            "Damodara-Shukla-4" -> list.add(
                VaishnavaFestival(
                    "Srila Prabhupada Disappearance Day",
                    "DISAPPEARANCE",
                    "Fast until noon; offer pushpanjali & remembrance.",
                    "Sacred disappearance observance of ISKCON Founder-Acharya."
                )
            )
            "Damodara-Shukla-15" -> list.add(
                VaishnavaFestival(
                    "Kartik Purnima & Rasa Yatra",
                    "VRATA",
                    "Completion of Damodara Vrata.",
                    "Final day of sacred Kartik month."
                )
            )
            "Keshava-Shukla-11" -> list.add(
                VaishnavaFestival(
                    "Gita Jayanti (Advent of Srimad Bhagavad-gita)",
                    "MAJOR_FESTIVAL",
                    "Recite Bhagavad-gita & observe Mokshada Ekadashi.",
                    "Day Lord Krishna spoke Bhagavad-gita to Arjuna."
                )
            )
        }
        if (fullTithiIndex == 14 && list.none { it.title.contains("Purnima") }) {
            list.add(
                VaishnavaFestival(
                    "$masa Purnima",
                    "VRATA",
                    "Auspicious full moon day for kirtan and charity.",
                    "Completion of $masa Shukla Paksha."
                )
            )
        }
        return list
    }

    // --- ASTRONOMICAL CALCULATIONS (Meeus) ---
    private fun julianDay(zdt: ZonedDateTime): Double {
        val utc = zdt.withZoneSameInstant(ZoneId.of("UTC"))
        var y = utc.year
        var m = utc.monthValue
        val d = utc.dayOfMonth +
            (utc.hour + utc.minute / 60.0 + utc.second / 3600.0) / 24.0
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = y / 100
        val b = 2 - a + (a / 4)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    private fun julianCenturies(jd: Double): Double = (jd - 2451545.0) / 36525.0

    private fun solarLongitude(jd: Double): Double {
        val t = julianCenturies(jd)
        val l0 = normDeg(280.46646 + 36000.76983 * t + 0.0003032 * t * t)
        val m = normDeg(357.52911 + 35999.05029 * t - 0.0001537 * t * t)
        val mRad = Math.toRadians(m)
        val c = (1.914602 - 0.004817 * t - 0.000014 * t * t) * sin(mRad) +
            (0.019993 - 0.000101 * t) * sin(2 * mRad) +
            0.000289 * sin(3 * mRad)
        return normDeg(l0 + c)
    }

    private fun siderealSolarLongitude(zdt: ZonedDateTime): Double {
        val jd = julianDay(zdt)
        val tropical = solarLongitude(jd)
        val ayanamsa = 23.85472 + 0.013969 * ((jd - 2451545.0) / 365.25)
        return normDeg(tropical - ayanamsa)
    }

    private fun lunarLongitude(jd: Double): Double {
        val t = julianCenturies(jd)
        val lPrime = normDeg(218.3164477 + 481267.88123421 * t - 0.0015786 * t * t)
        val d = normDeg(297.8501921 + 445267.1114034 * t - 0.0018819 * t * t)
        val m = normDeg(357.5291092 + 35999.0502909 * t - 0.0001536 * t * t)
        val mPrime = normDeg(134.9633964 + 477198.8675055 * t + 0.0087414 * t * t)
        val f = normDeg(93.2720950 + 483202.0175233 * t - 0.0036539 * t * t)

        val dR = Math.toRadians(d)
        val mR = Math.toRadians(m)
        val mpR = Math.toRadians(mPrime)
        val fR = Math.toRadians(f)

        val sigmaL = 6.288774 * sin(mpR) +
            1.274027 * sin(2 * dR - mpR) +
            0.658314 * sin(2 * dR) +
            0.213618 * sin(2 * mpR) -
            0.185116 * sin(mR) -
            0.114332 * sin(2 * fR) +
            0.058793 * sin(2 * dR - 2 * mpR) +
            0.057066 * sin(2 * dR - mR - mpR) +
            0.053322 * sin(2 * dR + mpR) +
            0.045758 * sin(2 * dR - mR) -
            0.040923 * sin(mR - mpR) -
            0.034720 * sin(dR) -
            0.030383 * sin(mR + mpR)
        return normDeg(lPrime + sigmaL)
    }

    private fun lunarSolarPhaseDeg(zdt: ZonedDateTime): Double {
        val jd = julianDay(zdt)
        return normDeg(lunarLongitude(jd) - solarLongitude(jd))
    }

    private fun tithiIndexAt(zdt: ZonedDateTime): Int {
        val phase = lunarSolarPhaseDeg(zdt)
        return floor(phase / 12.0).toInt().coerceIn(0, 29)
    }

    private fun computeSunriseSunset(
        date: LocalDate,
        latitude: Double,
        longitude: Double,
        zone: ZoneId
    ): Pair<ZonedDateTime, ZonedDateTime> {
        val noon = ZonedDateTime.of(date, LocalTime.NOON, zone)
        val jd = julianDay(noon)
        val t = julianCenturies(jd)
        val sunLon = solarLongitude(jd)
        val obliquity = 23.439291 - 0.0130042 * t
        val dec = Math.asin(sin(Math.toRadians(obliquity)) * sin(Math.toRadians(sunLon)))

        // Equation of Time (minutes)
        val y = tan(Math.toRadians(obliquity / 2.0)).let { it * it }
        val l0 = Math.toRadians(normDeg(280.46646 + 36000.76983 * t))
        val m = Math.toRadians(normDeg(357.52911 + 35999.05029 * t))
        val e = 0.016708634 - 0.000042037 * t
        val eqTimeMin = 4.0 * Math.toDegrees(
            y * sin(2 * l0) - 2 * e * sin(m) + 4 * e * y * sin(m) * cos(2 * l0) -
                0.5 * y * y * sin(4 * l0) - 1.25 * e * e * sin(2 * m)
        )

        val latRad = Math.toRadians(latitude.coerceIn(-66.0, 66.0))
        val zenithRad = Math.toRadians(90.833)
        val cosH = (cos(zenithRad) / (cos(latRad) * cos(dec)) - tan(latRad) * tan(dec))
            .coerceIn(-0.999, 0.999)
        val haDeg = Math.toDegrees(acos(cosH))

        val tzOffsetMin = zone.rules.getOffset(Instant.from(noon)).totalSeconds / 60.0
        val solarNoonMin = 720.0 - 4.0 * longitude - eqTimeMin + tzOffsetMin
        val sunriseMin = (solarNoonMin - 4.0 * haDeg).coerceIn(180.0, 660.0)
        val sunsetMin = (solarNoonMin + 4.0 * haDeg).coerceIn(780.0, 1380.0)

        val sr = ZonedDateTime.of(
            date,
            LocalTime.of((sunriseMin / 60).toInt(), (sunriseMin % 60).toInt()),
            zone
        )
        val ss = ZonedDateTime.of(
            date,
            LocalTime.of((sunsetMin / 60).toInt(), (sunsetMin % 60).toInt()),
            zone
        )
        return sr to ss
    }

    private fun normDeg(deg: Double): Double {
        var d = deg % 360.0
        if (d < 0) d += 360.0
        return d
    }

    @SuppressLint("MissingPermission")
    fun detectCoarseLocation(context: Context): SacredCityPreset? {
        return try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
            val loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER)
                ?: return null
            val tz = ZoneId.systemDefault().id
            var cityLabel = "Current Location"
            runCatching {
                @Suppress("DEPRECATION")
                val addresses = Geocoder(context, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)
                val first = addresses?.firstOrNull()
                val locality = first?.locality ?: first?.adminArea
                val country = first?.countryName
                if (!locality.isNullOrBlank()) {
                    cityLabel = listOfNotNull(locality, country).joinToString(", ")
                }
            }
            SacredCityPreset(cityLabel, loc.latitude, loc.longitude, tz)
        } catch (_: Exception) {
            null
        }
    }
}
