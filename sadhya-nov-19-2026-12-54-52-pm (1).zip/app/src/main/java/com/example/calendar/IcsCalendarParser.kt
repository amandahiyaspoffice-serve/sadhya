package com.example.calendar

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.data.local.ImportedCalendarEventEntity

object IcsCalendarParser {

    fun parseIcsStream(icsText: String, sourceLabel: String = "Imported .ics"): List<ImportedCalendarEventEntity> {
        val events = mutableListOf<ImportedCalendarEventEntity>()
        val unfolded = icsText.replace(Regex("\r?\n[ \t]"), "")
        val blocks = unfolded.split("BEGIN:VEVENT")
        for (i in 1 until blocks.size) {
            val block = blocks[i].substringBefore("END:VEVENT")
            var summary = ""
            var description = ""
            var dateIso = ""
            block.lines().forEach { line ->
                when {
                    line.startsWith("SUMMARY") -> summary = line.substringAfter(":").trim()
                    line.startsWith("DESCRIPTION") -> description = line.substringAfter(":").replace("\\n", " ").trim()
                    line.startsWith("DTSTART") -> {
                        val raw = line.substringAfter(":").trim()
                        val digits = raw.takeWhile { it.isDigit() }
                        if (digits.length >= 8) {
                            dateIso = "${digits.substring(0, 4)}-${digits.substring(4, 6)}-${digits.substring(6, 8)}"
                        }
                    }
                }
            }
            if (summary.isNotBlank() && dateIso.length == 10) {
                val paranaMatch = Regex("(?i)parana[^.]*").find(description)?.value.orEmpty()
                events.add(
                    ImportedCalendarEventEntity(
                        dateIso = dateIso,
                        title = summary.take(120),
                        description = description.take(300),
                        paranaInfo = paranaMatch.take(120),
                        sourceLabel = sourceLabel
                    )
                )
            }
        }
        return events
    }

    fun launchExternalVaishnavaCalendar(context: Context): Boolean {
        // Try known Vaishnava calendar Android package if installed, else open authorized Vaishnava Calendar portal
        val knownPackages = listOf(
            "com.iskcon.vaishnavacalendar",
            "org.iskcon.calendar",
            "com.gaudiya.vaishnavacalendar"
        )
        val pm = context.packageManager
        for (pkg in knownPackages) {
            val launch = pm.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                return true
            }
        }
        return try {
            val browserIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.vaishnavacalendar.info/")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(browserIntent)
            false
        } catch (_: Exception) {
            false
        }
    }
}
