package com.example.focus

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import java.util.Calendar

data class InstalledAppSummary(
    val packageName: String,
    val appName: String,
    val todayMinutes: Int
)

object UsageStatsHelper {

    val commonDistractingDefaults = listOf(
        "com.instagram.android" to "Instagram",
        "com.google.android.youtube" to "YouTube",
        "com.facebook.katana" to "Facebook",
        "com.android.chrome" to "Chrome",
        "com.zhiliaoapp.musically" to "TikTok",
        "com.reddit.frontpage" to "Reddit",
        "com.twitter.android" to "X / Twitter"
    )

    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openUsageAccessSettings(context: Context) {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun getTodayAppUsageMinutes(context: Context): Map<String, Int> {
        if (!hasUsageAccess(context)) return emptyMap()
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return emptyMap()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis
        val end = System.currentTimeMillis()
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end) ?: return emptyMap()
        val map = mutableMapOf<String, Int>()
        for (item in stats) {
            val mins = (item.totalTimeInForeground / 60_000L).toInt()
            if (mins > 0) {
                map[item.packageName] = (map[item.packageName] ?: 0) + mins
            }
        }
        return map
    }

    fun getLauncherApps(context: Context): List<InstalledAppSummary> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(mainIntent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(mainIntent, 0)
        }
        val usageMap = getTodayAppUsageMinutes(context)
        val seen = mutableSetOf<String>()
        val list = mutableListOf<InstalledAppSummary>()

        for (ri in resolved) {
            val pkg = ri.activityInfo?.packageName ?: continue
            if (pkg == context.packageName || !seen.add(pkg)) continue
            val label = ri.loadLabel(pm).toString().ifBlank { pkg }
            list.add(InstalledAppSummary(pkg, label, usageMap[pkg] ?: 0))
        }
        // Also ensure well-known distracting packages appear for easy pre-configuration
        for ((pkg, name) in commonDistractingDefaults) {
            if (seen.add(pkg)) {
                list.add(InstalledAppSummary(pkg, name, usageMap[pkg] ?: 0))
            }
        }
        return list.sortedWith(compareByDescending<InstalledAppSummary> { it.todayMinutes }.thenBy { it.appName })
    }

    fun getCurrentForegroundPackage(context: Context): String? {
        if (!hasUsageAccess(context)) return null
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
        val end = System.currentTimeMillis()
        val start = end - 10_000L
        val events = usm.queryEvents(start, end)
        val event = UsageEvents.Event()
        var lastPkg: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                lastPkg = event.packageName
            }
        }
        return lastPkg
    }
}
