package com.example.focus

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.alarms.AlarmScheduler
import com.example.data.local.PreferencesManager
import com.example.data.local.SadhanaLocalDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class FocusMonitorService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var monitorJob: Job? = null
    private var lastInterruptedPkg: String? = null
    private var lastInterruptedAtMs: Long = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        AlarmScheduler.ensureChannels(this)
        val pi = PendingIntent.getActivity(
            this,
            2001,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, AlarmScheduler.CHANNEL_FOCUS)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle("Focus Shield Active")
            .setContentText("Protecting your Sadhana & deep work from distracting apps.")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()

        startForeground(2001, notification)
        startMonitoringLoop()
        return START_STICKY
    }

    private fun startMonitoringLoop() {
        if (monitorJob?.isActive == true) return
        val prefs = PreferencesManager(applicationContext)
        val dao = SadhanaLocalDatabase.getInstance(applicationContext).sadhanaDao()

        monitorJob = serviceScope.launch {
            while (isActive) {
                val state = prefs.getSnapshot()
                val now = System.currentTimeMillis()
                if (!state.focusShieldActive || (state.focusEndEpochMs in 1..now)) {
                    if (state.focusShieldActive && state.focusEndEpochMs in 1..now) {
                        prefs.setFocusShield(false, 0L, state.currentScheduledActivity, state.strictness)
                    }
                    stopSelf()
                    break
                }

                val fgPkg = UsageStatsHelper.getCurrentForegroundPackage(applicationContext)
                if (!fgPkg.isNullOrBlank() && fgPkg != packageName) {
                    val rules = dao.getBlockedFocusRulesSync()
                    val matchingRule = rules.firstOrNull { it.packageName == fgPkg }
                    if (matchingRule != null && matchingRule.lastExceptionUntilMs < now) {
                        val cooldownPassed = fgPkg != lastInterruptedPkg || (now - lastInterruptedAtMs > 6_000L)
                        if (cooldownPassed) {
                            lastInterruptedPkg = fgPkg
                            lastInterruptedAtMs = now
                            val interruptIntent = Intent(applicationContext, FocusInterruptionActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                putExtra(FocusInterruptionActivity.EXTRA_PKG, matchingRule.packageName)
                                putExtra(FocusInterruptionActivity.EXTRA_APP_NAME, matchingRule.appName)
                                putExtra(FocusInterruptionActivity.EXTRA_ACTIVITY, state.currentScheduledActivity)
                                putExtra(FocusInterruptionActivity.EXTRA_STRICTNESS, state.strictness)
                            }
                            startActivity(interruptIntent)
                        }
                    }
                }
                delay(2000L)
            }
        }
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, FocusMonitorService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FocusMonitorService::class.java))
        }
    }
}
