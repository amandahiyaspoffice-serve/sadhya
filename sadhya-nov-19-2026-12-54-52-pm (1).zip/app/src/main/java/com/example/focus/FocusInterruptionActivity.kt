package com.example.focus

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.MainActivity
import com.example.data.local.GuestLocalRepository
import com.example.data.local.SadhanaLocalDatabase
import com.example.data.model.FocusLog
import com.example.data.model.FocusOutcome
import com.example.data.model.FocusStrictness
import com.example.data.model.safeEnumValueOf
import com.example.data.remote.SadhanaDataRepository
import com.example.data.remote.SadhanaFirestoreRepository
import com.example.ui.theme.SadhanaTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate

class FocusInterruptionActivity : ComponentActivity() {

    companion object {
        const val EXTRA_PKG = "extra_pkg"
        const val EXTRA_APP_NAME = "extra_app_name"
        const val EXTRA_ACTIVITY = "extra_activity"
        const val EXTRA_STRICTNESS = "extra_strictness"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val pkg = intent.getStringExtra(EXTRA_PKG) ?: "com.instagram.android"
        val appName = intent.getStringExtra(EXTRA_APP_NAME) ?: "Restricted App"
        val scheduledActivity = intent.getStringExtra(EXTRA_ACTIVITY) ?: "Daily Sadhana"
        val strictness = safeEnumValueOf(intent.getStringExtra(EXTRA_STRICTNESS), FocusStrictness.BALANCED)

        setContent {
            SadhanaTheme {
                FocusInterruptionScreen(
                    packageName = pkg,
                    appName = appName,
                    scheduledActivity = scheduledActivity,
                    strictness = strictness,
                    onReturnToActivity = {
                        val homeIntent = Intent(this, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        }
                        startActivity(homeIntent)
                        finish()
                    },
                    onAllowAndFinish = {
                        finish()
                    }
                )
            }
        }
    }
}

@Composable
fun FocusInterruptionScreen(
    packageName: String,
    appName: String,
    scheduledActivity: String,
    strictness: FocusStrictness,
    onReturnToActivity: () -> Unit,
    onAllowAndFinish: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { SadhanaLocalDatabase.getInstance(context).sadhanaDao() }
    val firestoreRepo = remember { SadhanaFirestoreRepository(context) }

    var reasonText by remember { mutableStateOf("") }
    var countdown by remember(strictness) { mutableIntStateOf(strictness.holdSeconds) }

    LaunchedEffect(strictness) {
        while (countdown > 0) {
            delay(1000L)
            countdown--
        }
    }

    fun recordAndExecute(outcome: FocusOutcome, exceptionMinutes: Int, after: () -> Unit) {
        scope.launch {
            if (exceptionMinutes > 0) {
                dao.setTemporaryException(packageName, System.currentTimeMillis() + exceptionMinutes * 60_000L)
            }
            val uid = Firebase.auth.currentUser?.uid
            val targetRepo: SadhanaDataRepository = if (!uid.isNullOrBlank()) firestoreRepo else GuestLocalRepository.getInstance(context)
            val targetUid = uid ?: GuestLocalRepository.GUEST_USER_ID
            targetRepo.addFocusLog(
                targetUid,
                FocusLog(
                    userId = targetUid,
                    packageName = packageName,
                    appName = appName,
                    scheduledActivity = scheduledActivity,
                    userReason = reasonText.trim(),
                    outcome = outcome.name,
                    durationMinutes = exceptionMinutes.toLong(),
                    dateIso = LocalDate.now().toString()
                )
            )
            after()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.primary,
                        MaterialTheme.colorScheme.background
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.SelfImprovement,
                    contentDescription = "Mindful Focus Pause",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(38.dp)
                )
            }
            Spacer(Modifier.height(16.dp))
            Text(
                text = "Mindful Pause — $appName",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "What were you supposed to be doing?",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onPrimary,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Scheduled now: $scheduledActivity",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.95f),
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(24.dp))

            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Is opening this application really necessary?",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    OutlinedTextField(
                        value = reasonText,
                        onValueChange = { reasonText = it },
                        label = { Text("Explain why you need access right now") },
                        placeholder = { Text("e.g., Replying to temple seva message...") },
                        minLines = 2,
                        maxLines = 3,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("focus_reason_input")
                    )

                    Button(
                        onClick = {
                            recordAndExecute(FocusOutcome.RETURNED, 0, onReturnToActivity)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("focus_return_button")
                    ) {
                        Text("Return to $scheduledActivity")
                    }

                    val needsReason = strictness != FocusStrictness.GENTLE
                    val canRequestException = countdown == 0 && (!needsReason || reasonText.trim().length >= 5)

                    OutlinedButton(
                        onClick = {
                            recordAndExecute(FocusOutcome.TEMP_EXCEPTION, 5, onAllowAndFinish)
                        },
                        enabled = canRequestException,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("focus_exception_button")
                    ) {
                        Text(
                            if (countdown > 0) "Request 5m Exception (${countdown}s)"
                            else if (needsReason && reasonText.trim().length < 5) "Write brief reason for 5m exception"
                            else "Request 5m Temporary Exception"
                        )
                    }

                    if (strictness != FocusStrictness.STRICT) {
                        TextButton(
                            onClick = {
                                recordAndExecute(FocusOutcome.EMERGENCY_BYPASS, 15, onAllowAndFinish)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("focus_emergency_button")
                        ) {
                            Text("Emergency Bypass (15 min)")
                        }
                    } else {
                        Text(
                            text = "Strict Focus Mode: Emergency bypass is disabled during active focus.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}
