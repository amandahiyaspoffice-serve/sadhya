package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.alarms.AlarmScheduler
import com.example.data.local.GuestLocalRepository
import com.example.data.local.LocalAlarmFocusState
import com.example.data.local.PreferencesManager
import com.example.data.local.SadhanaLocalDatabase
import com.example.data.model.SadhanaDailyLog
import com.example.data.model.UserProfile
import com.example.data.remote.AuthHelper
import com.example.data.remote.GeminiAssistantRepository
import com.example.data.remote.SadhanaFirestoreRepository
import com.example.data.remote.authStateFlow
import com.example.data.remote.configureAppCheck
import com.example.media.DevotionalAudioPlayer
import com.example.ui.components.SanctuaryCard
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.FocusScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.ProfileAiScreen
import com.example.ui.screens.SadhanaScreen
import com.example.ui.theme.SadhanaTheme
import com.example.ui.viewmodel.SadhanaViewModel
import com.example.ui.viewmodel.UiState
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch
import java.time.LocalDate

enum class SadhanaTab(val label: String, val icon: ImageVector, val testTag: String) {
    HOME("Home", Icons.Default.Home, "nav_home"),
    SADHANA("Sadhana", Icons.Default.SelfImprovement, "nav_sadhana"),
    CALENDAR("Calendar", Icons.Default.CalendarMonth, "nav_calendar"),
    FOCUS("Focus", Icons.Default.Shield, "nav_focus"),
    PROFILE("Profile/AI", Icons.Default.Person, "nav_profile")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Must run before setContent, ViewModels, or any Firebase operations
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        AlarmScheduler.ensureChannels(this)

        setContent {
            SadhanaRootApp()
        }
    }
}

@Composable
private fun SadhanaRootApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { PreferencesManager(context.applicationContext) }
    val currentUser by Firebase.auth.authStateFlow().collectAsStateWithLifecycle(
        initialValue = Firebase.auth.currentUser
    )
    val localPrefs by prefs.stateFlow.collectAsStateWithLifecycle(initialValue = LocalAlarmFocusState())

    val user = currentUser
    LaunchedEffect(user?.uid) {
        if (user != null && localPrefs.guestModeEnabled) {
            prefs.setGuestModeEnabled(false)
        }
    }

    when {
        user != null -> {
            key(user.uid) {
                AuthenticatedSadhanaApp(
                    uid = user.uid,
                    displayName = user.displayName ?: "Devotee",
                    email = user.email ?: "",
                    isGuest = false
                )
            }
        }
        localPrefs.guestModeEnabled -> {
            key(GuestLocalRepository.GUEST_USER_ID) {
                AuthenticatedSadhanaApp(
                    uid = GuestLocalRepository.GUEST_USER_ID,
                    displayName = "Guest Devotee",
                    email = "",
                    isGuest = true
                )
            }
        }
        else -> {
            SadhanaTheme {
                AuthScreen(
                    onAuthSuccess = {},
                    onContinueAsGuest = {
                        scope.launch { prefs.setGuestModeEnabled(true) }
                    }
                )
            }
        }
    }
}

@Composable
private fun AuthenticatedSadhanaApp(
    uid: String,
    displayName: String,
    email: String,
    isGuest: Boolean
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    val viewModel: SadhanaViewModel = viewModel(
        key = "$uid-$isGuest",
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val appContext = context.applicationContext
                val repo = if (isGuest) {
                    GuestLocalRepository.getInstance(appContext)
                } else {
                    SadhanaFirestoreRepository(appContext)
                }
                return SadhanaViewModel(
                    currentUserId = uid,
                    initialDisplayName = displayName,
                    initialEmail = email,
                    firestoreRepo = repo,
                    geminiRepo = GeminiAssistantRepository(),
                    dao = SadhanaLocalDatabase.getInstance(appContext).sadhanaDao(),
                    prefs = PreferencesManager(appContext),
                    audioPlayer = DevotionalAudioPlayer(),
                    isGuestMode = isGuest
                ) as T
            }
        }
    )

    val profileState by viewModel.profileState.collectAsStateWithLifecycle()
    val scheduleState by viewModel.scheduleState.collectAsStateWithLifecycle()
    val tasksState by viewModel.tasksState.collectAsStateWithLifecycle()
    val sadhanaLogsState by viewModel.sadhanaLogsState.collectAsStateWithLifecycle()
    val localPrefs by viewModel.localPrefsState.collectAsStateWithLifecycle()
    val aiTaskState by viewModel.aiTaskState.collectAsStateWithLifecycle()
    val aiWakeState by viewModel.aiWakeReflection.collectAsStateWithLifecycle()
    val audioState by viewModel.audioState.collectAsStateWithLifecycle()
    val bannerFeedback by viewModel.bannerFeedback.collectAsStateWithLifecycle()

    val profile = (profileState as? UiState.Success)?.data ?: UserProfile(
        userId = uid,
        displayName = displayName,
        email = email
    )

    var forceOnboarding by rememberSaveable { mutableStateOf(false) }
    var currentTab by rememberSaveable { mutableStateOf(SadhanaTab.HOME) }
    val snackbarHostState = remember { SnackbarHostState() }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(uid) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    LaunchedEffect(bannerFeedback) {
        val msg = bannerFeedback
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearBannerFeedback()
        }
    }

    SadhanaTheme(
        themeStyle = profile.themeStyleEnum(),
        darkModePreference = profile.darkModeEnum(),
        fontScaleLevel = profile.fontScaleEnum()
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            when (val pState = profileState) {
                is UiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator()
                            Spacer(Modifier.height(12.dp))
                            Text(
                                text = "Preparing your Sadhya Sanctuary...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                is UiState.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        SanctuaryCard {
                            Text(
                                text = "Unable to sync your sanctuary",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = pState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(14.dp))
                            OutlinedButton(
                                onClick = { AuthHelper.signOut(credentialManager, scope) }
                            ) {
                                Text("Sign Out & Switch Account")
                            }
                        }
                    }
                }

                is UiState.Success -> {
                    val resolvedProfile = pState.data ?: profile
                    if (!resolvedProfile.onboardingCompleted || forceOnboarding) {
                        if (forceOnboarding) {
                            BackHandler { forceOnboarding = false }
                        }
                        OnboardingScreen(
                            initialProfile = resolvedProfile,
                            onComplete = { updated ->
                                viewModel.completeOnboarding(updated) { snap ->
                                    AlarmScheduler.syncAllAlarms(context, snap)
                                }
                                forceOnboarding = false
                            },
                            onSkipAll = {
                                viewModel.completeOnboarding(resolvedProfile) { snap ->
                                    AlarmScheduler.syncAllAlarms(context, snap)
                                }
                                forceOnboarding = false
                            }
                        )
                    } else {
                        val todayIso = remember { LocalDate.now().toString() }
                        val allLogs = (sadhanaLogsState as? UiState.Success)?.data.orEmpty()
                        val todayLog = allLogs.firstOrNull { it.dateIso == todayIso }
                            ?: SadhanaDailyLog(
                                userId = uid,
                                dateIso = todayIso,
                                targetRounds = resolvedProfile.japaTargetRounds
                            )

                        if (currentTab != SadhanaTab.HOME) {
                            BackHandler { currentTab = SadhanaTab.HOME }
                        }

                        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                            val useRail = maxWidth >= 600.dp

                            Scaffold(
                                contentWindowInsets = WindowInsets.statusBars,
                                snackbarHost = { SnackbarHost(snackbarHostState) },
                                bottomBar = {
                                    if (!useRail) {
                                        NavigationBar(
                                            windowInsets = WindowInsets.navigationBars
                                        ) {
                                            SadhanaTab.entries.forEach { tab ->
                                                NavigationBarItem(
                                                    selected = currentTab == tab,
                                                    onClick = { currentTab = tab },
                                                    icon = {
                                                        Icon(tab.icon, contentDescription = tab.label)
                                                    },
                                                    label = {
                                                        Text(
                                                            text = tab.label,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                    },
                                                    modifier = Modifier.testTag(tab.testTag)
                                                )
                                            }
                                        }
                                    }
                                }
                            ) { innerPadding ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(innerPadding)
                                ) {
                                    if (useRail) {
                                        NavigationRail(modifier = Modifier.fillMaxHeight()) {
                                            Spacer(Modifier.height(16.dp))
                                            SadhanaTab.entries.forEach { tab ->
                                                NavigationRailItem(
                                                    selected = currentTab == tab,
                                                    onClick = { currentTab = tab },
                                                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                                                    label = { Text(tab.label, maxLines = 1) },
                                                    modifier = Modifier.testTag(tab.testTag)
                                                )
                                            }
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxHeight(),
                                        contentAlignment = Alignment.TopCenter
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .widthIn(max = 840.dp)
                                        ) {
                                            when (currentTab) {
                                                SadhanaTab.HOME -> HomeScreen(
                                                    viewModel = viewModel,
                                                    profile = resolvedProfile,
                                                    scheduleState = scheduleState,
                                                    tasksState = tasksState,
                                                    todayLog = todayLog,
                                                    localPrefs = localPrefs,
                                                    aiTaskState = aiTaskState,
                                                    aiWakeState = aiWakeState,
                                                    onOpenSadhanaTab = { currentTab = SadhanaTab.SADHANA },
                                                    onOpenCalendarTab = { currentTab = SadhanaTab.CALENDAR }
                                                )

                                                SadhanaTab.SADHANA -> SadhanaScreen(
                                                    viewModel = viewModel,
                                                    profile = resolvedProfile,
                                                    todayLog = todayLog,
                                                    recentLogs = allLogs.take(7),
                                                    localPrefs = localPrefs,
                                                    audioState = audioState
                                                )

                                                SadhanaTab.CALENDAR -> CalendarScreen(
                                                    viewModel = viewModel,
                                                    profile = resolvedProfile
                                                )

                                                SadhanaTab.FOCUS -> FocusScreen(
                                                    viewModel = viewModel,
                                                    profile = resolvedProfile
                                                )

                                                SadhanaTab.PROFILE -> ProfileAiScreen(
                                                    viewModel = viewModel,
                                                    profile = resolvedProfile,
                                                    onReopenOnboarding = { forceOnboarding = true }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
