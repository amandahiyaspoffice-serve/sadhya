package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.alarms.AlarmScheduler
import com.example.alarms.WakeUpAlarmActivity
import com.example.data.model.DarkModePreference
import com.example.data.model.FontScaleLevel
import com.example.data.model.TempleCommunity
import com.example.data.model.TemplePostType
import com.example.data.model.ThemeStyle
import com.example.data.model.UserProfile
import com.example.data.remote.AuthHelper
import com.example.ui.components.PillBadge
import com.example.ui.components.SanctuaryCard
import com.example.ui.components.SectionHeader
import com.example.ui.viewmodel.AiTaskState
import com.example.ui.viewmodel.SadhanaViewModel
import com.example.ui.viewmodel.UiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileAiScreen(
    viewModel: SadhanaViewModel,
    profile: UserProfile,
    onReopenOnboarding: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    val coachMessages by viewModel.coachMessages.collectAsStateWithLifecycle()
    val coachError by viewModel.coachError.collectAsStateWithLifecycle()
    val aiScheduleState by viewModel.aiScheduleState.collectAsStateWithLifecycle()
    val templesState by viewModel.templesState.collectAsStateWithLifecycle()
    val postsState by viewModel.followedTemplePostsState.collectAsStateWithLifecycle()
    val localPrefs by viewModel.localPrefsState.collectAsStateWithLifecycle()
    val checkIns by viewModel.privateCheckInsState.collectAsStateWithLifecycle()

    var coachInput by remember { mutableStateOf("") }
    var schedulePrompt by remember { mutableStateOf("") }
    var preserveEssentials by remember { mutableStateOf(true) }

    // Alarm editing states
    var wakeEnabled by remember(localPrefs.wakeAlarmEnabled) { mutableStateOf(localPrefs.wakeAlarmEnabled) }
    var wakeTime by remember(profile.wakeTime) { mutableStateOf(profile.wakeTime) }
    var sleepTime by remember(profile.sleepTime) { mutableStateOf(profile.sleepTime) }
    var bedtimeEnabled by remember(localPrefs.bedtimeRemindersEnabled) { mutableStateOf(localPrefs.bedtimeRemindersEnabled) }
    var gayatriEnabled by remember(profile.gayatriInitiated) { mutableStateOf(profile.gayatriInitiated) }
    var gayatriM by remember(profile.gayatriMorningTime) { mutableStateOf(profile.gayatriMorningTime) }
    var gayatriA by remember(profile.gayatriAfternoonTime) { mutableStateOf(profile.gayatriAfternoonTime) }
    var gayatriE by remember(profile.gayatriEveningTime) { mutableStateOf(profile.gayatriEveningTime) }

    // Temple Admin Dialogs
    var showCreateTempleDialog by remember { mutableStateOf(false) }
    var showPublishPostFor by remember { mutableStateOf<TempleCommunity?>(null) }

    val voiceScheduleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                schedulePrompt = spoken
            }
        }
    }

    val temples = (templesState as? UiState.Success)?.data.orEmpty()
    val followedTemple = temples.firstOrNull { it.id == profile.followedTempleId }
    val posts = (postsState as? UiState.Success)?.data.orEmpty()

    val onTimeCheckIns = checkIns.count { it.status == "ON_TIME" }
    val wakeConsistencyPct = if (checkIns.isNotEmpty()) (onTimeCheckIns * 100) / checkIns.size else 100

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Companion, Temples & Profile",
                subtitle = if (viewModel.isGuestMode) {
                    "${profile.displayName} • Guest Mode (Local)"
                } else {
                    "${profile.displayName} • ${profile.routineModeEnum().label}"
                },
                icon = Icons.Default.Person,
                trailing = {
                    if (viewModel.isGuestMode) {
                        Button(
                            onClick = { viewModel.exitGuestMode() },
                            modifier = Modifier.testTag("guest_sign_in_button")
                        ) {
                            Text("Sign In")
                        }
                    } else {
                        OutlinedButton(
                            onClick = { AuthHelper.signOut(credentialManager, scope) },
                            modifier = Modifier.testTag("sign_out_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Sign Out")
                        }
                    }
                }
            )
        }

        if (viewModel.isGuestMode) {
            item {
                SanctuaryCard(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            PillBadge(text = "Guest Mode Active")
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = "All Sadhya features are unlocked locally on this device. Sign in with Google anytime to sync schedules and join shared temples across devices.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            }
        }

        // 1. Gemini Accountability Companion
        item {
            SanctuaryCard {
                SectionHeader(
                    title = "Gemini Sadhana Companion",
                    subtitle = "Encouraging, compassionate & practical accountability",
                    icon = Icons.Default.Psychology
                )
                Spacer(Modifier.height(8.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "Weekly Sadhana Report",
                        "Why I missed wake-up",
                        "Screen time advice"
                    ).forEach { quick ->
                        FilterChip(
                            selected = false,
                            onClick = { viewModel.sendCoachMessage(quick) },
                            label = { Text(quick) }
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    coachMessages.takeLast(6).forEach { msg ->
                        val isUser = msg.role == "user"
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (isUser) MaterialTheme.colorScheme.primaryContainer
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = if (isUser) "You" else "Sadhana Companion",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = if (msg.text.isBlank() && msg.isStreaming) "Reflecting gently..." else msg.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                if (coachError != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = coachError!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = coachInput,
                        onValueChange = { coachInput = it },
                        placeholder = { Text("Ask about rounds, missed wake-ups, balance...") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("coach_chat_input")
                    )
                    IconButton(
                        onClick = {
                            if (coachInput.isNotBlank()) {
                                viewModel.sendCoachMessage(coachInput)
                                coachInput = ""
                            }
                        },
                        modifier = Modifier.testTag("coach_send_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send to Gemini Companion")
                    }
                }
            }
        }

        // 2. Gemini Natural Language Schedule Generator
        item {
            SanctuaryCard {
                SectionHeader(
                    title = "AI Schedule Generator",
                    subtitle = "Describe your day naturally — spiritual essentials stay protected",
                    icon = Icons.Default.AutoAwesome
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = schedulePrompt,
                    onValueChange = { schedulePrompt = it },
                    label = { Text("Describe your ideal day") },
                    placeholder = {
                        Text("I want to wake up at 4 AM, chant 16 rounds, attend Mangal Aarti, read Gita 30m, study 5 hours, exercise and sleep at 10 PM.")
                    },
                    minLines = 3,
                    maxLines = 5,
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your ideal daily schedule")
                                }
                                runCatching { voiceScheduleLauncher.launch(intent) }
                            }
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = "Voice input for schedule")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ai_schedule_prompt_input")
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = preserveEssentials,
                        onCheckedChange = { preserveEssentials = it }
                    )
                    Text(
                        text = "Preserve existing essential spiritual items",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val prompt = schedulePrompt.ifBlank {
                                "Wake up at ${profile.wakeTime}, chant ${profile.japaTargetRounds} rounds, read ${profile.readingTargetMinutes}m, balance responsibilities (${profile.responsibilities.joinToString()}), sleep at ${profile.sleepTime}"
                            }
                            viewModel.generateScheduleWithAi(prompt, preserveEssentials)
                        },
                        enabled = aiScheduleState !is AiTaskState.Loading,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_generate_schedule_button")
                    ) {
                        if (aiScheduleState is AiTaskState.Loading) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                        }
                        Text("Generate Timetable")
                    }
                    OutlinedButton(
                        onClick = {
                            schedulePrompt = "Wake at 04:00, chant 16 rounds, Mangal Aarti, read Gita 30 min, work/study 6h, exercise 40 min, sleep at 22:00"
                        }
                    ) {
                        Text("Example")
                    }
                }

                when (val state = aiScheduleState) {
                    is AiTaskState.Success -> {
                        Spacer(Modifier.height(8.dp))
                        Text(state.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                    is AiTaskState.Error -> {
                        Spacer(Modifier.height(8.dp))
                        Text(state.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                    else -> Unit
                }
            }
        }

        // 3. Temple Community Hub
        item {
            SanctuaryCard {
                SectionHeader(
                    title = "Temple Community Hub",
                    subtitle = "Follow official temple timings, festivals & seva needs",
                    icon = Icons.Default.AccountBalance,
                    trailing = {
                        OutlinedButton(
                            onClick = { showCreateTempleDialog = true },
                            modifier = Modifier.testTag("create_temple_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Temple")
                        }
                    }
                )
                Spacer(Modifier.height(8.dp))

                if (temples.isEmpty()) {
                    Text(
                        text = "No temples published yet. Temple administrators can create a temple profile to share official schedules and seva opportunities.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    temples.forEach { temple ->
                        val isFollowed = temple.id == profile.followedTempleId
                        val isTempleAdmin = temple.adminUid == profile.userId
                        Column(modifier = Modifier.padding(vertical = 6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(temple.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        text = "${temple.city} • ${temple.tradition} • Mangal ${temple.mangalAartiTime}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (isFollowed) {
                                    PillBadge(text = "Following")
                                } else {
                                    OutlinedButton(onClick = { viewModel.followTemple(temple) }) {
                                        Text("Follow")
                                    }
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { viewModel.applyTempleScheduleToMyRoutine(temple) }) {
                                    Text("Apply Schedule")
                                }
                                if (isTempleAdmin) {
                                    Button(onClick = { showPublishPostFor = temple }) {
                                        Text("Publish Post")
                                    }
                                }
                            }
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    }
                }

                if (followedTemple != null && posts.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "${followedTemple.name} Updates",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(6.dp))
                    posts.forEach { post ->
                        val isVolunteered = profile.userId in post.volunteerUids
                        SanctuaryCard(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                PillBadge(text = post.postTypeEnum().label)
                                if (post.eventDate.isNotBlank()) {
                                    Text(
                                        text = "${post.eventDate} ${post.eventTime}".trim(),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(post.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text(post.body, style = MaterialTheme.typography.bodySmall)
                            if (post.postType == TemplePostType.SEVA.name) {
                                Spacer(Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${post.volunteerUids.size}/${post.sevaSlotsTotal} volunteers",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                    Button(
                                        onClick = { viewModel.toggleSevaVolunteer(followedTemple.id, post) }
                                    ) {
                                        Icon(Icons.Default.VolunteerActivism, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(if (isVolunteered) "Leave Seva" else "Volunteer")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Brahma Muhurta Alarms & Gayatri Reminders
        item {
            SanctuaryCard {
                SectionHeader(
                    title = "Wake-Up, Gayatri & Bedtime Alarms",
                    subtitle = "Consistency: $wakeConsistencyPct% ($onTimeCheckIns/${checkIns.size.coerceAtLeast(1)} on time)",
                    icon = Icons.Default.Alarm
                )
                Spacer(Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Brahma Muhurta Wake-Up Alarm", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = wakeEnabled, onCheckedChange = { wakeEnabled = it })
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = wakeTime,
                        onValueChange = { wakeTime = it },
                        label = { Text("Wake (HH:mm)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = sleepTime,
                        onValueChange = { sleepTime = it },
                        label = { Text("Sleep (HH:mm)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Bedtime 3-Stage Wind-Down", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = bedtimeEnabled, onCheckedChange = { bedtimeEnabled = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Gayatri Sandhya Reminders", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = gayatriEnabled, onCheckedChange = { gayatriEnabled = it })
                }

                if (gayatriEnabled) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = gayatriM,
                            onValueChange = { gayatriM = it },
                            label = { Text("Morning") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = gayatriA,
                            onValueChange = { gayatriA = it },
                            label = { Text("Noon") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = gayatriE,
                            onValueChange = { gayatriE = it },
                            label = { Text("Evening") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            viewModel.updateAlarmSettings(
                                wakeEnabled = wakeEnabled,
                                wakeTime = wakeTime,
                                sleepTime = sleepTime,
                                bedtimeEnabled = bedtimeEnabled,
                                gayatriEnabled = gayatriEnabled,
                                gayatriM = gayatriM,
                                gayatriA = gayatriA,
                                gayatriE = gayatriE,
                                onAlarmsSync = { AlarmScheduler.syncAllAlarms(context, it) }
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_alarms_button")
                    ) {
                        Text("Save & Schedule Alarms")
                    }
                    OutlinedButton(
                        onClick = { context.startActivity(Intent(context, WakeUpAlarmActivity::class.java)) }
                    ) {
                        Text("Test Wake UI")
                    }
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !AlarmScheduler.canScheduleExactAlarms(context)) {
                    Spacer(Modifier.height(8.dp))
                    TextButton(
                        onClick = {
                            runCatching {
                                context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                            }
                        }
                    ) {
                        Text("Allow Exact Alarms in Android Settings for pinpoint timing")
                    }
                }
            }
        }

        // 5. Appearance & Home Screen Customization
        item {
            var selectedTheme by remember(profile.themeStyle) { mutableStateOf(profile.themeStyleEnum()) }
            var selectedDark by remember(profile.darkModePreference) { mutableStateOf(profile.darkModeEnum()) }
            var selectedFont by remember(profile.fontScaleLevel) { mutableStateOf(profile.fontScaleEnum()) }
            var showMedia by remember(localPrefs.showQuickMediaCard) { mutableStateOf(localPrefs.showQuickMediaCard) }
            var showWake by remember(localPrefs.showWakeUpCard) { mutableStateOf(localPrefs.showWakeUpCard) }

            SanctuaryCard {
                SectionHeader(
                    title = "Appearance & Home Layout",
                    subtitle = "Tailor theme colors, dark mode & dashboard cards",
                    icon = Icons.Default.Palette
                )
                Spacer(Modifier.height(8.dp))

                Text("Color Theme", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeStyle.entries.forEach { t ->
                        FilterChip(
                            selected = selectedTheme == t,
                            onClick = {
                                selectedTheme = t
                                viewModel.updateThemeAndCustomization(t, selectedDark, selectedFont, showMedia, showWake)
                            },
                            label = { Text(t.label) }
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                Text("Dark Mode", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DarkModePreference.entries.forEach { d ->
                        FilterChip(
                            selected = selectedDark == d,
                            onClick = {
                                selectedDark = d
                                viewModel.updateThemeAndCustomization(selectedTheme, d, selectedFont, showMedia, showWake)
                            },
                            label = { Text(d.label) }
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                Text("Font Size", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FontScaleLevel.entries.forEach { f ->
                        FilterChip(
                            selected = selectedFont == f,
                            onClick = {
                                selectedFont = f
                                viewModel.updateThemeAndCustomization(selectedTheme, selectedDark, f, showMedia, showWake)
                            },
                            label = { Text(f.label) }
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Show Brahma Muhurta Card on Home", style = MaterialTheme.typography.bodySmall)
                    Switch(
                        checked = showWake,
                        onCheckedChange = {
                            showWake = it
                            viewModel.updateThemeAndCustomization(selectedTheme, selectedDark, selectedFont, showMedia, it)
                        }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Show Live Darshan Banner on Home", style = MaterialTheme.typography.bodySmall)
                    Switch(
                        checked = showMedia,
                        onCheckedChange = {
                            showMedia = it
                            viewModel.updateThemeAndCustomization(selectedTheme, selectedDark, selectedFont, it, showWake)
                        }
                    )
                }

                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onReopenOnboarding,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rerun_onboarding_button")
                ) {
                    Text("Re-run 10-Step Onboarding Questionnaire")
                }
            }
        }
    }

    if (showCreateTempleDialog) {
        CreateTempleDialog(
            onDismiss = { showCreateTempleDialog = false },
            onConfirm = { name, city, tradition, mangal, darshan, sb, sandhya, desc ->
                viewModel.createTemple(name, city, tradition, mangal, darshan, sb, sandhya, desc)
                showCreateTempleDialog = false
            }
        )
    }

    if (showPublishPostFor != null) {
        val targetTemple = showPublishPostFor!!
        PublishTemplePostDialog(
            templeName = targetTemple.name,
            onDismiss = { showPublishPostFor = null },
            onPublish = { type, title, body, date, time, slots ->
                viewModel.publishTemplePost(targetTemple.id, type, title, body, date, time, slots)
                showPublishPostFor = null
            }
        )
    }
}

@Composable
private fun CreateTempleDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var tradition by remember { mutableStateOf("ISKCON") }
    var mangal by remember { mutableStateOf("04:30") }
    var darshan by remember { mutableStateOf("07:15") }
    var sb by remember { mutableStateOf("08:00") }
    var sandhya by remember { mutableStateOf("18:30") }
    var desc by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Temple Community") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Temple Name") }, singleLine = true)
                OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("City") }, singleLine = true)
                OutlinedTextField(value = tradition, onValueChange = { tradition = it }, label = { Text("Tradition") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = mangal, onValueChange = { mangal = it }, label = { Text("Mangal") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = darshan, onValueChange = { darshan = it }, label = { Text("Darshan") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = sb, onValueChange = { sb = it }, label = { Text("SB Class") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = sandhya, onValueChange = { sandhya = it }, label = { Text("Sandhya") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Welcome note") }, maxLines = 2)
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(name, city, tradition, mangal, darshan, sb, sandhya, desc) },
                enabled = name.trim().length >= 2 && city.trim().length >= 2
            ) {
                Text("Create")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PublishTemplePostDialog(
    templeName: String,
    onDismiss: () -> Unit,
    onPublish: (TemplePostType, String, String, String, String, Long) -> Unit
) {
    var postType by remember { mutableStateOf(TemplePostType.ANNOUNCEMENT) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var eventDate by remember { mutableStateOf("") }
    var eventTime by remember { mutableStateOf("") }
    var sevaSlots by remember { mutableStateOf("5") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Publish to $templeName") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TemplePostType.entries.forEach { t ->
                        FilterChip(
                            selected = postType == t,
                            onClick = { postType = t },
                            label = { Text(t.label) }
                        )
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true)
                OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Details") }, minLines = 2)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = eventDate, onValueChange = { eventDate = it }, label = { Text("Date (optional)") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = eventTime, onValueChange = { eventTime = it }, label = { Text("Time (optional)") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                if (postType == TemplePostType.SEVA) {
                    OutlinedTextField(
                        value = sevaSlots,
                        onValueChange = { sevaSlots = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Volunteer Slots Needed") },
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onPublish(
                        postType,
                        title,
                        body,
                        eventDate,
                        eventTime,
                        sevaSlots.toLongOrNull() ?: 0L
                    )
                },
                enabled = title.trim().length >= 2 && body.trim().length >= 2
            ) {
                Text("Publish")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
