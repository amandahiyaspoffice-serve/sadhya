package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- Theme 1: Ivory & Deep Maroon (Default Devotional Sanctuary) ---
val IvoryBackground = Color(0xFFFAF6EE)
val ParchmentSurface = Color(0xFFFFFDF8)
val WarmSandVariant = Color(0xFFF1E8D8)
val DeepMaroonPrimary = Color(0xFF6B1D2B)
val MaroonContainer = Color(0xFFF6D9DD)
val OnMaroonContainer = Color(0xFF3E0A14)
val SaffronSecondary = Color(0xFFD67222)
val SaffronContainer = Color(0xFFFFE5CF)
val OnSaffronContainer = Color(0xFF472000)
val SacredGoldTertiary = Color(0xFFB5851A)
val GoldContainer = Color(0xFFFBEBC4)
val CharcoalUmber = Color(0xFF241917)
val MutedUmber = Color(0xFF6B5B57)
val SoftOutline = Color(0xFFD9CDBB)

// Dark Sanctuary
val NightUmberBackground = Color(0xFF151012)
val NightPlumSurface = Color(0xFF21181B)
val NightSurfaceVariant = Color(0xFF302428)
val LuminousGoldPrimary = Color(0xFFF0B45A)
val NightMaroonContainer = Color(0xFF4D1A24)
val SoftRoseSecondary = Color(0xFFE58C97)
val NightSaffronContainer = Color(0xFF4F2B0D)
val TulasiGreen = Color(0xFF3E6B48)
val TulasiLight = Color(0xFF81B98D)
val NightTextPrimary = Color(0xFFF5ECE4)
val NightTextMuted = Color(0xFFC4B3AB)
val NightOutline = Color(0xFF4A3B3E)

// --- Theme 2: Saffron & Sand ---
val SandSaffronPrimary = Color(0xFFB85414)
val SandGoldSecondary = Color(0xFF8B6215)
val SandSaffronContainer = Color(0xFFFFE1CC)
val SandDarkPrimary = Color(0xFFFFB685)

// --- Theme 3: Vrindavan Forest ---
val VrindavanGreenPrimary = Color(0xFF2E5C3E)
val VrindavanSaffronSecondary = Color(0xFFC86D24)
val VrindavanContainer = Color(0xFFD2ECD8)
val VrindavanDarkPrimary = Color(0xFF8CD1A0)
