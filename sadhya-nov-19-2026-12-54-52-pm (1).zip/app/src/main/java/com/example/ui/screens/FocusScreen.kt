package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.alarms.AlarmScheduler
import com.example.data.model.FocusOutcome
import com.example.data.model.FocusStrictness
import com.example.data.model.RoutineTemplates
import com.example.data.model.UserProfile
import com.example.focus.FocusInterruptionActivity
import com.example.focus.FocusMonitorService
import com.example.focus.InstalledAppSummary
import com.example.focus.UsageStatsHelper
import com.example.ui.components.PillBadge
import com.example.ui.components.SanctuaryCard
import com.example.ui.components.SectionHeader
import com.example.ui.viewmodel.SadhanaViewModel
import com.example.ui.viewmodel.UiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FocusScreen(
    viewModel: SadhanaViewModel,
    profile: UserProfile
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val localPrefs by viewModel.localPrefsState.collectAsStateWithLifecycle()
    val focusRules by viewModel.focusRulesState.collectAsStateWithLifecycle()
    val focusLogsState by viewModel.focusLogsState.collectAsStateWithLifecycle()
    val scheduleState by viewModel.scheduleState.collectAsStateWithLifecycle()

    var hasUsageAccess by remember { mutableStateOf(UsageStatsHelper.hasUsageAccess(context)) }
    var installedApps by remember { mutableStateOf<List<InstalledAppSummary>>(emptyList()) }
    var usageMinutesMap by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var selectedDuration by remember { mutableIntStateOf(45) }
    var appSearch by remember { mutableStateOf("") }

    // Refresh permissions and device usage stats when returning from Android Settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasUsageAccess = UsageStatsHelper.hasUsageAccess(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(hasUsageAccess) {
        withContext(Dispatchers.IO) {
            val apps = UsageStatsHelper.getLauncherApps(context)
            val usage = UsageStatsHelper.getTodayAppUsageMinutes(context)
            withContext(Dispatchers.Main) {
                installedApps = apps
                usageMinutesMap = usage
            }
        }
    }

    val currentScheduleBlock = remember(scheduleState) {
        val list = (scheduleState as? UiState.Success)?.data.orEmpty()
        val now = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
        list.firstOrNull { now >= it.startTime && now <= it.endTime }?.title ?: "Morning Japa & Deep Sadhana"
    }

    val blockedPackages = remember(focusRules, profile.distractingPackages) {
        val ruleSet = focusRules.filter { it.blockedDuringFocus }.map { it.packageName }.toSet()
        ruleSet + profile.distractingPackages.toSet()
    }

    val focusLogs = (focusLogsState as? UiState.Success)?.data.orEmpty()
    val returnedCount = focusLogs.count { it.outcome == FocusOutcome.RETURNED.name }
    val strictness = profile.strictnessEnum()

    val filteredApps = remember(installedApps, appSearch) {
        if (appSearch.isBlank()) installedApps
        else installedApps.filter {
            it.appName.contains(appSearch, ignoreCase = true) ||
                it.packageName.contains(appSearch, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Focus & Wellbeing",
                subtitle = "Gentle mindful interruption & digital restraint",
                icon = Icons.Default.Shield,
                trailing = {
                    PillBadge(
                        text = if (localPrefs.focusShieldActive) "Shield Active" else "Standby",
                        containerColor = if (localPrefs.focusShieldActive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (localPrefs.focusShieldActive) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            )
        }

        // Focus Shield Control
        item {
            SanctuaryCard(
                containerColor = if (localPrefs.focusShieldActive) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface
            ) {
                Text(
                    text = "Deep Sadhana & Study Focus Shield",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Current activity: $currentScheduleBlock",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(10.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(25, 45, 90).forEach { mins ->
                        FilterChip(
                            selected = selectedDuration == mins,
                            onClick = { selectedDuration = mins },
                            label = { Text("$mins min") }
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (localPrefs.focusShieldActive) {
                                viewModel.setFocusShieldActive(false, 0, currentScheduleBlock)
                                FocusMonitorService.stop(context)
                            } else {
                                viewModel.setFocusShieldActive(true, selectedDuration, currentScheduleBlock)
                                FocusMonitorService.start(context)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("focus_shield_toggle_button")
                    ) {
                        Icon(
                            if (localPrefs.focusShieldActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(if (localPrefs.focusShieldActive) "Stop Shield" else "Start ${selectedDuration}m Shield")
                    }

                    OutlinedButton(
                        onClick = {
                            val intent = Intent(context, FocusInterruptionActivity::class.java).apply {
                                putExtra(FocusInterruptionActivity.EXTRA_PKG, blockedPackages.firstOrNull() ?: "com.instagram.android")
                                putExtra(FocusInterruptionActivity.EXTRA_APP_NAME, "Distracting App")
                                putExtra(FocusInterruptionActivity.EXTRA_ACTIVITY, currentScheduleBlock)
                                putExtra(FocusInterruptionActivity.EXTRA_STRICTNESS, strictness.name)
                            }
                            context.startActivity(intent)
                        },
                        modifier = Modifier.testTag("preview_mindful_pause_button")
                    ) {
                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Preview Pause")
                    }
                }
            }
        }

        // Transparent Usage Access Permission Card
        item {
            SanctuaryCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (hasUsageAccess) "Usage Access Granted" else "Enable Usage Access",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Used strictly on-device to detect selected distracting apps during Focus or Bedtime and summarize today's screen time.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    if (hasUsageAccess) {
                        PillBadge(text = "Active")
                    } else {
                        Button(
                            onClick = { UsageStatsHelper.openUsageAccessSettings(context) },
                            modifier = Modifier.testTag("grant_usage_access_button")
                        ) {
                            Text("Allow")
                        }
                    }
                }
            }
        }

        // Strictness Mode Selector
        item {
            SanctuaryCard {
                SectionHeader(
                    title = "Intervention Strictness",
                    subtitle = "Choose how firmly the mindful pause holds space",
                    icon = Icons.Default.Security
                )
                Spacer(Modifier.height(8.dp))
                FocusStrictness.entries.forEach { level ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(level.label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text(
                                level.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        FilterChip(
                            selected = strictness == level,
                            onClick = { viewModel.updateFocusStrictness(level) },
                            label = { Text(if (strictness == level) "Selected" else "Select") }
                        )
                    }
                }
            }
        }

        // Bedtime Routine System
        item {
            val wrapTime = RoutineTemplates.subtractMinutes(profile.sleepTime, 30)
            val prepTime = RoutineTemplates.subtractMinutes(profile.sleepTime, 15)
            SanctuaryCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Bedtime, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("Bedtime Wind-Down System", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = "Protects Brahma Muhurta wake-up (${profile.sleepTime} rest target)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = localPrefs.bedtimeRemindersEnabled,
                        onCheckedChange = { enabled ->
                            viewModel.updateAlarmSettings(
                                wakeEnabled = localPrefs.wakeAlarmEnabled,
                                wakeTime = profile.wakeTime,
                                sleepTime = profile.sleepTime,
                                bedtimeEnabled = enabled,
                                gayatriEnabled = profile.gayatriInitiated,
                                gayatriM = profile.gayatriMorningTime,
                                gayatriA = profile.gayatriAfternoonTime,
                                gayatriE = profile.gayatriEveningTime,
                                onAlarmsSync = { AlarmScheduler.syncAllAlarms(context, it) }
                            )
                        },
                        modifier = Modifier.testTag("bedtime_winddown_switch")
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text("• $wrapTime — Finish evening activities & close distracting apps", style = MaterialTheme.typography.bodySmall)
                Text("• $prepTime — Prepare tomorrow's schedule & Ekadashi check", style = MaterialTheme.typography.bodySmall)
                Text("• ${profile.sleepTime} — Rest cleanly for morning Japa", style = MaterialTheme.typography.bodySmall)
            }
        }

        // Focus Stats & Screen Time Insights
        item {
            SanctuaryCard {
                SectionHeader(
                    title = "Wellbeing & Accountability",
                    subtitle = "$returnedCount mindful returns recorded",
                    icon = Icons.Default.Insights
                )
                Spacer(Modifier.height(8.dp))
                val todayMinutes = viewModel.currentTodayLog().focusMinutes
                Text(
                    text = "Today's Protected Focus: $todayMinutes min • Focus Decisions Logged: ${focusLogs.size}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
                val topUsed = usageMinutesMap.entries.sortedByDescending { it.value }.take(4)
                if (topUsed.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Today's Device Usage:", style = MaterialTheme.typography.labelLarge)
                    topUsed.forEach { (pkg, mins) ->
                        val label = installedApps.firstOrNull { it.packageName == pkg }?.appName ?: pkg
                        Text("• $label: $mins min", style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (focusLogs.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Recent Mindful Pause Decisions:", style = MaterialTheme.typography.labelLarge)
                    focusLogs.take(4).forEach { log ->
                        Text(
                            text = "• ${log.appName}: ${log.outcomeEnum().label}${if (log.userReason.isNotBlank()) " — \"${log.userReason}\"" else ""}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Distracting Apps Selector
        item {
            SanctuaryCard {
                SectionHeader(
                    title = "Distracting Applications (${blockedPackages.size})",
                    subtitle = "Select which apps trigger the Mindful Pause during Focus Shield",
                    icon = Icons.Default.Block
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = appSearch,
                    onValueChange = { appSearch = it },
                    label = { Text("Search installed apps") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("focus_app_search")
                )
            }
        }

        items(filteredApps.take(35), key = { it.packageName }) { app ->
            val isBlocked = app.packageName in blockedPackages
            SanctuaryCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(app.appName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = if (app.todayMinutes > 0) "${app.todayMinutes} min today • ${app.packageName}" else app.packageName,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = isBlocked,
                        onCheckedChange = {
                            viewModel.toggleBlockedApp(app.packageName, app.appName, isBlocked)
                        }
                    )
                }
            }
        }
    }
}
