package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.LocalAlarmFocusState
import com.example.data.model.DevotionalMediaCatalog
import com.example.data.model.DevotionalMediaCategory
import com.example.data.model.SadhanaDailyLog
import com.example.data.model.UserProfile
import com.example.media.AudioPlaybackState
import com.example.ui.components.PillBadge
import com.example.ui.components.SanctuaryCard
import com.example.ui.components.SectionHeader
import com.example.ui.viewmodel.SadhanaViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SadhanaScreen(
    viewModel: SadhanaViewModel,
    profile: UserProfile,
    todayLog: SadhanaDailyLog,
    recentLogs: List<SadhanaDailyLog>,
    localPrefs: LocalAlarmFocusState,
    audioState: AudioPlaybackState
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var showTargetDialog by remember { mutableStateOf(false) }
    var showSevaDialog by remember { mutableStateOf(false) }
    var selectedMediaFilter by remember { mutableStateOf<DevotionalMediaCategory?>(null) }

    fun openExternalUrl(url: String) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Japa Counter & 108 Bead Mala
        item {
            SectionHeader(
                title = "Sadhana Tracker",
                subtitle = "Chanting, reading, hearing, Gayatri & Seva",
                icon = Icons.Default.Spa,
                trailing = {
                    IconButton(onClick = { showTargetDialog = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Targets")
                    }
                }
            )
        }

        item {
            SanctuaryCard(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Hare Krishna Japa", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "${todayLog.roundsChanted} / ${profile.japaTargetRounds} rounds",
                            style = MaterialTheme.typography.displayMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Bead ${localPrefs.japaBeadCount} of 108",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    // Tactile 108-Bead Tap Ring
                    val ringPrimary = MaterialTheme.colorScheme.primary
                    val ringTrack = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                    Box(
                        modifier = Modifier
                            .size(116.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface)
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                viewModel.tapJapaBead()
                            }
                            .testTag("japa_bead_tap_circle"),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                            drawArc(
                                color = ringTrack,
                                startAngle = 0f,
                                sweepAngle = 360f,
                                useCenter = false,
                                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                            )
                            val sweep = (localPrefs.japaBeadCount / 108f) * 360f
                            drawArc(
                                color = ringPrimary,
                                startAngle = -90f,
                                sweepAngle = sweep,
                                useCenter = false,
                                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("TAP", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                            Text("${localPrefs.japaBeadCount}", style = MaterialTheme.typography.titleLarge)
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.incrementRounds(1) },
                        modifier = Modifier.weight(1f).testTag("japa_plus_1_button")
                    ) { Text("+1 Round") }
                    OutlinedButton(
                        onClick = { viewModel.incrementRounds(4) },
                        modifier = Modifier.weight(1f)
                    ) { Text("+4") }
                    IconButton(onClick = { viewModel.resetJapaBead() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset current mala beads")
                    }
                }
            }
        }

        // 2. Reading, Hearing, Mangal Aarti, Gayatri & Seva
        item {
            SanctuaryCard {
                Text("Devotional Practices", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))

                // Book Reading
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Book, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("Book Reading", style = MaterialTheme.typography.titleMedium)
                            Text("${todayLog.readingMinutes} / ${profile.readingTargetMinutes} min", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { viewModel.addReadingMinutes(15) }) { Text("+15m") }
                        OutlinedButton(onClick = { viewModel.addReadingMinutes(30) }) { Text("+30m") }
                    }
                }
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (todayLog.readingMinutes.toFloat() / profile.readingTargetMinutes.coerceAtLeast(1L)).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50))
                )

                Spacer(Modifier.height(16.dp))

                // Hearing Lectures
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Headphones, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("Hearing Lectures", style = MaterialTheme.typography.titleMedium)
                            Text("${todayLog.hearingMinutes} / ${profile.hearingTargetMinutes} min", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { viewModel.addHearingMinutes(15) }) { Text("+15m") }
                        OutlinedButton(onClick = { viewModel.addHearingMinutes(30) }) { Text("+30m") }
                    }
                }
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (todayLog.hearingMinutes.toFloat() / profile.hearingTargetMinutes.coerceAtLeast(1L)).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50))
                )

                Spacer(Modifier.height(14.dp))

                // Mangal Aarti + Seva
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = todayLog.mangalAartiAttended,
                            onCheckedChange = { viewModel.toggleMangalAarti() }
                        )
                        Text("Attended Mangal Aarti", style = MaterialTheme.typography.titleSmall)
                    }
                    OutlinedButton(onClick = { showSevaDialog = true }) {
                        Icon(Icons.Default.VolunteerActivism, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Seva: ${todayLog.sevaMinutes}m")
                    }
                }

                // Gayatri Check-ins for Initiated Devotees
                if (profile.gayatriInitiated) {
                    Spacer(Modifier.height(12.dp))
                    Text("Gayatri Sandhya Check-In", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = todayLog.gayatriMorningDone,
                            onClick = { viewModel.toggleGayatri(0) },
                            label = { Text("Morning (${profile.gayatriMorningTime})") }
                        )
                        FilterChip(
                            selected = todayLog.gayatriAfternoonDone,
                            onClick = { viewModel.toggleGayatri(1) },
                            label = { Text("Noon (${profile.gayatriAfternoonTime})") }
                        )
                        FilterChip(
                            selected = todayLog.gayatriEveningDone,
                            onClick = { viewModel.toggleGayatri(2) },
                            label = { Text("Evening (${profile.gayatriEveningTime})") }
                        )
                    }
                }
            }
        }

        // 3. Weekly Sadhana Analytics
        item {
            SanctuaryCard {
                Text("Weekly Chanting Report", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                val last7 = recentLogs.take(7).reversed()
                val avgRounds = if (last7.isEmpty()) 0 else last7.map { it.roundsChanted }.average().toInt()
                val totalMin = last7.sumOf { it.readingMinutes + it.hearingMinutes }
                Text(
                    "7-day average: $avgRounds rounds/day • $totalMin min reading & hearing",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(14.dp))
                val barColor = MaterialTheme.colorScheme.primary
                val goalColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)
                val maxRounds = maxOf(profile.japaTargetRounds.toFloat(), last7.maxOfOrNull { it.roundsChanted.toFloat() } ?: 16f, 16f)
                if (last7.isEmpty()) {
                    Text("Log today's rounds above to start your weekly chart.", style = MaterialTheme.typography.bodySmall)
                } else {
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                    ) {
                        val count = last7.size.coerceAtLeast(1)
                        val slotWidth = size.width / count
                        val barW = (slotWidth * 0.55f).coerceAtMost(32.dp.toPx())
                        val targetY = size.height * (1f - (profile.japaTargetRounds / maxRounds).coerceIn(0f, 1f))
                        drawLine(
                            color = goalColor,
                            start = Offset(0f, targetY),
                            end = Offset(size.width, targetY),
                            strokeWidth = 2.dp.toPx()
                        )
                        last7.forEachIndexed { idx, log ->
                            val ratio = (log.roundsChanted / maxRounds).coerceIn(0.05f, 1f)
                            val barH = size.height * ratio
                            val left = idx * slotWidth + (slotWidth - barW) / 2f
                            drawRect(
                                color = barColor,
                                topLeft = Offset(left, size.height - barH),
                                size = Size(barW, barH)
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        last7.forEach { log ->
                            Text(log.dateIso.takeLast(5), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        // 4. Devotional Media Section
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_kirtan_banner),
                    contentDescription = "Devotional Media Banner",
                    modifier = Modifier.fillMaxWidth().height(128.dp),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(128.dp)
                        .background(Brush.horizontalGradient(listOf(Color.Black.copy(alpha = 0.72f), Color.Transparent)))
                        .padding(18.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Column {
                        Text("Devotional Media", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                        Text(
                            "Ad-free offline mantra audio & authorized ISKCON broadcasts",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // Active Mini Audio Player
        if (audioState.activeItem != null) {
            item {
                val active = audioState.activeItem!!
                SanctuaryCard(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(active.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = if (audioState.isBuffering) "Connecting..."
                                else String.format("Playing • %02d:%02d", audioState.elapsedSeconds / 60, audioState.elapsedSeconds % 60),
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (!audioState.errorMessage.isNullOrBlank()) {
                                Text(audioState.errorMessage!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Row {
                            IconButton(onClick = { viewModel.audioPlayer.togglePlayPause() }) {
                                Icon(
                                    if (audioState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play or Pause"
                                )
                            }
                            IconButton(onClick = { viewModel.audioPlayer.stop() }) {
                                Icon(Icons.Default.Stop, contentDescription = "Stop")
                            }
                        }
                    }
                }
            }
        }

        // Media Category Filter Chips
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = selectedMediaFilter == null,
                    onClick = { selectedMediaFilter = null },
                    label = { Text("All") }
                )
                DevotionalMediaCategory.entries.forEach { cat ->
                    FilterChip(
                        selected = selectedMediaFilter == cat,
                        onClick = { selectedMediaFilter = if (selectedMediaFilter == cat) null else cat },
                        label = { Text(cat.label) }
                    )
                }
            }
        }

        val filteredMedia = DevotionalMediaCatalog.items.filter {
            selectedMediaFilter == null || it.category == selectedMediaFilter
        }
        items(filteredMedia, key = { it.id }) { item ->
            SanctuaryCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            PillBadge(text = item.category.label)
                            Text(item.durationLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(item.title, style = MaterialTheme.typography.titleMedium)
                        Text(item.speakerOrSource, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        Text(item.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = { viewModel.playDevotionalMedia(item, ::openExternalUrl) },
                        modifier = Modifier.testTag("play_media_${item.id}")
                    ) {
                        Icon(
                            imageVector = when {
                                item.isBuiltInOfflineAudio -> Icons.Default.PlayArrow
                                item.isLiveStream -> Icons.Default.LiveTv
                                else -> Icons.Default.OpenInNew
                            },
                            contentDescription = "Open or Play ${item.title}",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(16.dp)) }
    }

    if (showTargetDialog) {
        var rds by remember { mutableStateOf(profile.japaTargetRounds.toString()) }
        var readM by remember { mutableStateOf(profile.readingTargetMinutes.toString()) }
        var hearM by remember { mutableStateOf(profile.hearingTargetMinutes.toString()) }
        AlertDialog(
            onDismissRequest = { showTargetDialog = false },
            title = { Text("Customize Sadhana Targets") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = rds, onValueChange = { rds = it.filter(Char::isDigit) }, label = { Text("Daily Japa Rounds") })
                    OutlinedTextField(value = readM, onValueChange = { readM = it.filter(Char::isDigit) }, label = { Text("Reading Target (min)") })
                    OutlinedTextField(value = hearM, onValueChange = { hearM = it.filter(Char::isDigit) }, label = { Text("Hearing Target (min)") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.updateSadhanaTargets(
                        rds.toLongOrNull() ?: 16L,
                        readM.toLongOrNull() ?: 30L,
                        hearM.toLongOrNull() ?: 30L
                    )
                    showTargetDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showTargetDialog = false }) { Text("Cancel") } }
        )
    }

    if (showSevaDialog) {
        var mins by remember { mutableStateOf("30") }
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSevaDialog = false },
            title = { Text("Log Personal Seva") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = mins, onValueChange = { mins = it.filter(Char::isDigit) }, label = { Text("Minutes of Seva") })
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Seva description (e.g., Altar cleaning, Prasadam)") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.logSeva(mins.toLongOrNull() ?: 15L, note)
                    showSevaDialog = false
                }) { Text("Log Seva") }
            },
            dismissButton = { TextButton(onClick = { showSevaDialog = false }) { Text("Cancel") } }
        )
    }
}
