package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.alarms.WakeUpAlarmActivity
import com.example.calendar.VaishnavaCalendarEngine
import com.example.data.local.LocalAlarmFocusState
import com.example.data.model.DailyTask
import com.example.data.model.RoutineMode
import com.example.data.model.SadhanaDailyLog
import com.example.data.model.ScheduleCategory
import com.example.data.model.ScheduleItem
import com.example.data.model.TaskPriority
import com.example.data.model.TaskRepeatFrequency
import com.example.data.model.UserProfile
import com.example.data.model.WakeUpMethod
import com.example.data.model.WakeUpStatus
import com.example.ui.components.PillBadge
import com.example.ui.components.SanctuaryCard
import com.example.ui.components.SectionHeader
import com.example.ui.viewmodel.AiTaskState
import com.example.ui.viewmodel.SadhanaViewModel
import com.example.ui.viewmodel.UiState
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    viewModel: SadhanaViewModel,
    profile: UserProfile,
    scheduleState: UiState<List<ScheduleItem>>,
    tasksState: UiState<List<DailyTask>>,
    todayLog: SadhanaDailyLog,
    localPrefs: LocalAlarmFocusState,
    aiTaskState: AiTaskState,
    aiWakeState: AiTaskState,
    onOpenSadhanaTab: () -> Unit,
    onOpenCalendarTab: () -> Unit
) {
    val context = LocalContext.current
    val today = remember { LocalDate.now() }
    val todayIso = remember { today.toString() }
    val nowHhMm = remember { LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")) }

    val todayPanchanga = remember(profile.latitude, profile.longitude, profile.timezoneId, profile.calendarTradition) {
        val zone = runCatching { ZoneId.of(profile.timezoneId) }.getOrElse { ZoneId.systemDefault() }
        VaishnavaCalendarEngine.computeDay(today, profile.latitude, profile.longitude, zone, profile.traditionEnum())
    }

    var showAddScheduleDialog by remember { mutableStateOf(false) }
    var editingScheduleItem by remember { mutableStateOf<ScheduleItem?>(null) }
    var showAddTaskDialog by remember { mutableStateOf(false) }
    var showLateWakeDialog by remember { mutableStateOf(false) }
    var aiTaskPrompt by remember { mutableStateOf("") }

    val voiceTaskLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) aiTaskPrompt = spoken
        }
    }

    val scheduleItems = (scheduleState as? UiState.Success)?.data.orEmpty()
    val tasks = (tasksState as? UiState.Success)?.data.orEmpty()
    val nextActivity = scheduleItems.firstOrNull {
        !(it.completedToday && it.lastCompletedDate == todayIso) && it.endTime >= nowHhMm
    } ?: scheduleItems.firstOrNull { !(it.completedToday && it.lastCompletedDate == todayIso) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Dawn Hero & Vaishnava Day Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_hero_dawn),
                    contentDescription = "Morning Sadhana Sanctuary",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(175.dp),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(175.dp)
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.Black.copy(alpha = 0.25f),
                                    Color.Black.copy(alpha = 0.72f)
                                )
                            )
                        )
                        .padding(18.dp),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Column {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PillBadge(
                                text = "${todayPanchanga.masaName} • ${todayPanchanga.paksha} ${todayPanchanga.tithiName}",
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            if (todayPanchanga.isEkadashiFast) {
                                PillBadge(
                                    text = "Ekadashi Fast",
                                    containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Hare Krishna, ${profile.displayName}",
                            style = MaterialTheme.typography.headlineLarge,
                            color = Color.White
                        )
                        Text(
                            text = "Sunrise ${todayPanchanga.sunriseTime} • ${profile.routineModeEnum().label} Mode",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // Active Festival Mode Banner
        if (profile.activeFestivalMode.isNotBlank()) {
            item {
                SanctuaryCard(
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.75f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = "Festival Mode Active",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = profile.activeFestivalMode,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        TextButton(onClick = { viewModel.deactivateFestivalMode() }) {
                            Text("Exit")
                        }
                    }
                }
            }
        }

        // 2. Next Activity & Sadhana Quick Snapshot
        item {
            SanctuaryCard(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = "NEXT ON YOUR SCHEDULE",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(4.dp))
                        if (nextActivity != null) {
                            Text(
                                text = nextActivity.title,
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "${nextActivity.startTime} – ${nextActivity.endTime}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        } else {
                            Text("All scheduled items completed!", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                    Button(
                        onClick = onOpenSadhanaTab,
                        modifier = Modifier.testTag("home_open_japa_button")
                    ) {
                        Icon(Icons.Default.Spa, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("${todayLog.roundsChanted}/${profile.japaTargetRounds} Rds")
                    }
                }
                Spacer(Modifier.height(12.dp))
                val roundRatio = (todayLog.roundsChanted.toFloat() / profile.japaTargetRounds.coerceAtLeast(1L)).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { roundRatio },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(50))
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "Reading: ${todayLog.readingMinutes}/${profile.readingTargetMinutes}m",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "Hearing: ${todayLog.hearingMinutes}/${profile.hearingTargetMinutes}m",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        if (todayLog.mangalAartiAttended) "Mangal Aarti ✓" else "Mangal Aarti ○",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (todayLog.mangalAartiAttended) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // 3. Brahma Muhurta Wake-Up Check-in Card (customizable)
        if (localPrefs.showWakeUpCard) {
            item {
                SanctuaryCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                Icons.Default.WbTwilight,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Brahma Muhurta Wake-Up", style = MaterialTheme.typography.titleMedium)
                                val statusText = when (todayLog.wakeUpStatusEnum()) {
                                    WakeUpStatus.PENDING -> "Target: ${profile.wakeTime} • Tap to check in"
                                    else -> "${todayLog.wakeUpStatusEnum().label} at ${todayLog.wakeUpActualTime}"
                                }
                                Text(statusText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        if (todayLog.wakeUpStatusEnum() == WakeUpStatus.PENDING) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(
                                    onClick = { showLateWakeDialog = true },
                                    modifier = Modifier.height(44.dp)
                                ) {
                                    Text("Missed")
                                }
                                Button(
                                    onClick = {
                                        context.startActivity(Intent(context, WakeUpAlarmActivity::class.java))
                                    },
                                    modifier = Modifier
                                        .height(44.dp)
                                        .testTag("home_wakeup_checkin_button")
                                ) {
                                    Text("Check In")
                                }
                            }
                        } else {
                            PillBadge(text = todayLog.wakeUpMethodEnum().label)
                        }
                    }
                }
            }
        }

        // Ekadashi / Parana Alert Card
        if (todayPanchanga.isEkadashiFast || todayPanchanga.isParanaDay || todayPanchanga.festivals.isNotEmpty()) {
            item {
                SanctuaryCard(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                    modifier = Modifier.clickable { onOpenCalendarTab() }
                ) {
                    Text(
                        text = when {
                            todayPanchanga.isEkadashiFast -> "Ekadashi Today: ${todayPanchanga.ekadashiName}"
                            todayPanchanga.isParanaDay -> "Parana Window Today: ${todayPanchanga.paranaWindow}"
                            else -> todayPanchanga.festivals.first().title
                        },
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = todayPanchanga.festivals.firstOrNull()?.fastingNote
                            ?: "Break Ekadashi fast with grains during Parana window (${todayPanchanga.paranaWindow}).",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // 4. Routine Mode Switcher + Today's Schedule
        item {
            SectionHeader(
                title = "Today's Schedule",
                subtitle = "Essential spiritual blocks are protected",
                icon = Icons.Default.Schedule,
                trailing = {
                    IconButton(
                        onClick = { showAddScheduleDialog = true },
                        modifier = Modifier.testTag("home_add_schedule_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Schedule Block")
                    }
                }
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(top = 6.dp)
            ) {
                RoutineMode.entries.forEach { mode ->
                    FilterChip(
                        selected = profile.routineModeEnum() == mode,
                        onClick = { viewModel.switchRoutineMode(mode) },
                        label = { Text(mode.label) }
                    )
                }
            }
        }

        when (scheduleState) {
            UiState.Loading -> item {
                Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is UiState.Error -> item {
                Text(scheduleState.message, color = MaterialTheme.colorScheme.error)
            }
            is UiState.Success -> {
                items(scheduleItems, key = { it.id }) { item ->
                    val doneToday = item.completedToday && item.lastCompletedDate == todayIso
                    SanctuaryCard(
                        containerColor = if (doneToday) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                        else MaterialTheme.colorScheme.surface
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { viewModel.toggleScheduleCompleted(item) },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = if (doneToday) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = "Toggle ${item.title}",
                                    tint = if (doneToday) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${item.startTime}–${item.endTime}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    if (item.essential) {
                                        PillBadge(text = "Essential")
                                    }
                                }
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    textDecoration = if (doneToday) TextDecoration.LineThrough else TextDecoration.None
                                )
                                if (item.description.isNotBlank()) {
                                    Text(
                                        text = item.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            IconButton(onClick = { editingScheduleItem = item }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit timing", modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = { viewModel.deleteScheduleBlock(item.id) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Remove block", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        // 5. Personal Task Manager + Gemini Natural Language Quick Add
        item {
            Spacer(Modifier.height(6.dp))
            SectionHeader(
                title = "Personal Tasks",
                subtitle = "Manual or natural-language Gemini tasks",
                icon = Icons.Default.Alarm,
                trailing = {
                    Button(
                        onClick = { showAddTaskDialog = true },
                        modifier = Modifier.testTag("home_add_task_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Text(" New Task")
                    }
                }
            )
            Spacer(Modifier.height(8.dp))
            SanctuaryCard {
                Text("Add task in natural language with Gemini", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = aiTaskPrompt,
                        onValueChange = { aiTaskPrompt = it },
                        placeholder = { Text("e.g., Buy tulasi flowers tomorrow 7 AM high priority") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            }
                            runCatching { voiceTaskLauncher.launch(intent) }
                        }
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Voice Input")
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    when (aiTaskState) {
                        AiTaskState.Loading -> CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        is AiTaskState.Success -> Text(aiTaskState.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                        is AiTaskState.Error -> Text(aiTaskState.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, modifier = Modifier.weight(1f))
                        AiTaskState.Idle -> Spacer(Modifier.weight(1f))
                    }
                    Button(
                        onClick = {
                            if (aiTaskPrompt.isNotBlank()) {
                                viewModel.createTaskWithAi(aiTaskPrompt)
                                aiTaskPrompt = ""
                            }
                        },
                        enabled = aiTaskPrompt.isNotBlank() && aiTaskState !is AiTaskState.Loading,
                        modifier = Modifier.testTag("home_ai_task_submit")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Create")
                    }
                }
            }
        }

        if (tasks.isEmpty()) {
            item {
                SanctuaryCard {
                    Text(
                        "No personal tasks yet. Tap 'New Task' or ask Gemini above.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(tasks, key = { it.id }) { task ->
                SanctuaryCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = task.completed,
                            onCheckedChange = { viewModel.toggleTaskCompleted(task) }
                        )
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = task.title,
                                style = MaterialTheme.typography.titleMedium,
                                textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None
                            )
                            Text(
                                text = listOfNotNull(
                                    task.dateIso,
                                    task.startTime.takeIf { it.isNotBlank() },
                                    task.repeatEnum().label,
                                    "${task.priorityEnum().label} Priority"
                                ).joinToString(" • "),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { viewModel.deleteTask(task.id) }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Task")
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(16.dp)) }
    }

    // Add Schedule Block Dialog
    if (showAddScheduleDialog) {
        var title by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var start by remember { mutableStateOf("17:00") }
        var end by remember { mutableStateOf("18:00") }
        var cat by remember { mutableStateOf(ScheduleCategory.SEVA) }
        var essential by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAddScheduleDialog = false },
            title = { Text("Add Schedule Block") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Activity Title") }, singleLine = true)
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Notes") })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = start, onValueChange = { start = it.take(5) }, label = { Text("Start HH:mm") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = end, onValueChange = { end = it.take(5) }, label = { Text("End HH:mm") }, modifier = Modifier.weight(1f))
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ScheduleCategory.entries.forEach { c ->
                            FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c.label) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Essential Spiritual Commitment")
                        Switch(checked = essential, onCheckedChange = { essential = it })
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (title.isNotBlank()) {
                        viewModel.addScheduleBlock(title, desc, start, end, cat, essential)
                        showAddScheduleDialog = false
                    }
                }) { Text("Add") }
            },
            dismissButton = {
                TextButton(onClick = { showAddScheduleDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Edit Schedule Timings Dialog
    if (editingScheduleItem != null) {
        val target = editingScheduleItem!!
        var newStart by remember(target.id) { mutableStateOf(target.startTime) }
        var newEnd by remember(target.id) { mutableStateOf(target.endTime) }
        AlertDialog(
            onDismissRequest = { editingScheduleItem = null },
            title = { Text("Reschedule ${target.title}") },
            text = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = newStart, onValueChange = { newStart = it.take(5) }, label = { Text("Start HH:mm") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = newEnd, onValueChange = { newEnd = it.take(5) }, label = { Text("End HH:mm") }, modifier = Modifier.weight(1f))
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.updateScheduleTimes(target, newStart, newEnd)
                    editingScheduleItem = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { editingScheduleItem = null }) { Text("Cancel") }
            }
        )
    }

    // Add Manual Task Dialog
    if (showAddTaskDialog) {
        var title by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var dateIso by remember { mutableStateOf(todayIso) }
        var start by remember { mutableStateOf("09:00") }
        var end by remember { mutableStateOf("10:00") }
        var repeat by remember { mutableStateOf(TaskRepeatFrequency.ONCE) }
        var priority by remember { mutableStateOf(TaskPriority.MEDIUM) }

        AlertDialog(
            onDismissRequest = { showAddTaskDialog = false },
            title = { Text("New Personal Task") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true)
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") })
                    OutlinedTextField(value = dateIso, onValueChange = { dateIso = it.take(10) }, label = { Text("Date (yyyy-MM-dd)") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = start, onValueChange = { start = it.take(5) }, label = { Text("Start") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = end, onValueChange = { end = it.take(5) }, label = { Text("End") }, modifier = Modifier.weight(1f))
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TaskRepeatFrequency.entries.forEach { r ->
                            FilterChip(selected = repeat == r, onClick = { repeat = r }, label = { Text(r.label) })
                        }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TaskPriority.entries.forEach { p ->
                            FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(p.label) })
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (title.isNotBlank()) {
                        viewModel.addManualTask(title, desc, dateIso, start, end, repeat, priority)
                        showAddTaskDialog = false
                    }
                }) { Text("Save Task") }
            },
            dismissButton = {
                TextButton(onClick = { showAddTaskDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Missed / Late Wake-Up Reflection Dialog with Gemini
    if (showLateWakeDialog) {
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showLateWakeDialog = false },
            title = { Text("Morning Reflection") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("No judgement! Record what made waking at ${profile.wakeTime} difficult, and optionally ask Gemini for gentle adjustments tonight.")
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("What happened? (e.g., slept late, tired)") },
                        minLines = 2
                    )
                    when (aiWakeState) {
                        AiTaskState.Loading -> CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        is AiTaskState.Success -> Text(aiWakeState.message, style = MaterialTheme.typography.bodySmall)
                        is AiTaskState.Error -> Text(aiWakeState.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        AiTaskState.Idle -> {}
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.recordQuickWakeCheckIn(WakeUpMethod.MANTRA_CHECKIN, WakeUpStatus.LATE, note)
                    viewModel.analyzeMissedWakeUpWithAi(nowHhMm, note)
                }) { Text("Save & Ask Gemini") }
            },
            dismissButton = {
                TextButton(onClick = {
                    viewModel.recordQuickWakeCheckIn(WakeUpMethod.NONE, WakeUpStatus.MISSED, note)
                    showLateWakeDialog = false
                }) { Text("Record & Close") }
            }
        )
    }
}
