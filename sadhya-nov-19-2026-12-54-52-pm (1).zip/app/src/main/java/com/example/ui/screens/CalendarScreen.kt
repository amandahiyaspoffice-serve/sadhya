package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AddTask
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.calendar.IcsCalendarParser
import com.example.calendar.SacredCityPreset
import com.example.calendar.VaishnavaCalendarEngine
import com.example.calendar.VaishnavaDayInfo
import com.example.data.model.CalendarTradition
import com.example.data.model.UserProfile
import com.example.ui.components.PillBadge
import com.example.ui.components.SanctuaryCard
import com.example.ui.components.SectionHeader
import com.example.ui.viewmodel.SadhanaViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CalendarScreen(
    viewModel: SadhanaViewModel,
    profile: UserProfile
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val importedEvents by viewModel.importedCalendarEventsState.collectAsStateWithLifecycle()

    var showLocationDialog by remember { mutableStateOf(false) }
    var locationNotice by remember { mutableStateOf<String?>(null) }

    val tradition = profile.traditionEnum()
    val monthDays = remember(selectedMonth, profile.latitude, profile.longitude, profile.timezoneId, tradition) {
        VaishnavaCalendarEngine.computeMonth(
            year = selectedMonth.year,
            month = selectedMonth.monthValue,
            latitude = profile.latitude,
            longitude = profile.longitude,
            timezoneId = profile.timezoneId,
            tradition = tradition
        )
    }

    val selectedDayInfo = remember(selectedDate, monthDays, profile.latitude, profile.longitude, profile.timezoneId, tradition) {
        monthDays.firstOrNull { it.date == selectedDate }
            ?: VaishnavaCalendarEngine.computeDay(
                selectedDate,
                profile.latitude,
                profile.longitude,
                runCatching { java.time.ZoneId.of(profile.timezoneId) }.getOrElse { java.time.ZoneId.systemDefault() },
                tradition
            )
    }

    val importedForSelectedDate = remember(importedEvents, selectedDate) {
        val iso = selectedDate.toString()
        importedEvents.filter { it.dateIso == iso }
    }

    val upcomingObservances = remember(monthDays) {
        monthDays.filter { it.isEkadashiFast || it.festivals.isNotEmpty() || it.isParanaDay }
    }

    val coarseLocationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            scope.launch {
                val detected = withContext(Dispatchers.IO) {
                    VaishnavaCalendarEngine.detectCoarseLocation(context)
                }
                if (detected != null) {
                    viewModel.updateCalendarLocationAndTradition(detected, tradition)
                    locationNotice = "Calibrated for ${detected.name}"
                } else {
                    locationNotice = "GPS location unavailable right now — please select a city preset."
                }
            }
        } else {
            locationNotice = "Location permission declined. You can select any sacred city preset manually."
        }
    }

    val icsPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val parsed = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    }.getOrNull()?.let { text ->
                        IcsCalendarParser.parseIcsStream(text, "Imported .ics")
                    }.orEmpty()
                }
                if (parsed.isNotEmpty()) {
                    viewModel.saveImportedIcsEvents(parsed)
                } else {
                    locationNotice = "No VEVENT entries found in selected .ics file."
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header + Location & Tradition Card
        item {
            SectionHeader(
                title = "Vaishnava Calendar",
                subtitle = "${profile.locationName} • ${tradition.label}",
                icon = Icons.Default.CalendarMonth,
                trailing = {
                    TextButton(
                        onClick = { viewModel.selectDate(LocalDate.now()) },
                        modifier = Modifier.testTag("calendar_today_button")
                    ) {
                        Text("Today")
                    }
                }
            )
        }

        item {
            SanctuaryCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = profile.locationName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            text = "Timezone: ${profile.timezoneId}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = {
                                if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                                    scope.launch {
                                        val detected = withContext(Dispatchers.IO) {
                                            VaishnavaCalendarEngine.detectCoarseLocation(context)
                                        }
                                        if (detected != null) {
                                            viewModel.updateCalendarLocationAndTradition(detected, tradition)
                                            locationNotice = "Calibrated for ${detected.name}"
                                        } else {
                                            locationNotice = "Last location unavailable — choose a city preset."
                                        }
                                    }
                                } else {
                                    coarseLocationLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                                }
                            },
                            modifier = Modifier.testTag("calendar_gps_button")
                        ) {
                            Icon(Icons.Default.MyLocation, contentDescription = "Detect device location")
                        }
                        OutlinedButton(
                            onClick = { showLocationDialog = true },
                            modifier = Modifier.testTag("calendar_city_button")
                        ) {
                            Text("City")
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text("Calendar Tradition", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CalendarTradition.entries.forEach { t ->
                        FilterChip(
                            selected = tradition == t,
                            onClick = {
                                viewModel.updateCalendarLocationAndTradition(
                                    SacredCityPreset(
                                        profile.locationName,
                                        profile.latitude,
                                        profile.longitude,
                                        profile.timezoneId
                                    ),
                                    t
                                )
                            },
                            label = { Text(t.label) }
                        )
                    }
                }
                if (locationNotice != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = locationNotice!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Monthly Calendar Grid
        item {
            SanctuaryCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.navigateMonth(-1) },
                        modifier = Modifier.testTag("calendar_prev_month")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous month")
                    }
                    Text(
                        text = "${selectedMonth.month.getDisplayName(TextStyle.FULL, Locale.getDefault())} ${selectedMonth.year}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    IconButton(
                        onClick = { viewModel.navigateMonth(1) },
                        modifier = Modifier.testTag("calendar_next_month")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next month")
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Weekday headers Sun..Sat
                val weekHeaders = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
                Row(modifier = Modifier.fillMaxWidth()) {
                    weekHeaders.forEach { dayName ->
                        Text(
                            text = dayName,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))

                val firstOfMonth = selectedMonth.atDay(1)
                val leadingBlanks = when (firstOfMonth.dayOfWeek) {
                    DayOfWeek.SUNDAY -> 0
                    DayOfWeek.MONDAY -> 1
                    DayOfWeek.TUESDAY -> 2
                    DayOfWeek.WEDNESDAY -> 3
                    DayOfWeek.THURSDAY -> 4
                    DayOfWeek.FRIDAY -> 5
                    DayOfWeek.SATURDAY -> 6
                }
                val cells: List<VaishnavaDayInfo?> = List(leadingBlanks) { null } + monthDays
                val rows = cells.chunked(7)
                val today = LocalDate.now()

                rows.forEach { week ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (col in 0 until 7) {
                            val dayInfo = week.getOrNull(col)
                            if (dayInfo == null) {
                                Spacer(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                )
                            } else {
                                val isSelected = dayInfo.date == selectedDate
                                val isToday = dayInfo.date == today
                                val hasFestival = dayInfo.festivals.any { !it.isEkadashi }
                                val hasImported = importedEvents.any { it.dateIso == dayInfo.date.toString() }

                                val bgColor = when {
                                    isSelected -> MaterialTheme.colorScheme.primary
                                    dayInfo.isEkadashiFast -> MaterialTheme.colorScheme.secondaryContainer
                                    hasFestival -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
                                    else -> Color.Transparent
                                }
                                val textColor = when {
                                    isSelected -> MaterialTheme.colorScheme.onPrimary
                                    dayInfo.isEkadashiFast -> MaterialTheme.colorScheme.onSecondaryContainer
                                    else -> MaterialTheme.colorScheme.onSurface
                                }

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(bgColor)
                                        .then(
                                            if (isToday && !isSelected) {
                                                Modifier.border(
                                                    1.5.dp,
                                                    MaterialTheme.colorScheme.primary,
                                                    RoundedCornerShape(12.dp)
                                                )
                                            } else Modifier
                                        )
                                        .clickable { viewModel.selectDate(dayInfo.date) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = dayInfo.date.dayOfMonth.toString(),
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = if (isSelected || isToday || dayInfo.isEkadashiFast) FontWeight.Bold else FontWeight.Normal,
                                            color = textColor
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                            if (dayInfo.isEkadashiFast) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.secondary)
                                                )
                                            }
                                            if (hasFestival || hasImported) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(5.dp)
                                                        .clip(CircleShape)
                                                        .background(if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary)
                                                )
                                            }
                                            if (dayInfo.isParanaDay) {
                                                Text(
                                                    text = "P",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.tertiary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LegendDot(MaterialTheme.colorScheme.secondary, "Ekadashi Fast")
                    LegendDot(MaterialTheme.colorScheme.primary, "Festival / Observance")
                    Text("P = Parana", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
                }
            }
        }

        // Selected Day Details Card
        item {
            SanctuaryCard {
                if (selectedDayInfo.isEkadashiFast || selectedDayInfo.festivals.isNotEmpty() || selectedDayInfo.isKartikMonth) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .clip(RoundedCornerShape(16.dp))
                    ) {
                        Image(
                            painter = painterResource(R.drawable.img_festival_art),
                            contentDescription = "Vaishnava observance banner",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = selectedDayInfo.ekadashiName
                                    ?: selectedDayInfo.festivals.firstOrNull()?.title
                                    ?: "Sacred Damodara / Kartik Day",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }

                val formattedDate = selectedDayInfo.date.format(DateTimeFormatter.ofPattern("EEEE, d MMM yyyy"))
                Text(
                    text = formattedDate,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "${selectedDayInfo.masaName} Masa • ${selectedDayInfo.paksha} Paksha • ${selectedDayInfo.tithiName}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium
                )

                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PillBadge(text = "Sunrise ${selectedDayInfo.sunriseTime}")
                    PillBadge(
                        text = "Sunset ${selectedDayInfo.sunsetTime}",
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }

                if (selectedDayInfo.chaturmasyaPhase != null) {
                    Spacer(Modifier.height(10.dp))
                    PillBadge(
                        text = selectedDayInfo.chaturmasyaPhase,
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                        contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }

                if (selectedDayInfo.isParanaDay && selectedDayInfo.paranaWindow != null) {
                    Spacer(Modifier.height(12.dp))
                    SanctuaryCard(
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.WbSunny, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Ekadashi Parana Window",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Break fast between ${selectedDayInfo.paranaWindow} (${profile.locationName})",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }

                if (selectedDayInfo.festivals.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    selectedDayInfo.festivals.forEach { fest ->
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text(
                                text = fest.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = fest.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Observance: ${fest.fastingNote}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                    }
                }

                if (importedForSelectedDate.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Imported Calendar Events", style = MaterialTheme.typography.labelLarge)
                    importedForSelectedDate.forEach { ev ->
                        Text(
                            text = "• ${ev.title} ${if (ev.paranaInfo.isNotBlank()) "(${ev.paranaInfo})" else ""}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                val primaryEventTitle = selectedDayInfo.ekadashiName
                    ?: selectedDayInfo.festivals.firstOrNull()?.title
                    ?: "${selectedDayInfo.masaName} ${selectedDayInfo.tithiName} Sadhana"
                val primaryEventNote = selectedDayInfo.festivals.firstOrNull()?.fastingNote
                    ?: selectedDayInfo.paranaWindow?.let { "Parana window: $it" }
                    ?: "Sunrise ${selectedDayInfo.sunriseTime}"

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.addCalendarEventToSchedule(
                                selectedDayInfo,
                                primaryEventTitle,
                                primaryEventNote
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("calendar_add_to_schedule_button")
                    ) {
                        Icon(Icons.Default.AddTask, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Add to Schedule")
                    }

                    val festivalModeCandidate = selectedDayInfo.ekadashiName
                        ?: selectedDayInfo.festivals.firstOrNull()?.title
                        ?: if (selectedDayInfo.isKartikMonth) "Kartik / Damodara" else ""
                    if (festivalModeCandidate.isNotBlank()) {
                        val isAlreadyActive = profile.activeFestivalMode == festivalModeCandidate
                        OutlinedButton(
                            onClick = {
                                if (isAlreadyActive) viewModel.deactivateFestivalMode()
                                else viewModel.activateFestivalMode(festivalModeCandidate)
                            },
                            modifier = Modifier.testTag("calendar_festival_mode_button")
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(if (isAlreadyActive) "Exit Mode" else "Festival Mode")
                        }
                    }
                }
            }
        }

        // External Vaishnava Calendar & .ics Import Card
        item {
            SanctuaryCard {
                SectionHeader(
                    title = "Calendar Sync & .ICS Import",
                    subtitle = "Import GCal / temple .ics exports or launch Vaishnava Calendar",
                    icon = Icons.Default.EventAvailable
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { icsPickerLauncher.launch(arrayOf("text/calendar", "*/*")) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("calendar_import_ics_button")
                    ) {
                        Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Import .ICS")
                    }
                    OutlinedButton(
                        onClick = { IcsCalendarParser.launchExternalVaishnavaCalendar(context) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("calendar_open_external_button")
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Vaishnava Cal")
                    }
                }
                if (importedEvents.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "${importedEvents.size} imported .ics calendar events active locally.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Upcoming Monthly Observances
        item {
            SectionHeader(
                title = "This Month's Observances",
                subtitle = "Tap any Ekadashi, Parana, or festival to view details",
                icon = Icons.Default.WbTwilight
            )
        }

        items(upcomingObservances, key = { it.date.toString() }) { day ->
            SanctuaryCard(
                modifier = Modifier.clickable { viewModel.selectDate(day.date) },
                containerColor = if (day.date == selectedDate) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f) else MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        val title = buildString {
                            if (day.ekadashiName != null) append(day.ekadashiName)
                            val nonEk = day.festivals.filterNot { it.isEkadashi }
                            if (nonEk.isNotEmpty()) {
                                if (isNotEmpty()) append(" • ")
                                append(nonEk.joinToString { it.title })
                            }
                            if (day.isParanaDay) {
                                if (isNotEmpty()) append(" • ")
                                append("Parana (${day.paranaWindow})")
                            }
                        }
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${day.date.format(DateTimeFormatter.ofPattern("EEE, MMM d"))} • ${day.masaName} ${day.paksha} ${day.tithiName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (day.isEkadashiFast) {
                        PillBadge(
                            text = "Ekadashi",
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    } else if (day.isParanaDay) {
                        PillBadge(
                            text = "Parana",
                            containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                            contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                }
            }
        }
    }

    if (showLocationDialog) {
        AlertDialog(
            onDismissRequest = { showLocationDialog = false },
            title = { Text("Select Location & Timezone") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Sunrise, Arunodaya Ekadashi, and Parana windows adjust automatically to your chosen city.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    VaishnavaCalendarEngine.cityPresets.forEach { preset ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    viewModel.updateCalendarLocationAndTradition(preset, tradition)
                                    showLocationDialog = false
                                }
                                .padding(horizontal = 10.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(preset.name, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    preset.timezoneId,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (preset.name == profile.locationName) {
                                PillBadge(text = "Active")
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLocationDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(5.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
