package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.data.model.DarkModePreference
import com.example.data.model.FontScaleLevel
import com.example.data.model.ThemeStyle

private val IvoryMaroonLight = lightColorScheme(
    primary = DeepMaroonPrimary,
    onPrimary = Color.White,
    primaryContainer = MaroonContainer,
    onPrimaryContainer = OnMaroonContainer,
    secondary = SaffronSecondary,
    onSecondary = Color.White,
    secondaryContainer = SaffronContainer,
    onSecondaryContainer = OnSaffronContainer,
    tertiary = SacredGoldTertiary,
    onTertiary = Color.White,
    tertiaryContainer = GoldContainer,
    onTertiaryContainer = CharcoalUmber,
    background = IvoryBackground,
    onBackground = CharcoalUmber,
    surface = ParchmentSurface,
    onSurface = CharcoalUmber,
    surfaceVariant = WarmSandVariant,
    onSurfaceVariant = MutedUmber,
    outline = SoftOutline
)

private val IvoryMaroonDark = darkColorScheme(
    primary = LuminousGoldPrimary,
    onPrimary = Color(0xFF281800),
    primaryContainer = NightMaroonContainer,
    onPrimaryContainer = Color(0xFFFFD9DE),
    secondary = SoftRoseSecondary,
    onSecondary = Color(0xFF3E0B14),
    secondaryContainer = NightSaffronContainer,
    onSecondaryContainer = Color(0xFFFFDCBE),
    tertiary = TulasiLight,
    onTertiary = Color(0xFF0A2E14),
    tertiaryContainer = Color(0xFF204529),
    onTertiaryContainer = Color(0xFFC8F0D0),
    background = NightUmberBackground,
    onBackground = NightTextPrimary,
    surface = NightPlumSurface,
    onSurface = NightTextPrimary,
    surfaceVariant = NightSurfaceVariant,
    onSurfaceVariant = NightTextMuted,
    outline = NightOutline
)

private val SaffronSandLight = IvoryMaroonLight.copy(
    primary = SandSaffronPrimary,
    primaryContainer = SandSaffronContainer,
    onPrimaryContainer = OnSaffronContainer,
    secondary = SandGoldSecondary
)

private val SaffronSandDark = IvoryMaroonDark.copy(
    primary = SandDarkPrimary,
    primaryContainer = NightSaffronContainer
)

private val VrindavanForestLight = IvoryMaroonLight.copy(
    primary = VrindavanGreenPrimary,
    primaryContainer = VrindavanContainer,
    onPrimaryContainer = Color(0xFF0E2917),
    secondary = VrindavanSaffronSecondary
)

private val VrindavanForestDark = IvoryMaroonDark.copy(
    primary = VrindavanDarkPrimary,
    primaryContainer = Color(0xFF1A3A25)
)

val SadhanaShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun SadhanaTheme(
    themeStyle: ThemeStyle = ThemeStyle.IVORY_MAROON,
    darkModePreference: DarkModePreference = DarkModePreference.SYSTEM,
    fontScaleLevel: FontScaleLevel = FontScaleLevel.NORMAL,
    content: @Composable () -> Unit
) {
    val isDark = when (darkModePreference) {
        DarkModePreference.SYSTEM -> isSystemInDarkTheme()
        DarkModePreference.LIGHT -> false
        DarkModePreference.DARK -> true
    }

    val colorScheme: ColorScheme = when (themeStyle) {
        ThemeStyle.IVORY_MAROON -> if (isDark) IvoryMaroonDark else IvoryMaroonLight
        ThemeStyle.SAFFRON_SAND -> if (isDark) SaffronSandDark else SaffronSandLight
        ThemeStyle.VRINDAVAN_FOREST -> if (isDark) VrindavanForestDark else VrindavanForestLight
    }

    val scaleFactor = when (fontScaleLevel) {
        FontScaleLevel.COMPACT -> 0.92f
        FontScaleLevel.NORMAL -> 1.0f
        FontScaleLevel.LARGE -> 1.14f
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = buildSadhanaTypography(scaleFactor),
        shapes = SadhanaShapes,
        content = content
    )
}
