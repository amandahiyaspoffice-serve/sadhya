package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.FocusStrictness
import com.example.data.model.RoutineMode
import com.example.data.model.UserProfile
import com.example.focus.UsageStatsHelper
import com.example.ui.components.SanctuaryCard
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    initialProfile: UserProfile,
    onComplete: (UserProfile) -> Unit,
    onSkipAll: () -> Unit
) {
    var step by remember { mutableIntStateOf(0) }
    val totalSteps = 10

    var selectedMode by remember { mutableStateOf(initialProfile.routineModeEnum()) }
    var wakeTime by remember { mutableStateOf(initialProfile.wakeTime) }
    var sleepTime by remember { mutableStateOf(initialProfile.sleepTime) }
    var japaRounds by remember { mutableIntStateOf(initialProfile.japaTargetRounds.toInt()) }
    var readingMinutes by remember { mutableIntStateOf(initialProfile.readingTargetMinutes.toInt()) }
    var hearingMinutes by remember { mutableIntStateOf(initialProfile.hearingTargetMinutes.toInt()) }
    var onlineMangalAarti by remember { mutableStateOf(initialProfile.attendOnlineMangalAarti) }
    var gayatriInitiated by remember { mutableStateOf(initialProfile.gayatriInitiated) }
    var gayatriM by remember { mutableStateOf(initialProfile.gayatriMorningTime) }
    var gayatriA by remember { mutableStateOf(initialProfile.gayatriAfternoonTime) }
    var gayatriE by remember { mutableStateOf(initialProfile.gayatriEveningTime) }
    var responsibilitiesText by remember { mutableStateOf(initialProfile.responsibilities.joinToString(", ")) }
    val distractingApps = remember {
        mutableStateListOf<String>().apply { addAll(initialProfile.distractingPackages) }
    }
    var strictness by remember { mutableStateOf(initialProfile.strictnessEnum()) }

    fun buildResultProfile(): UserProfile {
        val respList = responsibilitiesText.split(",")
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .take(15)
        return initialProfile.copy(
            routineMode = selectedMode.name,
            wakeTime = wakeTime,
            sleepTime = sleepTime,
            japaTargetRounds = japaRounds.toLong(),
            readingTargetMinutes = readingMinutes.toLong(),
            hearingTargetMinutes = hearingMinutes.toLong(),
            attendOnlineMangalAarti = onlineMangalAarti,
            gayatriInitiated = gayatriInitiated,
            gayatriMorningTime = gayatriM,
            gayatriAfternoonTime = gayatriA,
            gayatriEveningTime = gayatriE,
            responsibilities = respList,
            distractingPackages = distractingApps.toList(),
            focusStrictness = strictness.name,
            onboardingCompleted = true
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(modifier = Modifier.widthIn(max = 580.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Step ${step + 1} of $totalSteps",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                TextButton(
                    onClick = onSkipAll,
                    modifier = Modifier.testTag("onboarding_skip_all")
                ) {
                    Text("Complete Later")
                }
            }

            LinearProgressIndicator(
                progress = { (step + 1) / totalSteps.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(50))
            )

            Spacer(Modifier.height(16.dp))

            if (step == 0) {
                Image(
                    painter = painterResource(id = R.drawable.img_hero_dawn),
                    contentDescription = "Welcome to Sadhya",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(20.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(Modifier.height(16.dp))
            }

            SanctuaryCard {
                when (step) {
                    0 -> {
                        Text(
                            "1. Which lifestyle best describes you?",
                            style = MaterialTheme.typography.headlineMedium
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "You can switch modes or customize every activity anytime.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(14.dp))
                        val options = listOf(
                            Triple("ISKCON Temple Resident / Brahmachari", RoutineMode.TEMPLE_RESIDENT, "4:30 AM Mangal Aarti, Tulasi Puja, Seva"),
                            Triple("Congregational Devotee (Grihastha)", RoutineMode.CONGREGATIONAL, "Balance Sadhana, family & work"),
                            Triple("Student", RoutineMode.STUDENT_PRO, "Balance Sadhana, classes, study & exercise"),
                            Triple("Working Professional", RoutineMode.STUDENT_PRO, "Balance Sadhana, office & wellness")
                        )
                        options.forEach { (label, mode, desc) ->
                            val isSelected = selectedMode == mode &&
                                ((label.startsWith("Student") && responsibilitiesText.contains("Study", true)) ||
                                    !label.startsWith("Student") || selectedMode == RoutineMode.STUDENT_PRO)
                            SanctuaryCard(
                                modifier = Modifier
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        selectedMode = mode
                                        if (label == "Student" && responsibilitiesText.isBlank()) {
                                            responsibilitiesText = "Classes, Study, Exercise"
                                        } else if (label == "Working Professional" && responsibilitiesText.isBlank()) {
                                            responsibilitiesText = "Office Work, Exercise"
                                        }
                                    },
                                containerColor = if (selectedMode == mode) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                                else MaterialTheme.colorScheme.surface
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(label, style = MaterialTheme.typography.titleMedium)
                                        Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    if (selectedMode == mode) {
                                        Icon(Icons.Default.Check, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        Text("2. What time do you prefer waking up?", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        Text("Brahma Muhurta begins ~96 minutes before sunrise.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(14.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("03:45", "04:00", "04:30", "05:00", "05:30", "06:00").forEach { t ->
                                FilterChip(
                                    selected = wakeTime == t,
                                    onClick = { wakeTime = t },
                                    label = { Text(t) }
                                )
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = wakeTime,
                            onValueChange = { wakeTime = it.take(5) },
                            label = { Text("Custom wake time (HH:mm)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    2 -> {
                        Text("3. What time do you prefer sleeping?", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        Text("We will build a calm 30-minute wind-down before bedtime.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(14.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("21:00", "21:30", "22:00", "22:30", "23:00").forEach { t ->
                                FilterChip(
                                    selected = sleepTime == t,
                                    onClick = { sleepTime = t },
                                    label = { Text(t) }
                                )
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = sleepTime,
                            onValueChange = { sleepTime = it.take(5) },
                            label = { Text("Custom bedtime (HH:mm)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    3 -> {
                        Text("4. How many rounds do you want to chant daily?", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "$japaRounds rounds / day",
                            style = MaterialTheme.typography.displayMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Slider(
                            value = japaRounds.toFloat(),
                            onValueChange = { japaRounds = it.roundToInt() },
                            valueRange = 1f..32f,
                            steps = 30
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(1, 4, 8, 12, 16, 24).forEach { r ->
                                FilterChip(selected = japaRounds == r, onClick = { japaRounds = r }, label = { Text("$r rounds") })
                            }
                        }
                    }

                    4 -> {
                        Text("5. Daily devotional reading & hearing?", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(12.dp))
                        Text("Book reading: $readingMinutes min / day", style = MaterialTheme.typography.titleMedium)
                        Slider(
                            value = readingMinutes.toFloat(),
                            onValueChange = { readingMinutes = (it / 5).roundToInt() * 5 },
                            valueRange = 10f..120f
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Hearing lectures: $hearingMinutes min / day", style = MaterialTheme.typography.titleMedium)
                        Slider(
                            value = hearingMinutes.toFloat(),
                            onValueChange = { hearingMinutes = (it / 5).roundToInt() * 5 },
                            valueRange = 10f..120f
                        )
                    }

                    5 -> {
                        Text("6. Do you want to attend Mangal Aarti online?", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        Text("We will include Mayapur TV / Mangal Aarti in your morning block.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Attend Mangal Aarti Online", style = MaterialTheme.typography.titleMedium)
                            Switch(checked = onlineMangalAarti, onCheckedChange = { onlineMangalAarti = it })
                        }
                    }

                    6 -> {
                        Text("7. Are you Gayatri initiated?", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        Text("If yes, we enable personalized morning, midday, and evening Gayatri reminders.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Enable Gayatri Sandhya Reminders", style = MaterialTheme.typography.titleMedium)
                            Switch(checked = gayatriInitiated, onCheckedChange = { gayatriInitiated = it })
                        }
                        if (gayatriInitiated) {
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(value = gayatriM, onValueChange = { gayatriM = it.take(5) }, label = { Text("Morning") }, modifier = Modifier.weight(1f))
                                OutlinedTextField(value = gayatriA, onValueChange = { gayatriA = it.take(5) }, label = { Text("Noon") }, modifier = Modifier.weight(1f))
                                OutlinedTextField(value = gayatriE, onValueChange = { gayatriE = it.take(5) }, label = { Text("Evening") }, modifier = Modifier.weight(1f))
                            }
                        }
                    }

                    7 -> {
                        Text("8. What are your daily responsibilities?", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        Text("Separate multiple duties with commas (e.g., Temple Seva, Office, College, Family).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = responsibilitiesText,
                            onValueChange = { responsibilitiesText = it },
                            label = { Text("Daily responsibilities") },
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    8 -> {
                        Text("9. Which applications distract you?", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        Text("Select apps for your Digital Wellbeing Focus Shield (you can customize all installed apps later).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            UsageStatsHelper.commonDistractingDefaults.forEach { (pkg, name) ->
                                val selected = pkg in distractingApps
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        if (selected) distractingApps.remove(pkg) else distractingApps.add(pkg)
                                    },
                                    label = { Text(name) }
                                )
                            }
                        }
                    }

                    9 -> {
                        Text("10. How strict should your focus system be?", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(12.dp))
                        FocusStrictness.entries.forEach { level ->
                            SanctuaryCard(
                                modifier = Modifier
                                    .padding(vertical = 4.dp)
                                    .clickable { strictness = level },
                                containerColor = if (strictness == level) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                                else MaterialTheme.colorScheme.surface
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(level.label, style = MaterialTheme.typography.titleMedium)
                                        Text(level.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    if (strictness == level) {
                                        Icon(Icons.Default.Check, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (step > 0) {
                    OutlinedButton(
                        onClick = { step-- },
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        Text(" Back")
                    }
                } else {
                    Spacer(Modifier.height(48.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (step < totalSteps - 1) {
                        TextButton(
                            onClick = { step++ },
                            modifier = Modifier.height(48.dp)
                        ) {
                            Text("Skip")
                        }
                        Button(
                            onClick = { step++ },
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("onboarding_next_button")
                        ) {
                            Text("Next ")
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                        }
                    } else {
                        Button(
                            onClick = { onComplete(buildResultProfile()) },
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("onboarding_finish_button")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null)
                            Text(" Finish Setup")
                        }
                    }
                }
            }
        }
    }
}
