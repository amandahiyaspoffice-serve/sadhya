package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.calendar.SacredCityPreset
import com.example.calendar.VaishnavaCalendarEngine
import com.example.calendar.VaishnavaDayInfo
import com.example.data.local.FocusRuleEntity
import com.example.data.local.ImportedCalendarEventEntity
import com.example.data.local.LocalAlarmFocusState
import com.example.data.local.PreferencesManager
import com.example.data.local.PrivateCheckInEntity
import com.example.data.local.SadhanaDao
import com.example.data.model.CalendarTradition
import com.example.data.model.DailyTask
import com.example.data.model.DarkModePreference
import com.example.data.model.DevotionalMediaItem
import com.example.data.model.FocusLog
import com.example.data.model.FocusStrictness
import com.example.data.model.FontScaleLevel
import com.example.data.model.RoutineMode
import com.example.data.model.RoutineTemplates
import com.example.data.model.SadhanaDailyLog
import com.example.data.model.ScheduleCategory
import com.example.data.model.ScheduleItem
import com.example.data.model.TaskPriority
import com.example.data.model.TaskRepeatFrequency
import com.example.data.model.TempleCommunity
import com.example.data.model.TemplePost
import com.example.data.model.ThemeStyle
import com.example.data.model.UserProfile
import com.example.data.model.WakeUpMethod
import com.example.data.model.WakeUpStatus
import com.example.data.remote.GeminiAssistantRepository
import com.example.data.remote.SadhanaDataRepository
import com.example.media.AudioPlaybackState
import com.example.media.DevotionalAudioPlayer
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

data class CoachChatMessage(
    val id: String,
    val role: String, // "user" or "model"
    val text: String,
    val isStreaming: Boolean = false
)

sealed interface AiTaskState {
    data object Idle : AiTaskState
    data object Loading : AiTaskState
    data class Success(val message: String) : AiTaskState
    data class Error(val message: String) : AiTaskState
}

@OptIn(ExperimentalCoroutinesApi::class)
class SadhanaViewModel(
    private val currentUserId: String,
    private val initialDisplayName: String,
    private val initialEmail: String,
    private val firestoreRepo: SadhanaDataRepository,
    private val geminiRepo: GeminiAssistantRepository,
    private val dao: SadhanaDao,
    private val prefs: PreferencesManager,
    val audioPlayer: DevotionalAudioPlayer,
    val isGuestMode: Boolean = false
) : ViewModel() {

    private companion object {
        const val TAG = "SadhanaVM"
        const val STOP_TIMEOUT_MS = 5000L
    }

    private fun <T> kotlinx.coroutines.flow.Flow<T>.toSafeUiState(
        initial: UiState<T> = UiState.Loading
    ): StateFlow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Stream error", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Unable to load data."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
                initialValue = initial
            )

    val profileState: StateFlow<UiState<UserProfile?>> =
        firestoreRepo.observeUserProfile(currentUserId).toSafeUiState()

    val scheduleState: StateFlow<UiState<List<ScheduleItem>>> =
        firestoreRepo.observeScheduleItems(currentUserId).toSafeUiState()

    val tasksState: StateFlow<UiState<List<DailyTask>>> =
        firestoreRepo.observeTasks(currentUserId).toSafeUiState()

    val sadhanaLogsState: StateFlow<UiState<List<SadhanaDailyLog>>> =
        firestoreRepo.observeSadhanaLogs(currentUserId).toSafeUiState()

    val focusLogsState: StateFlow<UiState<List<FocusLog>>> =
        firestoreRepo.observeFocusLogs(currentUserId).toSafeUiState()

    val templesState: StateFlow<UiState<List<TempleCommunity>>> =
        firestoreRepo.observeTemples(currentUserId).toSafeUiState()

    val followedTemplePostsState: StateFlow<UiState<List<TemplePost>>> =
        profileState.flatMapLatest { state ->
            val templeId = (state as? UiState.Success)?.data?.followedTempleId.orEmpty()
            if (templeId.isBlank()) flowOf(emptyList())
            else firestoreRepo.observeTemplePosts(currentUserId, templeId)
        }.toSafeUiState(UiState.Success(emptyList()))

    val localPrefsState: StateFlow<LocalAlarmFocusState> =
        prefs.stateFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), LocalAlarmFocusState())

    val privateCheckInsState: StateFlow<List<PrivateCheckInEntity>> =
        dao.observeCheckIns().stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val focusRulesState: StateFlow<List<FocusRuleEntity>> =
        dao.observeFocusRules().stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val importedCalendarEventsState: StateFlow<List<ImportedCalendarEventEntity>> =
        dao.observeImportedEvents().stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val audioState: StateFlow<AudioPlaybackState> = audioPlayer.state

    // Vaishnava Calendar state
    private val _selectedMonth = MutableStateFlow(YearMonth.now())
    val selectedMonth: StateFlow<YearMonth> = _selectedMonth.asStateFlow()

    private val _selectedDate = MutableStateFlow(LocalDate.now())
    val selectedDate: StateFlow<LocalDate> = _selectedDate.asStateFlow()

    // AI States
    private val _aiScheduleState = MutableStateFlow<AiTaskState>(AiTaskState.Idle)
    val aiScheduleState: StateFlow<AiTaskState> = _aiScheduleState.asStateFlow()

    private val _aiTaskState = MutableStateFlow<AiTaskState>(AiTaskState.Idle)
    val aiTaskState: StateFlow<AiTaskState> = _aiTaskState.asStateFlow()

    private val _aiWakeReflection = MutableStateFlow<AiTaskState>(AiTaskState.Idle)
    val aiWakeReflection: StateFlow<AiTaskState> = _aiWakeReflection.asStateFlow()

    private val _coachMessages = MutableStateFlow<List<CoachChatMessage>>(
        listOf(
            CoachChatMessage(
                id = "welcome",
                role = "model",
                text = "Hare Krishna! I am your humble Sadhana & routine companion. Ask me to review your week, understand missed rounds or late wake-ups, or help balance your schedule."
            )
        )
    )
    val coachMessages: StateFlow<List<CoachChatMessage>> = _coachMessages.asStateFlow()

    private val _coachError = MutableStateFlow<String?>(null)
    val coachError: StateFlow<String?> = _coachError.asStateFlow()

    private val _bannerFeedback = MutableStateFlow<String?>(null)
    val bannerFeedback: StateFlow<String?> = _bannerFeedback.asStateFlow()

    init {
        viewModelScope.launch {
            firestoreRepo.ensureUserProfileExists(currentUserId, initialDisplayName, initialEmail)
            dao.insertDefaultFocusRules(
                listOf(
                    FocusRuleEntity("com.instagram.android", "Instagram", true, true),
                    FocusRuleEntity("com.google.android.youtube", "YouTube", true, true),
                    FocusRuleEntity("com.facebook.katana", "Facebook", true, true),
                    FocusRuleEntity("com.android.chrome", "Chrome", true, true)
                )
            )
        }
    }

    fun clearBannerFeedback() {
        _bannerFeedback.value = null
    }

    fun exitGuestMode() {
        viewModelScope.launch {
            prefs.setGuestModeEnabled(false)
        }
    }

    fun clearAiStates() {
        _aiScheduleState.value = AiTaskState.Idle
        _aiTaskState.value = AiTaskState.Idle
        _aiWakeReflection.value = AiTaskState.Idle
    }

    fun todayIso(): String = LocalDate.now().toString()

    fun currentProfile(): UserProfile =
        (profileState.value as? UiState.Success)?.data ?: UserProfile(
            userId = currentUserId,
            displayName = initialDisplayName,
            email = initialEmail
        )

    fun currentTodayLog(): SadhanaDailyLog {
        val today = todayIso()
        val logs = (sadhanaLogsState.value as? UiState.Success)?.data.orEmpty()
        val p = currentProfile()
        return logs.firstOrNull { it.dateIso == today } ?: SadhanaDailyLog(
            userId = currentUserId,
            dateIso = today,
            targetRounds = p.japaTargetRounds
        )
    }

    // --- ONBOARDING & PROFILE ---
    fun completeOnboarding(updatedProfile: UserProfile, onAlarmsSync: (LocalAlarmFocusState) -> Unit) {
        viewModelScope.launch {
            val finalProfile = updatedProfile.copy(
                userId = currentUserId,
                onboardingCompleted = true
            )
            val updates = mapOf(
                "displayName" to finalProfile.displayName,
                "routineMode" to finalProfile.routineMode,
                "wakeTime" to finalProfile.wakeTime,
                "sleepTime" to finalProfile.sleepTime,
                "japaTargetRounds" to finalProfile.japaTargetRounds,
                "readingTargetMinutes" to finalProfile.readingTargetMinutes,
                "hearingTargetMinutes" to finalProfile.hearingTargetMinutes,
                "attendOnlineMangalAarti" to finalProfile.attendOnlineMangalAarti,
                "gayatriInitiated" to finalProfile.gayatriInitiated,
                "gayatriMorningTime" to finalProfile.gayatriMorningTime,
                "gayatriAfternoonTime" to finalProfile.gayatriAfternoonTime,
                "gayatriEveningTime" to finalProfile.gayatriEveningTime,
                "responsibilities" to finalProfile.responsibilities,
                "distractingPackages" to finalProfile.distractingPackages,
                "focusStrictness" to finalProfile.focusStrictness,
                "onboardingCompleted" to true
            )
            val res = firestoreRepo.updateUserProfileFields(currentUserId, updates)
            if (res.isSuccess) {
                firestoreRepo.seedScheduleForProfile(currentUserId, finalProfile)
                prefs.updateWakeConfig(true, finalProfile.wakeTime)
                prefs.updateBedtimeConfig(finalProfile.bedtimeModeEnabled, finalProfile.sleepTime)
                prefs.updateGayatriConfig(
                    finalProfile.gayatriInitiated,
                    finalProfile.gayatriMorningTime,
                    finalProfile.gayatriAfternoonTime,
                    finalProfile.gayatriEveningTime
                )
                onAlarmsSync(prefs.getSnapshot())
                _bannerFeedback.value = "Your Sadhana schedule is ready."
            } else {
                _bannerFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to save profile."
            }
        }
    }

    fun switchRoutineMode(mode: RoutineMode) {
        viewModelScope.launch {
            val p = currentProfile().copy(routineMode = mode.name, activeFestivalMode = "")
            val res = firestoreRepo.updateUserProfileFields(
                currentUserId,
                mapOf("routineMode" to mode.name, "activeFestivalMode" to "")
            )
            if (res.isSuccess) {
                firestoreRepo.seedScheduleForProfile(currentUserId, p)
                _bannerFeedback.value = "Switched to ${mode.label} routine."
            }
        }
    }

    fun activateFestivalMode(festivalName: String) {
        viewModelScope.launch {
            val res = firestoreRepo.updateUserProfileFields(
                currentUserId,
                mapOf("activeFestivalMode" to festivalName)
            )
            if (res.isSuccess) {
                val festivalBlocks = RoutineTemplates.getFestivalModeSchedule(festivalName)
                festivalBlocks.forEach { block ->
                    firestoreRepo.addScheduleItem(currentUserId, block)
                }
                _bannerFeedback.value = "Festival Mode active: $festivalName"
            }
        }
    }

    fun deactivateFestivalMode() {
        viewModelScope.launch {
            firestoreRepo.updateUserProfileFields(currentUserId, mapOf("activeFestivalMode" to ""))
            val items = (scheduleState.value as? UiState.Success)?.data.orEmpty()
            items.filter { it.routineMode == "FESTIVAL" }.forEach {
                firestoreRepo.deleteScheduleItem(currentUserId, it.id)
            }
            _bannerFeedback.value = "Returned to regular daily routine."
        }
    }

    fun updateThemeAndCustomization(
        themeStyle: ThemeStyle,
        darkMode: DarkModePreference,
        fontScale: FontScaleLevel,
        showMediaCard: Boolean,
        showWakeCard: Boolean
    ) {
        viewModelScope.launch {
            prefs.updateHomeCustomization(showMediaCard, showWakeCard)
            firestoreRepo.updateUserProfileFields(
                currentUserId,
                mapOf(
                    "themeStyle" to themeStyle.name,
                    "darkModePreference" to darkMode.name,
                    "fontScaleLevel" to fontScale.name
                )
            )
            _bannerFeedback.value = "Appearance preferences saved."
        }
    }

    fun updateAlarmSettings(
        wakeEnabled: Boolean,
        wakeTime: String,
        sleepTime: String,
        bedtimeEnabled: Boolean,
        gayatriEnabled: Boolean,
        gayatriM: String,
        gayatriA: String,
        gayatriE: String,
        onAlarmsSync: (LocalAlarmFocusState) -> Unit
    ) {
        viewModelScope.launch {
            prefs.updateWakeConfig(wakeEnabled, wakeTime)
            prefs.updateBedtimeConfig(bedtimeEnabled, sleepTime)
            prefs.updateGayatriConfig(gayatriEnabled, gayatriM, gayatriA, gayatriE)
            firestoreRepo.updateUserProfileFields(
                currentUserId,
                mapOf(
                    "wakeTime" to wakeTime,
                    "sleepTime" to sleepTime,
                    "bedtimeModeEnabled" to bedtimeEnabled,
                    "gayatriInitiated" to gayatriEnabled,
                    "gayatriMorningTime" to gayatriM,
                    "gayatriAfternoonTime" to gayatriA,
                    "gayatriEveningTime" to gayatriE
                )
            )
            onAlarmsSync(prefs.getSnapshot())
            _bannerFeedback.value = "Alarms and reminders updated."
        }
    }

    // --- SCHEDULE CRUD ---
    fun addScheduleBlock(
        title: String,
        description: String,
        startTime: String,
        endTime: String,
        category: ScheduleCategory,
        essential: Boolean
    ) {
        viewModelScope.launch {
            val item = ScheduleItem(
                userId = currentUserId,
                title = title,
                description = description,
                startTime = startTime,
                endTime = endTime,
                category = category.name,
                routineMode = currentProfile().routineMode,
                essential = essential,
                reminderEnabled = true,
                completedToday = false,
                sortOrder = 50L
            )
            val res = firestoreRepo.addScheduleItem(currentUserId, item)
            if (res.isFailure) {
                _bannerFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to add activity."
            }
        }
    }

    fun toggleScheduleCompleted(item: ScheduleItem) {
        viewModelScope.launch {
            val today = todayIso()
            val isDoneNow = !(item.completedToday && item.lastCompletedDate == today)
            firestoreRepo.updateScheduleItem(
                currentUserId,
                item.id,
                mapOf(
                    "completedToday" to isDoneNow,
                    "lastCompletedDate" to if (isDoneNow) today else ""
                )
            )
        }
    }

    fun updateScheduleTimes(item: ScheduleItem, newStart: String, newEnd: String) {
        viewModelScope.launch {
            firestoreRepo.updateScheduleItem(
                currentUserId,
                item.id,
                mapOf("startTime" to newStart, "endTime" to newEnd)
            )
        }
    }

    fun deleteScheduleBlock(itemId: String) {
        viewModelScope.launch {
            firestoreRepo.deleteScheduleItem(currentUserId, itemId)
        }
    }

    // --- TASK CRUD ---
    fun addManualTask(
        title: String,
        description: String,
        dateIso: String,
        startTime: String,
        endTime: String,
        repeat: TaskRepeatFrequency,
        priority: TaskPriority
    ) {
        viewModelScope.launch {
            val task = DailyTask(
                userId = currentUserId,
                title = title,
                description = description,
                dateIso = dateIso.ifBlank { todayIso() },
                startTime = startTime,
                endTime = endTime,
                repeatFrequency = repeat.name,
                reminderEnabled = true,
                priority = priority.name,
                completed = false
            )
            val res = firestoreRepo.addTask(currentUserId, task)
            if (res.isFailure) {
                _bannerFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Could not save task."
            }
        }
    }

    fun toggleTaskCompleted(task: DailyTask) {
        viewModelScope.launch {
            firestoreRepo.updateTask(
                currentUserId,
                task.id,
                mapOf("completed" to !task.completed)
            )
        }
    }

    fun deleteTask(taskId: String) {
        viewModelScope.launch {
            firestoreRepo.deleteTask(currentUserId, taskId)
        }
    }

    // --- SADHANA TRACKER ---
    fun tapJapaBead() {
        viewModelScope.launch {
            val currentBead = localPrefsState.value.japaBeadCount
            val next = currentBead + 1
            if (next >= 108) {
                prefs.setJapaBeadCount(0)
                incrementRounds(1)
            } else {
                prefs.setJapaBeadCount(next)
            }
        }
    }

    fun resetJapaBead() {
        viewModelScope.launch { prefs.setJapaBeadCount(0) }
    }

    fun incrementRounds(delta: Long) {
        viewModelScope.launch {
            val log = currentTodayLog()
            val updated = log.copy(
                roundsChanted = (log.roundsChanted + delta).coerceIn(0L, 300L),
                targetRounds = currentProfile().japaTargetRounds
            )
            firestoreRepo.upsertSadhanaLog(currentUserId, todayIso(), updated)
        }
    }

    fun addReadingMinutes(minutes: Long) {
        viewModelScope.launch {
            val log = currentTodayLog()
            firestoreRepo.upsertSadhanaLog(
                currentUserId,
                todayIso(),
                log.copy(readingMinutes = (log.readingMinutes + minutes).coerceIn(0L, 720L))
            )
        }
    }

    fun addHearingMinutes(minutes: Long) {
        viewModelScope.launch {
            val log = currentTodayLog()
            firestoreRepo.upsertSadhanaLog(
                currentUserId,
                todayIso(),
                log.copy(hearingMinutes = (log.hearingMinutes + minutes).coerceIn(0L, 720L))
            )
        }
    }

    fun toggleMangalAarti() {
        viewModelScope.launch {
            val log = currentTodayLog()
            firestoreRepo.upsertSadhanaLog(
                currentUserId,
                todayIso(),
                log.copy(mangalAartiAttended = !log.mangalAartiAttended)
            )
        }
    }

    fun toggleGayatri(slot: Int) {
        viewModelScope.launch {
            val log = currentTodayLog()
            val next = when (slot) {
                0 -> log.copy(gayatriMorningDone = !log.gayatriMorningDone)
                1 -> log.copy(gayatriAfternoonDone = !log.gayatriAfternoonDone)
                else -> log.copy(gayatriEveningDone = !log.gayatriEveningDone)
            }
            firestoreRepo.upsertSadhanaLog(currentUserId, todayIso(), next)
        }
    }

    fun logSeva(minutes: Long, note: String) {
        viewModelScope.launch {
            val log = currentTodayLog()
            firestoreRepo.upsertSadhanaLog(
                currentUserId,
                todayIso(),
                log.copy(
                    sevaMinutes = (log.sevaMinutes + minutes).coerceIn(0L, 720L),
                    sevaNotes = note.ifBlank { log.sevaNotes }
                )
            )
        }
    }

    fun updateSadhanaTargets(rounds: Long, readingMin: Long, hearingMin: Long) {
        viewModelScope.launch {
            firestoreRepo.updateUserProfileFields(
                currentUserId,
                mapOf(
                    "japaTargetRounds" to rounds.coerceIn(1L, 192L),
                    "readingTargetMinutes" to readingMin.coerceIn(0L, 600L),
                    "hearingTargetMinutes" to hearingMin.coerceIn(0L, 600L)
                )
            )
            val log = currentTodayLog()
            firestoreRepo.upsertSadhanaLog(currentUserId, todayIso(), log.copy(targetRounds = rounds))
            _bannerFeedback.value = "Sadhana targets updated."
        }
    }

    fun recordQuickWakeCheckIn(method: WakeUpMethod, status: WakeUpStatus, note: String) {
        viewModelScope.launch {
            val now = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
            val log = currentTodayLog().copy(
                wakeUpStatus = status.name,
                wakeUpActualTime = now,
                wakeUpMethod = method.name,
                wakeUpReflection = note
            )
            firestoreRepo.upsertSadhanaLog(currentUserId, todayIso(), log)
            dao.insertCheckIn(
                PrivateCheckInEntity(
                    dateIso = todayIso(),
                    actualTime = now,
                    targetTime = currentProfile().wakeTime,
                    status = status.name,
                    method = method.name,
                    privatePhotoPath = null,
                    reflectionNote = note
                )
            )
        }
    }

    // --- VAISHNAVA CALENDAR ---
    fun navigateMonth(delta: Long) {
        _selectedMonth.value = _selectedMonth.value.plusMonths(delta)
    }

    fun selectDate(date: LocalDate) {
        _selectedDate.value = date
        _selectedMonth.value = YearMonth.from(date)
    }

    fun updateCalendarLocationAndTradition(preset: SacredCityPreset, tradition: CalendarTradition) {
        viewModelScope.launch {
            firestoreRepo.updateUserProfileFields(
                currentUserId,
                mapOf(
                    "locationName" to preset.name,
                    "latitude" to preset.latitude,
                    "longitude" to preset.longitude,
                    "timezoneId" to preset.timezoneId,
                    "calendarTradition" to tradition.name
                )
            )
            _bannerFeedback.value = "Calendar calibrated for ${preset.name}"
        }
    }

    fun saveImportedIcsEvents(events: List<ImportedCalendarEventEntity>) {
        viewModelScope.launch {
            dao.clearImportedEvents()
            dao.insertImportedEvents(events)
            _bannerFeedback.value = "Imported ${events.size} events from .ics calendar."
        }
    }

    fun addCalendarEventToSchedule(dayInfo: VaishnavaDayInfo, title: String, note: String) {
        addManualTask(
            title = title,
            description = note,
            dateIso = dayInfo.date.toString(),
            startTime = dayInfo.sunriseTime,
            endTime = "",
            repeat = TaskRepeatFrequency.ONCE,
            priority = TaskPriority.HIGH
        )
        _bannerFeedback.value = "Added '$title' to your tasks for ${dayInfo.date}."
    }

    // --- FOCUS & DIGITAL WELLBEING ---
    fun toggleBlockedApp(packageName: String, appName: String, currentlyBlocked: Boolean) {
        viewModelScope.launch {
            dao.upsertFocusRule(
                FocusRuleEntity(
                    packageName = packageName,
                    appName = appName,
                    blockedDuringFocus = !currentlyBlocked,
                    blockedDuringBedtime = !currentlyBlocked
                )
            )
            val currentList = currentProfile().distractingPackages.toMutableList()
            if (!currentlyBlocked) {
                if (packageName !in currentList) currentList.add(packageName)
            } else {
                currentList.remove(packageName)
            }
            firestoreRepo.updateUserProfileFields(
                currentUserId,
                mapOf("distractingPackages" to currentList.take(30))
            )
        }
    }

    fun updateFocusStrictness(strictness: FocusStrictness) {
        viewModelScope.launch {
            val s = localPrefsState.value
            prefs.setFocusShield(s.focusShieldActive, s.focusEndEpochMs, s.currentScheduledActivity, strictness.name)
            firestoreRepo.updateUserProfileFields(
                currentUserId,
                mapOf("focusStrictness" to strictness.name)
            )
        }
    }

    fun setFocusShieldActive(active: Boolean, durationMinutes: Int, scheduledActivity: String) {
        viewModelScope.launch {
            val endMs = if (active) System.currentTimeMillis() + durationMinutes * 60_000L else 0L
            prefs.setFocusShield(active, endMs, scheduledActivity, currentProfile().focusStrictness)
            if (active) {
                val log = currentTodayLog()
                firestoreRepo.upsertSadhanaLog(
                    currentUserId,
                    todayIso(),
                    log.copy(focusMinutes = log.focusMinutes + durationMinutes.toLong())
                )
            }
        }
    }

    // --- GEMINI AI ---
    fun generateScheduleWithAi(prompt: String, preserveEssentials: Boolean = true) {
        viewModelScope.launch {
            _aiScheduleState.value = AiTaskState.Loading
            val existing = (scheduleState.value as? UiState.Success)?.data.orEmpty()
            val essentials = if (preserveEssentials) existing.filter { it.essential } else emptyList()
            val result = geminiRepo.generateScheduleFromPrompt(prompt, currentProfile(), essentials)
            result.fold(
                onSuccess = { (summary, items) ->
                    firestoreRepo.replaceScheduleItems(
                        currentUserId,
                        items,
                        keepEssentialExisting = false
                    )
                    _aiScheduleState.value = AiTaskState.Success(summary)
                },
                onFailure = { err ->
                    _aiScheduleState.value = AiTaskState.Error(err.localizedMessage ?: "AI schedule generation failed.")
                }
            )
        }
    }

    fun createTaskWithAi(prompt: String) {
        viewModelScope.launch {
            _aiTaskState.value = AiTaskState.Loading
            val res = geminiRepo.parseNaturalLanguageTask(prompt, todayIso())
            res.fold(
                onSuccess = { task ->
                    firestoreRepo.addTask(currentUserId, task)
                    _aiTaskState.value = AiTaskState.Success("Added task: ${task.title} (${task.dateIso})")
                },
                onFailure = { err ->
                    _aiTaskState.value = AiTaskState.Error(err.localizedMessage ?: "Could not parse task.")
                }
            )
        }
    }

    fun analyzeMissedWakeUpWithAi(actualTime: String, userNote: String) {
        viewModelScope.launch {
            _aiWakeReflection.value = AiTaskState.Loading
            val res = geminiRepo.analyzeWakeUpMiss(currentProfile(), actualTime, userNote)
            _aiWakeReflection.value = res.fold(
                onSuccess = { AiTaskState.Success(it) },
                onFailure = { AiTaskState.Error(it.localizedMessage ?: "Reflection unavailable.") }
            )
        }
    }

    fun sendCoachMessage(userMessage: String) {
        if (userMessage.isBlank()) return
        _coachError.value = null
        val userMsg = CoachChatMessage("u_${System.currentTimeMillis()}", "user", userMessage.trim())
        val replyId = "m_${System.currentTimeMillis() + 1}"
        val historyPairs = _coachMessages.value
            .filter { !it.isStreaming && it.id != "welcome" }
            .map { it.role to it.text }

        _coachMessages.value = _coachMessages.value + userMsg + CoachChatMessage(replyId, "model", "", isStreaming = true)

        viewModelScope.launch {
            val recentLogs = (sadhanaLogsState.value as? UiState.Success)?.data.orEmpty().take(7)
            try {
                geminiRepo.streamAccountabilityReply(
                    userMessage = userMessage.trim(),
                    historyMessages = historyPairs,
                    profile = currentProfile(),
                    recentLogs = recentLogs
                ).collect { partial ->
                    _coachMessages.value = _coachMessages.value.map { msg ->
                        if (msg.id == replyId) msg.copy(text = partial, isStreaming = true) else msg
                    }
                }
                _coachMessages.value = _coachMessages.value.map { msg ->
                    if (msg.id == replyId) msg.copy(isStreaming = false) else msg
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Coach stream failed", e)
                _coachMessages.value = _coachMessages.value.filterNot { it.id == replyId && it.text.isBlank() }
                    .map { if (it.id == replyId) it.copy(isStreaming = false) else it }
                _coachError.value = e.localizedMessage ?: "Gemini Coach is temporarily unreachable."
            }
        }
    }

    // --- TEMPLE COMMUNITY ---
    fun followTemple(temple: TempleCommunity) {
        viewModelScope.launch {
            firestoreRepo.updateUserProfileFields(
                currentUserId,
                mapOf("followedTempleId" to temple.id)
            )
            _bannerFeedback.value = "Following ${temple.name}"
        }
    }

    fun applyTempleScheduleToMyRoutine(temple: TempleCommunity) {
        viewModelScope.launch {
            val items = listOf(
                ScheduleItem(title = "${temple.name} Mangal Aarti", startTime = temple.mangalAartiTime, endTime = RoutineTemplates.addMinutes(temple.mangalAartiTime, 30), category = ScheduleCategory.SPIRITUAL.name, routineMode = RoutineMode.TEMPLE_RESIDENT.name, essential = true, sortOrder = 1),
                ScheduleItem(title = "Tulasi Aarti & Parikrama", startTime = temple.tulasiAartiTime, endTime = RoutineTemplates.addMinutes(temple.tulasiAartiTime, 15), category = ScheduleCategory.SPIRITUAL.name, routineMode = RoutineMode.TEMPLE_RESIDENT.name, essential = true, sortOrder = 2),
                ScheduleItem(title = "Morning Japa Meditation", startTime = RoutineTemplates.addMinutes(temple.tulasiAartiTime, 15), endTime = temple.darshanTime, category = ScheduleCategory.SPIRITUAL.name, routineMode = RoutineMode.TEMPLE_RESIDENT.name, essential = true, sortOrder = 3),
                ScheduleItem(title = "Shringar Darshan & Guru Puja", startTime = temple.darshanTime, endTime = temple.bhagavatamClassTime, category = ScheduleCategory.SPIRITUAL.name, routineMode = RoutineMode.TEMPLE_RESIDENT.name, essential = true, sortOrder = 4),
                ScheduleItem(title = "Srimad Bhagavatam Class", startTime = temple.bhagavatamClassTime, endTime = RoutineTemplates.addMinutes(temple.bhagavatamClassTime, 60), category = ScheduleCategory.SPIRITUAL.name, routineMode = RoutineMode.TEMPLE_RESIDENT.name, essential = true, sortOrder = 5),
                ScheduleItem(title = "Sandhya Aarti & Kirtan", startTime = temple.sandhyaAartiTime, endTime = RoutineTemplates.addMinutes(temple.sandhyaAartiTime, 45), category = ScheduleCategory.SPIRITUAL.name, routineMode = RoutineMode.TEMPLE_RESIDENT.name, essential = true, sortOrder = 6)
            )
            firestoreRepo.replaceScheduleItems(currentUserId, items)
            _bannerFeedback.value = "Applied ${temple.name} official schedule."
        }
    }

    fun createTemple(
        name: String,
        city: String,
        tradition: String,
        mangalTime: String,
        darshanTime: String,
        sbTime: String,
        sandhyaTime: String,
        description: String
    ) {
        viewModelScope.launch {
            val res = firestoreRepo.createTemple(
                TempleCommunity(
                    name = name,
                    city = city,
                    tradition = tradition,
                    adminUid = currentUserId,
                    adminName = currentProfile().displayName,
                    mangalAartiTime = mangalTime,
                    tulasiAartiTime = RoutineTemplates.addMinutes(mangalTime, 30),
                    darshanTime = darshanTime,
                    bhagavatamClassTime = sbTime,
                    sandhyaAartiTime = sandhyaTime,
                    description = description
                )
            )
            res.onSuccess { newId ->
                firestoreRepo.updateUserProfileFields(currentUserId, mapOf("followedTempleId" to newId))
                _bannerFeedback.value = "Temple created and followed!"
            }.onFailure {
                _bannerFeedback.value = it.localizedMessage ?: "Failed to create temple."
            }
        }
    }

    fun publishTemplePost(
        templeId: String,
        postType: com.example.data.model.TemplePostType,
        title: String,
        body: String,
        eventDate: String,
        eventTime: String,
        sevaSlots: Long
    ) {
        viewModelScope.launch {
            val res = firestoreRepo.createTemplePost(
                templeId,
                TemplePost(
                    templeId = templeId,
                    authorUid = currentUserId,
                    authorName = currentProfile().displayName,
                    postType = postType.name,
                    title = title,
                    body = body,
                    eventDate = eventDate,
                    eventTime = eventTime,
                    sevaSlotsTotal = sevaSlots
                )
            )
            if (res.isSuccess) _bannerFeedback.value = "Published ${postType.label} to temple devotees."
            else _bannerFeedback.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to publish post."
        }
    }

    fun toggleSevaVolunteer(templeId: String, post: TemplePost) {
        viewModelScope.launch {
            firestoreRepo.toggleSevaVolunteer(templeId, post)
        }
    }

    // --- MEDIA ---
    fun playDevotionalMedia(item: DevotionalMediaItem, openExternal: (String) -> Unit) {
        audioPlayer.playItem(item, openExternal)
        addHearingMinutes(5)
    }

    override fun onCleared() {
        audioPlayer.stop()
        super.onCleared()
    }
}
