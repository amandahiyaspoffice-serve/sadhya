package com.example.alarms

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.local.LocalAlarmFocusState
import com.example.data.model.RoutineTemplates
import java.util.Calendar

object AlarmScheduler {

    const val CHANNEL_WAKE = "sadhana_wake_channel"
    const val CHANNEL_REMINDER = "sadhana_reminder_channel"
    const val CHANNEL_FOCUS = "sadhana_focus_channel"

    const val EXTRA_ALARM_TYPE = "extra_alarm_type"
    const val EXTRA_ALARM_TITLE = "extra_alarm_title"
    const val EXTRA_ALARM_BODY = "extra_alarm_body"
    const val EXTRA_TIME_HHMM = "extra_time_hhmm"

    const val TYPE_WAKE = "WAKE"
    const val TYPE_GAYATRI_MORNING = "GAYATRI_MORNING"
    const val TYPE_GAYATRI_AFTERNOON = "GAYATRI_AFTERNOON"
    const val TYPE_GAYATRI_EVENING = "GAYATRI_EVENING"
    const val TYPE_BEDTIME_WRAP = "BEDTIME_WRAP"
    const val TYPE_BEDTIME_PREP = "BEDTIME_PREP"
    const val TYPE_BEDTIME_SLEEP = "BEDTIME_SLEEP"
    const val TYPE_TASK_REMINDER = "TASK_REMINDER"

    private const val REQ_WAKE = 1001
    private const val REQ_WAKE_REPEAT = 1002
    private const val REQ_GAYATRI_M = 1011
    private const val REQ_GAYATRI_A = 1012
    private const val REQ_GAYATRI_E = 1013
    private const val REQ_BED_WRAP = 1021
    private const val REQ_BED_PREP = 1022
    private const val REQ_BED_SLEEP = 1023

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val wake = NotificationChannel(
                CHANNEL_WAKE,
                "Brahma Muhurta Wake-Up Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Morning wake-up alarms and repeat check-in reminders"
                enableVibration(true)
            }
            val reminder = NotificationChannel(
                CHANNEL_REMINDER,
                "Sadhana, Gayatri & Bedtime Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Daily schedule, Gayatri sandhya, Ekadashi and bedtime notifications"
            }
            val focus = NotificationChannel(
                CHANNEL_FOCUS,
                "Digital Wellbeing Focus Shield",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Active focus and bedtime app blocker status"
            }
            nm.createNotificationChannels(listOf(wake, reminder, focus))
        }
    }

    fun canScheduleExactAlarms(context: Context): Boolean {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            am.canScheduleExactAlarms()
        } else true
    }

    fun syncAllAlarms(context: Context, state: LocalAlarmFocusState) {
        ensureChannels(context)
        if (state.wakeAlarmEnabled) {
            scheduleDailyAlarm(
                context,
                REQ_WAKE,
                state.wakeTime,
                TYPE_WAKE,
                "Brahma Muhurta Wake-Up",
                "Hare Krishna! Time to rise for morning Japa & Mangal Aarti."
            )
        } else {
            cancelAlarm(context, REQ_WAKE)
        }

        if (state.gayatriEnabled) {
            scheduleDailyAlarm(context, REQ_GAYATRI_M, state.gayatriMorning, TYPE_GAYATRI_MORNING, "Morning Gayatri Sandhya", "Time for morning Gayatri meditation.")
            scheduleDailyAlarm(context, REQ_GAYATRI_A, state.gayatriAfternoon, TYPE_GAYATRI_AFTERNOON, "Midday Gayatri Sandhya", "Time for afternoon Gayatri meditation.")
            scheduleDailyAlarm(context, REQ_GAYATRI_E, state.gayatriEvening, TYPE_GAYATRI_EVENING, "Evening Gayatri Sandhya", "Time for sunset Gayatri meditation.")
        } else {
            cancelAlarm(context, REQ_GAYATRI_M)
            cancelAlarm(context, REQ_GAYATRI_A)
            cancelAlarm(context, REQ_GAYATRI_E)
        }

        if (state.bedtimeRemindersEnabled) {
            val wrap = RoutineTemplates.subtractMinutes(state.sleepTime, 30)
            val prep = RoutineTemplates.subtractMinutes(state.sleepTime, 15)
            scheduleDailyAlarm(context, REQ_BED_WRAP, wrap, TYPE_BEDTIME_WRAP, "Finish Evening Activities", "30 minutes until bedtime (${state.sleepTime}). Begin winding down.")
            scheduleDailyAlarm(context, REQ_BED_PREP, prep, TYPE_BEDTIME_PREP, "Prepare Tomorrow's Schedule", "Review tomorrow's tasks, Ekadashi calendar & Brahma Muhurta alarm.")
            scheduleDailyAlarm(context, REQ_BED_SLEEP, state.sleepTime, TYPE_BEDTIME_SLEEP, "Bedtime & Night Focus", "Time for rest so tomorrow's Brahma Muhurta Sadhana is fresh.")
        } else {
            cancelAlarm(context, REQ_BED_WRAP)
            cancelAlarm(context, REQ_BED_PREP)
            cancelAlarm(context, REQ_BED_SLEEP)
        }
    }

    fun scheduleRepeatWakeAlarm(context: Context, delayMinutes: Int) {
        ensureChannels(context)
        val triggerAt = System.currentTimeMillis() + delayMinutes.coerceIn(1, 30) * 60_000L
        val intent = Intent(context, SadhanaAlarmReceiver::class.java).apply {
            putExtra(EXTRA_ALARM_TYPE, TYPE_WAKE)
            putExtra(EXTRA_ALARM_TITLE, "Follow-up Wake-Up Alarm")
            putExtra(EXTRA_ALARM_BODY, "Repeat reminder: please confirm your Brahma Muhurta check-in.")
        }
        val pi = PendingIntent.getBroadcast(
            context,
            REQ_WAKE_REPEAT,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        scheduleTrigger(context, triggerAt, pi)
    }

    fun scheduleOneShotTaskReminder(context: Context, reqCode: Int, triggerAtMs: Long, title: String, body: String) {
        if (triggerAtMs <= System.currentTimeMillis()) return
        ensureChannels(context)
        val intent = Intent(context, SadhanaAlarmReceiver::class.java).apply {
            putExtra(EXTRA_ALARM_TYPE, TYPE_TASK_REMINDER)
            putExtra(EXTRA_ALARM_TITLE, title)
            putExtra(EXTRA_ALARM_BODY, body)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            reqCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        scheduleTrigger(context, triggerAtMs, pi)
    }

    fun scheduleDailyAlarm(
        context: Context,
        requestCode: Int,
        hhmm: String,
        type: String,
        title: String,
        body: String
    ) {
        val parts = hhmm.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull()?.coerceIn(0, 23) ?: 5
        val minute = parts.getOrNull(1)?.toIntOrNull()?.coerceIn(0, 59) ?: 0

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 5_000L) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val intent = Intent(context, SadhanaAlarmReceiver::class.java).apply {
            putExtra(EXTRA_ALARM_TYPE, type)
            putExtra(EXTRA_ALARM_TITLE, title)
            putExtra(EXTRA_ALARM_BODY, body)
            putExtra(EXTRA_TIME_HHMM, hhmm)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        scheduleTrigger(context, cal.timeInMillis, pi)
    }

    private fun scheduleTrigger(context: Context, triggerAtMs: Long, pi: PendingIntent) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
        }
    }

    private fun cancelAlarm(context: Context, requestCode: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            context,
            requestCode,
            Intent(context, SadhanaAlarmReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) am.cancel(pi)
    }
}
