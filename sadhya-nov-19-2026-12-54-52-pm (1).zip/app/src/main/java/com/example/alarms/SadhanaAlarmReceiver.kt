package com.example.alarms

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R

class SadhanaAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmScheduler.ensureChannels(context)
        val type = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_TYPE) ?: AlarmScheduler.TYPE_TASK_REMINDER
        val title = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_TITLE) ?: "Sadhana Reminder"
        val body = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_BODY) ?: "Time for your scheduled devotional activity."
        val hhmm = intent.getStringExtra(AlarmScheduler.EXTRA_TIME_HHMM)

        // Reschedule daily recurring alarms for tomorrow
        if (!hhmm.isNullOrBlank()) {
            val reqCode = when (type) {
                AlarmScheduler.TYPE_WAKE -> 1001
                AlarmScheduler.TYPE_GAYATRI_MORNING -> 1011
                AlarmScheduler.TYPE_GAYATRI_AFTERNOON -> 1012
                AlarmScheduler.TYPE_GAYATRI_EVENING -> 1013
                AlarmScheduler.TYPE_BEDTIME_WRAP -> 1021
                AlarmScheduler.TYPE_BEDTIME_PREP -> 1022
                AlarmScheduler.TYPE_BEDTIME_SLEEP -> 1023
                else -> null
            }
            if (reqCode != null) {
                AlarmScheduler.scheduleDailyAlarm(context, reqCode, hhmm, type, title, body)
            }
        }

        val isWake = type == AlarmScheduler.TYPE_WAKE
        val targetIntent = if (isWake) {
            Intent(context, WakeUpAlarmActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
        } else {
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
        }

        val contentPi = PendingIntent.getActivity(
            context,
            type.hashCode(),
            targetIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val channelId = if (isWake) AlarmScheduler.CHANNEL_WAKE else AlarmScheduler.CHANNEL_REMINDER
        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(contentPi)
            .setPriority(if (isWake) NotificationCompat.PRIORITY_MAX else NotificationCompat.PRIORITY_DEFAULT)

        if (isWake) {
            builder.setCategory(NotificationCompat.CATEGORY_ALARM)
                .setFullScreenIntent(contentPi, true)
            // Also attempt direct launch if allowed
            runCatching { context.startActivity(targetIntent) }
        }

        val canNotify = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (canNotify) {
            NotificationManagerCompat.from(context).notify(type.hashCode(), builder.build())
        }
    }
}
