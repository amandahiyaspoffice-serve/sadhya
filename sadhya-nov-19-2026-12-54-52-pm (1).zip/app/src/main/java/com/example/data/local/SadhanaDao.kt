package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SadhanaDao {

    // Private Wake-up Check-ins
    @Query("SELECT * FROM private_checkins ORDER BY createdEpochMs DESC LIMIT 60")
    fun observeCheckIns(): Flow<List<PrivateCheckInEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCheckIn(entity: PrivateCheckInEntity)

    // Focus Rules
    @Query("SELECT * FROM focus_rules ORDER BY appName ASC")
    fun observeFocusRules(): Flow<List<FocusRuleEntity>>

    @Query("SELECT * FROM focus_rules WHERE blockedDuringFocus = 1")
    suspend fun getBlockedFocusRulesSync(): List<FocusRuleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFocusRule(rule: FocusRuleEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertDefaultFocusRules(rules: List<FocusRuleEntity>)

    @Query("UPDATE focus_rules SET lastExceptionUntilMs = :untilMs WHERE packageName = :pkg")
    suspend fun setTemporaryException(pkg: String, untilMs: Long)

    @Query("DELETE FROM focus_rules WHERE packageName = :pkg")
    suspend fun deleteFocusRule(pkg: String)

    // Imported ICS Calendar Events
    @Query("SELECT * FROM imported_calendar_events ORDER BY dateIso ASC")
    fun observeImportedEvents(): Flow<List<ImportedCalendarEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImportedEvents(events: List<ImportedCalendarEventEntity>)

    @Query("DELETE FROM imported_calendar_events")
    suspend fun clearImportedEvents()
}
