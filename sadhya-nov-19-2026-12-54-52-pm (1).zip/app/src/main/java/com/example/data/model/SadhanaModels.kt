package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class RoutineMode(val label: String, val subtitle: String) {
    TEMPLE_RESIDENT("Temple Resident", "Traditional ashram & temple schedule"),
    CONGREGATIONAL("Congregational", "Family, work & spiritual balance"),
    STUDENT_PRO("Student / Pro", "Classes, office, exercise & sadhana")
}

enum class ScheduleCategory(val label: String) {
    SPIRITUAL("Spiritual"),
    SEVA("Seva"),
    WORK_STUDY("Work / Study"),
    HEALTH("Health"),
    REST("Rest"),
    FESTIVAL("Festival")
}

enum class TaskRepeatFrequency(val label: String) {
    ONCE("One-time"),
    DAILY("Daily"),
    WEEKLY("Weekly"),
    EKADASHI("Every Ekadashi")
}

enum class TaskPriority(val label: String) {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High")
}

enum class FocusStrictness(val label: String, val description: String, val holdSeconds: Int) {
    GENTLE("Gentle", "Mindful pause with immediate bypass option", 0),
    BALANCED("Balanced", "Requires brief written reflection for exceptions", 5),
    STRICT("Strict", "Requires 10-second reflection; emergency bypass disabled", 10)
}

enum class CalendarTradition(val label: String) {
    ISKCON_MAYAPUR("ISKCON / Mayapur (GCal)"),
    GAUDIYA_MATH("Gaudiya Math"),
    VRINDAVAN("Vrindavan Panchanga")
}

enum class ThemeStyle(val label: String) {
    IVORY_MAROON("Ivory & Maroon"),
    SAFFRON_SAND("Saffron & Sand"),
    VRINDAVAN_FOREST("Vrindavan Forest")
}

enum class DarkModePreference(val label: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark")
}

enum class FontScaleLevel(val label: String) {
    COMPACT("Compact"),
    NORMAL("Standard"),
    LARGE("Large")
}

enum class WakeUpStatus(val label: String) {
    PENDING("Pending"),
    ON_TIME("On Time"),
    LATE("Late"),
    MISSED("Missed")
}

enum class WakeUpMethod(val label: String) {
    NONE("Not Checked In"),
    SELFIE("Private Selfie"),
    MANTRA_CHECKIN("Mantra Affirmation")
}

enum class FocusOutcome(val label: String) {
    RETURNED("Returned to Sadhana"),
    TEMP_EXCEPTION("Temporary Exception"),
    EMERGENCY_BYPASS("Emergency Bypass")
}

enum class TemplePostType(val label: String) {
    ANNOUNCEMENT("Announcement"),
    FESTIVAL("Festival"),
    LECTURE("Lecture"),
    SEVA("Seva Volunteer")
}

inline fun <reified T : Enum<T>> safeEnumValueOf(raw: String?, default: T): T {
    if (raw.isNullOrBlank()) return default
    return enumValues<T>().firstOrNull { it.name == raw } ?: default
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "Devotee",
    val email: String = "",
    val routineMode: String = RoutineMode.CONGREGATIONAL.name,
    val wakeTime: String = "04:30",
    val sleepTime: String = "22:00",
    val japaTargetRounds: Long = 16L,
    val readingTargetMinutes: Long = 30L,
    val hearingTargetMinutes: Long = 30L,
    val attendOnlineMangalAarti: Boolean = true,
    val gayatriInitiated: Boolean = false,
    val gayatriMorningTime: String = "06:00",
    val gayatriAfternoonTime: String = "12:15",
    val gayatriEveningTime: String = "18:15",
    val responsibilities: List<String> = emptyList(),
    val distractingPackages: List<String> = listOf(
        "com.instagram.android",
        "com.google.android.youtube",
        "com.facebook.katana",
        "com.android.chrome"
    ),
    val focusStrictness: String = FocusStrictness.BALANCED.name,
    val calendarTradition: String = CalendarTradition.ISKCON_MAYAPUR.name,
    val locationName: String = "Sri Mayapur, India",
    val latitude: Double = 23.4231,
    val longitude: Double = 88.3880,
    val timezoneId: String = java.util.TimeZone.getDefault().id,
    val followedTempleId: String = "",
    val activeFestivalMode: String = "",
    val themeStyle: String = ThemeStyle.IVORY_MAROON.name,
    val darkModePreference: String = DarkModePreference.SYSTEM.name,
    val fontScaleLevel: String = FontScaleLevel.NORMAL.name,
    val bedtimeModeEnabled: Boolean = true,
    val onboardingCompleted: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun routineModeEnum(): RoutineMode = safeEnumValueOf(routineMode, RoutineMode.CONGREGATIONAL)
    fun strictnessEnum(): FocusStrictness = safeEnumValueOf(focusStrictness, FocusStrictness.BALANCED)
    fun traditionEnum(): CalendarTradition = safeEnumValueOf(calendarTradition, CalendarTradition.ISKCON_MAYAPUR)
    fun themeStyleEnum(): ThemeStyle = safeEnumValueOf(themeStyle, ThemeStyle.IVORY_MAROON)
    fun darkModeEnum(): DarkModePreference = safeEnumValueOf(darkModePreference, DarkModePreference.SYSTEM)
    fun fontScaleEnum(): FontScaleLevel = safeEnumValueOf(fontScaleLevel, FontScaleLevel.NORMAL)

    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "displayName" to displayName.ifBlank { "Devotee" }.take(80),
        "email" to email.take(120),
        "routineMode" to routineMode,
        "wakeTime" to wakeTime.ifBlank { "04:30" }.take(8),
        "sleepTime" to sleepTime.ifBlank { "22:00" }.take(8),
        "japaTargetRounds" to japaTargetRounds.coerceIn(1L, 192L),
        "readingTargetMinutes" to readingTargetMinutes.coerceIn(0L, 600L),
        "hearingTargetMinutes" to hearingTargetMinutes.coerceIn(0L, 600L),
        "attendOnlineMangalAarti" to attendOnlineMangalAarti,
        "gayatriInitiated" to gayatriInitiated,
        "gayatriMorningTime" to gayatriMorningTime.take(8),
        "gayatriAfternoonTime" to gayatriAfternoonTime.take(8),
        "gayatriEveningTime" to gayatriEveningTime.take(8),
        "responsibilities" to responsibilities.take(15).map { it.take(80) },
        "distractingPackages" to distractingPackages.take(30).map { it.take(160) },
        "focusStrictness" to focusStrictness,
        "calendarTradition" to calendarTradition,
        "locationName" to locationName.take(100),
        "latitude" to latitude.coerceIn(-90.0, 90.0),
        "longitude" to longitude.coerceIn(-180.0, 180.0),
        "timezoneId" to timezoneId.ifBlank { "UTC" }.take(64),
        "followedTempleId" to followedTempleId.take(128),
        "activeFestivalMode" to activeFestivalMode.take(64),
        "themeStyle" to themeStyle,
        "darkModePreference" to darkModePreference,
        "fontScaleLevel" to fontScaleLevel,
        "bedtimeModeEnabled" to bedtimeModeEnabled,
        "onboardingCompleted" to onboardingCompleted,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class ScheduleItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val description: String = "",
    val startTime: String = "05:00",
    val endTime: String = "06:00",
    val category: String = ScheduleCategory.SPIRITUAL.name,
    val routineMode: String = RoutineMode.CONGREGATIONAL.name,
    val essential: Boolean = false,
    val reminderEnabled: Boolean = true,
    val completedToday: Boolean = false,
    val lastCompletedDate: String = "",
    val sortOrder: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun categoryEnum(): ScheduleCategory = safeEnumValueOf(category, ScheduleCategory.SPIRITUAL)

    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "title" to title.trim().ifBlank { "Activity" }.take(120),
        "description" to description.trim().take(500),
        "startTime" to startTime.ifBlank { "05:00" }.take(8),
        "endTime" to endTime.ifBlank { "06:00" }.take(8),
        "category" to category,
        "routineMode" to routineMode,
        "essential" to essential,
        "reminderEnabled" to reminderEnabled,
        "completedToday" to completedToday,
        "lastCompletedDate" to lastCompletedDate.take(16),
        "sortOrder" to sortOrder.coerceIn(0L, 1000L),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class DailyTask(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val description: String = "",
    val dateIso: String = "",
    val startTime: String = "",
    val endTime: String = "",
    val repeatFrequency: String = TaskRepeatFrequency.ONCE.name,
    val reminderEnabled: Boolean = true,
    val priority: String = TaskPriority.MEDIUM.name,
    val completed: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun priorityEnum(): TaskPriority = safeEnumValueOf(priority, TaskPriority.MEDIUM)
    fun repeatEnum(): TaskRepeatFrequency = safeEnumValueOf(repeatFrequency, TaskRepeatFrequency.ONCE)

    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "title" to title.trim().ifBlank { "Task" }.take(140),
        "description" to description.trim().take(600),
        "dateIso" to dateIso.ifBlank { "2026-11-18" }.take(16),
        "startTime" to startTime.take(8),
        "endTime" to endTime.take(8),
        "repeatFrequency" to repeatFrequency,
        "reminderEnabled" to reminderEnabled,
        "priority" to priority,
        "completed" to completed,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class SadhanaDailyLog(
    @DocumentId val id: String = "",
    val userId: String = "",
    val dateIso: String = "",
    val roundsChanted: Long = 0L,
    val targetRounds: Long = 16L,
    val readingMinutes: Long = 0L,
    val hearingMinutes: Long = 0L,
    val mangalAartiAttended: Boolean = false,
    val gayatriMorningDone: Boolean = false,
    val gayatriAfternoonDone: Boolean = false,
    val gayatriEveningDone: Boolean = false,
    val sevaMinutes: Long = 0L,
    val sevaNotes: String = "",
    val wakeUpStatus: String = WakeUpStatus.PENDING.name,
    val wakeUpActualTime: String = "",
    val wakeUpMethod: String = WakeUpMethod.NONE.name,
    val wakeUpReflection: String = "",
    val focusMinutes: Long = 0L,
    val distractionsBlocked: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun wakeUpStatusEnum(): WakeUpStatus = safeEnumValueOf(wakeUpStatus, WakeUpStatus.PENDING)
    fun wakeUpMethodEnum(): WakeUpMethod = safeEnumValueOf(wakeUpMethod, WakeUpMethod.NONE)

    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "dateIso" to dateIso.take(16),
        "roundsChanted" to roundsChanted.coerceIn(0L, 300L),
        "targetRounds" to targetRounds.coerceIn(1L, 300L),
        "readingMinutes" to readingMinutes.coerceIn(0L, 720L),
        "hearingMinutes" to hearingMinutes.coerceIn(0L, 720L),
        "mangalAartiAttended" to mangalAartiAttended,
        "gayatriMorningDone" to gayatriMorningDone,
        "gayatriAfternoonDone" to gayatriAfternoonDone,
        "gayatriEveningDone" to gayatriEveningDone,
        "sevaMinutes" to sevaMinutes.coerceIn(0L, 720L),
        "sevaNotes" to sevaNotes.take(300),
        "wakeUpStatus" to wakeUpStatus,
        "wakeUpActualTime" to wakeUpActualTime.take(16),
        "wakeUpMethod" to wakeUpMethod,
        "wakeUpReflection" to wakeUpReflection.take(500),
        "focusMinutes" to focusMinutes.coerceIn(0L, 1440L),
        "distractionsBlocked" to distractionsBlocked.coerceIn(0L, 500L),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class FocusLog(
    @DocumentId val id: String = "",
    val userId: String = "",
    val packageName: String = "",
    val appName: String = "",
    val scheduledActivity: String = "",
    val userReason: String = "",
    val outcome: String = FocusOutcome.RETURNED.name,
    val durationMinutes: Long = 0L,
    val dateIso: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    fun outcomeEnum(): FocusOutcome = safeEnumValueOf(outcome, FocusOutcome.RETURNED)

    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "userId" to uid,
        "packageName" to packageName.ifBlank { "unknown" }.take(160),
        "appName" to appName.ifBlank { "App" }.take(80),
        "scheduledActivity" to scheduledActivity.take(120),
        "userReason" to userReason.take(500),
        "outcome" to outcome,
        "durationMinutes" to durationMinutes.coerceIn(0L, 480L),
        "dateIso" to dateIso.take(16),
        "createdAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class TempleCommunity(
    @DocumentId val id: String = "",
    val name: String = "",
    val city: String = "",
    val tradition: String = "ISKCON",
    val adminUid: String = "",
    val adminName: String = "",
    val mangalAartiTime: String = "04:30",
    val tulasiAartiTime: String = "05:00",
    val darshanTime: String = "07:15",
    val bhagavatamClassTime: String = "08:00",
    val sandhyaAartiTime: String = "18:30",
    val description: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(uid: String): Map<String, Any> = mapOf(
        "name" to name.trim().take(120),
        "city" to city.trim().take(80),
        "tradition" to tradition.trim().take(60),
        "adminUid" to uid,
        "adminName" to adminName.trim().ifBlank { "Temple Admin" }.take(80),
        "mangalAartiTime" to mangalAartiTime.take(8),
        "tulasiAartiTime" to tulasiAartiTime.take(8),
        "darshanTime" to darshanTime.take(8),
        "bhagavatamClassTime" to bhagavatamClassTime.take(8),
        "sandhyaAartiTime" to sandhyaAartiTime.take(8),
        "description" to description.trim().take(600),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class TemplePost(
    @DocumentId val id: String = "",
    val templeId: String = "",
    val authorUid: String = "",
    val authorName: String = "",
    val postType: String = TemplePostType.ANNOUNCEMENT.name,
    val title: String = "",
    val body: String = "",
    val eventDate: String = "",
    val eventTime: String = "",
    val sevaSlotsTotal: Long = 0L,
    val volunteerUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun postTypeEnum(): TemplePostType = safeEnumValueOf(postType, TemplePostType.ANNOUNCEMENT)

    fun toCreateMap(uid: String, targetTempleId: String): Map<String, Any> = mapOf(
        "templeId" to targetTempleId,
        "authorUid" to uid,
        "authorName" to authorName.trim().ifBlank { "Temple Admin" }.take(80),
        "postType" to postType,
        "title" to title.trim().take(140),
        "body" to body.trim().take(1000),
        "eventDate" to eventDate.take(24),
        "eventTime" to eventTime.take(24),
        "sevaSlotsTotal" to sevaSlotsTotal.coerceIn(0L, 500L),
        "volunteerUids" to volunteerUids.take(50),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}
