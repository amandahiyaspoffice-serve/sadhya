package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.sadhanaDataStore: DataStore<Preferences> by preferencesDataStore(name = "sadhana_prefs")

data class LocalAlarmFocusState(
    val wakeAlarmEnabled: Boolean = true,
    val wakeTime: String = "04:30",
    val sleepTime: String = "22:00",
    val repeatAlarmMinutes: Int = 5,
    val gayatriEnabled: Boolean = false,
    val gayatriMorning: String = "06:00",
    val gayatriAfternoon: String = "12:15",
    val gayatriEvening: String = "18:15",
    val bedtimeRemindersEnabled: Boolean = true,
    val focusShieldActive: Boolean = false,
    val focusEndEpochMs: Long = 0L,
    val currentScheduledActivity: String = "Daily Sadhana",
    val strictness: String = "BALANCED",
    val japaBeadCount: Int = 0,
    val showQuickMediaCard: Boolean = true,
    val showWakeUpCard: Boolean = true,
    val guestModeEnabled: Boolean = false
)

class PreferencesManager(private val context: Context) {

    private object Keys {
        val WAKE_ALARM_ENABLED = booleanPreferencesKey("wake_alarm_enabled")
        val WAKE_TIME = stringPreferencesKey("wake_time")
        val SLEEP_TIME = stringPreferencesKey("sleep_time")
        val REPEAT_ALARM_MIN = intPreferencesKey("repeat_alarm_min")
        val GAYATRI_ENABLED = booleanPreferencesKey("gayatri_enabled")
        val GAYATRI_MORNING = stringPreferencesKey("gayatri_morning")
        val GAYATRI_AFTERNOON = stringPreferencesKey("gayatri_afternoon")
        val GAYATRI_EVENING = stringPreferencesKey("gayatri_evening")
        val BEDTIME_ENABLED = booleanPreferencesKey("bedtime_enabled")
        val FOCUS_SHIELD_ACTIVE = booleanPreferencesKey("focus_shield_active")
        val FOCUS_END_EPOCH = longPreferencesKey("focus_end_epoch")
        val CURRENT_ACTIVITY = stringPreferencesKey("current_activity")
        val STRICTNESS = stringPreferencesKey("strictness")
        val JAPA_BEAD_COUNT = intPreferencesKey("japa_bead_count")
        val SHOW_MEDIA_CARD = booleanPreferencesKey("show_media_card")
        val SHOW_WAKE_CARD = booleanPreferencesKey("show_wake_card")
        val GUEST_MODE_ENABLED = booleanPreferencesKey("guest_mode_enabled")
    }

    val stateFlow: Flow<LocalAlarmFocusState> = context.sadhanaDataStore.data.map { prefs ->
        LocalAlarmFocusState(
            wakeAlarmEnabled = prefs[Keys.WAKE_ALARM_ENABLED] ?: true,
            wakeTime = prefs[Keys.WAKE_TIME] ?: "04:30",
            sleepTime = prefs[Keys.SLEEP_TIME] ?: "22:00",
            repeatAlarmMinutes = prefs[Keys.REPEAT_ALARM_MIN] ?: 5,
            gayatriEnabled = prefs[Keys.GAYATRI_ENABLED] ?: false,
            gayatriMorning = prefs[Keys.GAYATRI_MORNING] ?: "06:00",
            gayatriAfternoon = prefs[Keys.GAYATRI_AFTERNOON] ?: "12:15",
            gayatriEvening = prefs[Keys.GAYATRI_EVENING] ?: "18:15",
            bedtimeRemindersEnabled = prefs[Keys.BEDTIME_ENABLED] ?: true,
            focusShieldActive = prefs[Keys.FOCUS_SHIELD_ACTIVE] ?: false,
            focusEndEpochMs = prefs[Keys.FOCUS_END_EPOCH] ?: 0L,
            currentScheduledActivity = prefs[Keys.CURRENT_ACTIVITY] ?: "Daily Sadhana",
            strictness = prefs[Keys.STRICTNESS] ?: "BALANCED",
            japaBeadCount = prefs[Keys.JAPA_BEAD_COUNT] ?: 0,
            showQuickMediaCard = prefs[Keys.SHOW_MEDIA_CARD] ?: true,
            showWakeUpCard = prefs[Keys.SHOW_WAKE_CARD] ?: true,
            guestModeEnabled = prefs[Keys.GUEST_MODE_ENABLED] ?: false
        )
    }

    suspend fun getSnapshot(): LocalAlarmFocusState = stateFlow.first()

    suspend fun updateWakeConfig(enabled: Boolean, wakeTime: String, repeatMinutes: Int = 5) {
        context.sadhanaDataStore.edit { prefs ->
            prefs[Keys.WAKE_ALARM_ENABLED] = enabled
            prefs[Keys.WAKE_TIME] = wakeTime
            prefs[Keys.REPEAT_ALARM_MIN] = repeatMinutes
        }
    }

    suspend fun updateBedtimeConfig(enabled: Boolean, sleepTime: String) {
        context.sadhanaDataStore.edit { prefs ->
            prefs[Keys.BEDTIME_ENABLED] = enabled
            prefs[Keys.SLEEP_TIME] = sleepTime
        }
    }

    suspend fun updateGayatriConfig(enabled: Boolean, morning: String, afternoon: String, evening: String) {
        context.sadhanaDataStore.edit { prefs ->
            prefs[Keys.GAYATRI_ENABLED] = enabled
            prefs[Keys.GAYATRI_MORNING] = morning
            prefs[Keys.GAYATRI_AFTERNOON] = afternoon
            prefs[Keys.GAYATRI_EVENING] = evening
        }
    }

    suspend fun setFocusShield(active: Boolean, endEpochMs: Long, currentActivity: String, strictness: String) {
        context.sadhanaDataStore.edit { prefs ->
            prefs[Keys.FOCUS_SHIELD_ACTIVE] = active
            prefs[Keys.FOCUS_END_EPOCH] = endEpochMs
            prefs[Keys.CURRENT_ACTIVITY] = currentActivity
            prefs[Keys.STRICTNESS] = strictness
        }
    }

    suspend fun setJapaBeadCount(count: Int) {
        context.sadhanaDataStore.edit { it[Keys.JAPA_BEAD_COUNT] = count.coerceIn(0, 107) }
    }

    suspend fun updateHomeCustomization(showMedia: Boolean, showWake: Boolean) {
        context.sadhanaDataStore.edit { prefs ->
            prefs[Keys.SHOW_MEDIA_CARD] = showMedia
            prefs[Keys.SHOW_WAKE_CARD] = showWake
        }
    }

    suspend fun setGuestModeEnabled(enabled: Boolean) {
        context.sadhanaDataStore.edit { prefs ->
            prefs[Keys.GUEST_MODE_ENABLED] = enabled
        }
    }
}
