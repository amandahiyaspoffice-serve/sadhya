package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "private_checkins")
data class PrivateCheckInEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val dateIso: String,
    val actualTime: String,
    val targetTime: String,
    val status: String, // ON_TIME, LATE, MISSED
    val method: String, // SELFIE, MANTRA_CHECKIN
    val privatePhotoPath: String?, // Stored strictly in app-private filesDir, never shared
    val reflectionNote: String,
    val createdEpochMs: Long = System.currentTimeMillis()
)

@Entity(tableName = "focus_rules")
data class FocusRuleEntity(
    @PrimaryKey val packageName: String,
    val appName: String,
    val blockedDuringFocus: Boolean = true,
    val blockedDuringBedtime: Boolean = true,
    val lastExceptionUntilMs: Long = 0L
)

@Entity(tableName = "imported_calendar_events")
data class ImportedCalendarEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val dateIso: String,
    val title: String,
    val description: String,
    val paranaInfo: String,
    val sourceLabel: String
)
