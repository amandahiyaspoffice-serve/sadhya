package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.model.DailyTask
import com.example.data.model.FocusLog
import com.example.data.model.RoutineTemplates
import com.example.data.model.SadhanaDailyLog
import com.example.data.model.ScheduleItem
import com.example.data.model.TempleCommunity
import com.example.data.model.TemplePost
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class SadhanaFirestoreRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) : SadhanaDataRepository {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun <T> Flow<T>.wrapFirestoreErrors(op: OperationType, path: String, uid: String): Flow<T> =
        this.catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val exceptionToLog = firestoreError ?: (error as? Exception)
            if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                handleFirestoreError(exceptionToLog, op, path)
            }
            throw error
        }

    // --- USER PROFILE ---
    override fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val uid = requireUserId()
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    } else null
                }
                .wrapFirestoreErrors(OperationType.GET, path, uid)
        )
    }

    override suspend fun ensureUserProfileExists(
        userId: String,
        displayName: String,
        email: String
    ): Result<UserProfile> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Authenticated UID mismatch." }
            val docRef = db.collection("users").document(uid)
            val snap = docRef.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                if (existing != null) return Result.success(existing)
            }
            val initial = UserProfile(
                userId = uid,
                displayName = displayName.ifBlank { "Devotee" }.take(80),
                email = email.take(120)
            )
            docRef.set(initial.toCreateMap(uid)).await()
            // Also seed default schedule items if empty
            val schedSnap = docRef.collection("schedule_items").limit(1).get().await()
            if (schedSnap.isEmpty) {
                seedScheduleForProfile(uid, initial)
            }
            Result.success(initial)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    override suspend fun updateUserProfileFields(userId: String, updates: Map<String, Any>): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Cross-user profile write blocked." }
            val payload = updates.toMutableMap()
            payload["updatedAt"] = FieldValue.serverTimestamp()
            db.collection("users").document(uid).update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- SCHEDULE ITEMS ---
    override fun observeScheduleItems(userId: String): Flow<List<ScheduleItem>> = flow {
        val uid = requireUserId()
        val path = "users/$userId/schedule_items"
        emitAll(
            db.collection("users").document(userId).collection("schedule_items")
                .orderBy("startTime", Query.Direction.ASCENDING)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ScheduleItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .wrapFirestoreErrors(OperationType.LIST, path, uid)
        )
    }

    override suspend fun seedScheduleForProfile(userId: String, profile: UserProfile): Result<Unit> {
        val items = RoutineTemplates.generateDefaultSchedule(profile)
        return replaceScheduleItems(userId, items, keepEssentialExisting = false)
    }

    override suspend fun replaceScheduleItems(
        userId: String,
        newItems: List<ScheduleItem>,
        keepEssentialExisting: Boolean
    ): Result<Unit> {
        val path = "users/$userId/schedule_items"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "UID mismatch" }
            val colRef = db.collection("users").document(uid).collection("schedule_items")
            val existing = colRef.get().await()
            val batch = db.batch()
            val existingDocs = existing.documents
            existingDocs.forEach { doc ->
                val isEssential = doc.getBoolean("essential") ?: false
                if (!keepEssentialExisting || !isEssential) {
                    batch.delete(doc.reference)
                }
            }
            newItems.forEachIndexed { idx, item ->
                val docId = "sched_${UUID.randomUUID().toString().replace("-", "").take(16)}"
                val finalItem = item.copy(sortOrder = (idx + 1).toLong())
                batch.set(colRef.document(docId), finalItem.toCreateMap(uid))
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    override suspend fun addScheduleItem(userId: String, item: ScheduleItem): Result<Unit> {
        val docId = "sched_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "users/$userId/schedule_items/$docId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "UID mismatch" }
            db.collection("users").document(uid).collection("schedule_items")
                .document(docId)
                .set(item.toCreateMap(uid))
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    override suspend fun updateScheduleItem(userId: String, itemId: String, updates: Map<String, Any>): Result<Unit> {
        val path = "users/$userId/schedule_items/$itemId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "UID mismatch" }
            require(itemId.isNotBlank()) { "Schedule ID required" }
            val payload = updates.toMutableMap()
            payload["updatedAt"] = FieldValue.serverTimestamp()
            db.collection("users").document(uid).collection("schedule_items")
                .document(itemId).update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    override suspend fun deleteScheduleItem(userId: String, itemId: String): Result<Unit> {
        val path = "users/$userId/schedule_items/$itemId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "UID mismatch" }
            require(itemId.isNotBlank()) { "Schedule ID required" }
            db.collection("users").document(uid).collection("schedule_items")
                .document(itemId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- PERSONAL TASKS ---
    override fun observeTasks(userId: String): Flow<List<DailyTask>> = flow {
        val uid = requireUserId()
        val path = "users/$userId/tasks"
        emitAll(
            db.collection("users").document(userId).collection("tasks")
                .orderBy("dateIso", Query.Direction.ASCENDING)
                .snapshots()
                .map { snap ->
                    snap.toObjects(DailyTask::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .wrapFirestoreErrors(OperationType.LIST, path, uid)
        )
    }

    override suspend fun addTask(userId: String, task: DailyTask): Result<String> {
        val docId = "task_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "users/$userId/tasks/$docId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "UID mismatch" }
            db.collection("users").document(uid).collection("tasks")
                .document(docId)
                .set(task.toCreateMap(uid))
                .await()
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    override suspend fun updateTask(userId: String, taskId: String, updates: Map<String, Any>): Result<Unit> {
        val path = "users/$userId/tasks/$taskId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "UID mismatch" }
            require(taskId.isNotBlank()) { "Task ID required" }
            val payload = updates.toMutableMap()
            payload["updatedAt"] = FieldValue.serverTimestamp()
            db.collection("users").document(uid).collection("tasks")
                .document(taskId).update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    override suspend fun deleteTask(userId: String, taskId: String): Result<Unit> {
        val path = "users/$userId/tasks/$taskId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "UID mismatch" }
            require(taskId.isNotBlank()) { "Task ID required" }
            db.collection("users").document(uid).collection("tasks")
                .document(taskId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- SADHANA DAILY LOGS ---
    override fun observeSadhanaLogs(userId: String): Flow<List<SadhanaDailyLog>> = flow {
        val uid = requireUserId()
        val path = "users/$userId/sadhana_logs"
        emitAll(
            db.collection("users").document(userId).collection("sadhana_logs")
                .orderBy("dateIso", Query.Direction.DESCENDING)
                .limit(31)
                .snapshots()
                .map { snap ->
                    snap.toObjects(SadhanaDailyLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .wrapFirestoreErrors(OperationType.LIST, path, uid)
        )
    }

    override suspend fun upsertSadhanaLog(userId: String, dateIso: String, log: SadhanaDailyLog): Result<Unit> {
        val path = "users/$userId/sadhana_logs/$dateIso"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "UID mismatch" }
            val docRef = db.collection("users").document(uid).collection("sadhana_logs").document(dateIso)
            val snap = docRef.get().await()
            if (snap.exists()) {
                val updates = mapOf(
                    "dateIso" to dateIso,
                    "roundsChanted" to log.roundsChanted.coerceIn(0L, 300L),
                    "targetRounds" to log.targetRounds.coerceIn(1L, 300L),
                    "readingMinutes" to log.readingMinutes.coerceIn(0L, 720L),
                    "hearingMinutes" to log.hearingMinutes.coerceIn(0L, 720L),
                    "mangalAartiAttended" to log.mangalAartiAttended,
                    "gayatriMorningDone" to log.gayatriMorningDone,
                    "gayatriAfternoonDone" to log.gayatriAfternoonDone,
                    "gayatriEveningDone" to log.gayatriEveningDone,
                    "sevaMinutes" to log.sevaMinutes.coerceIn(0L, 720L),
                    "sevaNotes" to log.sevaNotes.take(300),
                    "wakeUpStatus" to log.wakeUpStatus,
                    "wakeUpActualTime" to log.wakeUpActualTime.take(16),
                    "wakeUpMethod" to log.wakeUpMethod,
                    "wakeUpReflection" to log.wakeUpReflection.take(500),
                    "focusMinutes" to log.focusMinutes.coerceIn(0L, 1440L),
                    "distractionsBlocked" to log.distractionsBlocked.coerceIn(0L, 500L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            } else {
                docRef.set(log.copy(dateIso = dateIso).toCreateMap(uid)).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    // --- FOCUS LOGS ---
    override fun observeFocusLogs(userId: String): Flow<List<FocusLog>> = flow {
        val uid = requireUserId()
        val path = "users/$userId/focus_logs"
        emitAll(
            db.collection("users").document(userId).collection("focus_logs")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(50)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FocusLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .wrapFirestoreErrors(OperationType.LIST, path, uid)
        )
    }

    override suspend fun addFocusLog(userId: String, log: FocusLog): Result<Unit> {
        val docId = "focus_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "users/$userId/focus_logs/$docId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "UID mismatch" }
            db.collection("users").document(uid).collection("focus_logs")
                .document(docId)
                .set(log.toCreateMap(uid))
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    // --- TEMPLE COMMUNITY ---
    override fun observeTemples(userId: String): Flow<List<TempleCommunity>> = flow {
        val uid = requireUserId()
        val path = "temples"
        emitAll(
            db.collection("temples")
                .orderBy("name", Query.Direction.ASCENDING)
                .snapshots()
                .map { snap ->
                    snap.toObjects(TempleCommunity::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .wrapFirestoreErrors(OperationType.LIST, path, uid)
        )
    }

    override fun observeTemplePosts(userId: String, templeId: String): Flow<List<TemplePost>> = flow {
        val uid = requireUserId()
        val path = "temples/$templeId/posts"
        emitAll(
            db.collection("temples").document(templeId).collection("posts")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snap ->
                    snap.toObjects(TemplePost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .wrapFirestoreErrors(OperationType.LIST, path, uid)
        )
    }

    override suspend fun createTemple(temple: TempleCommunity): Result<String> {
        val templeId = "temple_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "temples/$templeId"
        return try {
            val uid = requireUserId()
            db.collection("temples").document(templeId)
                .set(temple.toCreateMap(uid))
                .await()
            Result.success(templeId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    override suspend fun updateTempleTimings(templeId: String, updates: Map<String, Any>): Result<Unit> {
        val path = "temples/$templeId"
        return try {
            requireUserId()
            val payload = updates.toMutableMap()
            payload["updatedAt"] = FieldValue.serverTimestamp()
            db.collection("temples").document(templeId).update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    override suspend fun createTemplePost(templeId: String, post: TemplePost): Result<Unit> {
        val postId = "post_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "temples/$templeId/posts/$postId"
        return try {
            val uid = requireUserId()
            db.collection("temples").document(templeId).collection("posts")
                .document(postId)
                .set(post.toCreateMap(uid, templeId))
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    override suspend fun toggleSevaVolunteer(templeId: String, post: TemplePost): Result<Unit> {
        val path = "temples/$templeId/posts/${post.id}"
        return try {
            val uid = requireUserId()
            val currentList = post.volunteerUids
            val nextList = if (uid in currentList) {
                currentList - uid
            } else {
                (currentList + uid).take(50)
            }
            db.collection("temples").document(templeId).collection("posts")
                .document(post.id)
                .update(
                    mapOf(
                        "volunteerUids" to nextList,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }
}
