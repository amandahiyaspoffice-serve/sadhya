package com.example.data.remote

import com.example.data.model.DailyTask
import com.example.data.model.FocusLog
import com.example.data.model.SadhanaDailyLog
import com.example.data.model.ScheduleItem
import com.example.data.model.TempleCommunity
import com.example.data.model.TemplePost
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow

interface SadhanaDataRepository {
    fun observeUserProfile(userId: String): Flow<UserProfile?>
    suspend fun ensureUserProfileExists(userId: String, displayName: String, email: String): Result<UserProfile>
    suspend fun updateUserProfileFields(userId: String, updates: Map<String, Any>): Result<Unit>

    fun observeScheduleItems(userId: String): Flow<List<ScheduleItem>>
    suspend fun seedScheduleForProfile(userId: String, profile: UserProfile): Result<Unit>
    suspend fun replaceScheduleItems(
        userId: String,
        newItems: List<ScheduleItem>,
        keepEssentialExisting: Boolean = false
    ): Result<Unit>
    suspend fun addScheduleItem(userId: String, item: ScheduleItem): Result<Unit>
    suspend fun updateScheduleItem(userId: String, itemId: String, updates: Map<String, Any>): Result<Unit>
    suspend fun deleteScheduleItem(userId: String, itemId: String): Result<Unit>

    fun observeTasks(userId: String): Flow<List<DailyTask>>
    suspend fun addTask(userId: String, task: DailyTask): Result<String>
    suspend fun updateTask(userId: String, taskId: String, updates: Map<String, Any>): Result<Unit>
    suspend fun deleteTask(userId: String, taskId: String): Result<Unit>

    fun observeSadhanaLogs(userId: String): Flow<List<SadhanaDailyLog>>
    suspend fun upsertSadhanaLog(userId: String, dateIso: String, log: SadhanaDailyLog): Result<Unit>

    fun observeFocusLogs(userId: String): Flow<List<FocusLog>>
    suspend fun addFocusLog(userId: String, log: FocusLog): Result<Unit>

    fun observeTemples(userId: String): Flow<List<TempleCommunity>>
    fun observeTemplePosts(userId: String, templeId: String): Flow<List<TemplePost>>
    suspend fun createTemple(temple: TempleCommunity): Result<String>
    suspend fun updateTempleTimings(templeId: String, updates: Map<String, Any>): Result<Unit>
    suspend fun createTemplePost(templeId: String, post: TemplePost): Result<Unit>
    suspend fun toggleSevaVolunteer(templeId: String, post: TemplePost): Result<Unit>
}
