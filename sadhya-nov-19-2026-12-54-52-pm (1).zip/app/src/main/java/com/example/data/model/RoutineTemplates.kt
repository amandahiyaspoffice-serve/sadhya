package com.example.data.model

object RoutineTemplates {

    fun generateDefaultSchedule(profile: UserProfile): List<ScheduleItem> {
        val mode = profile.routineModeEnum()
        val wake = profile.wakeTime.ifBlank { "04:30" }
        val sleep = profile.sleepTime.ifBlank { "22:00" }
        val preWind = subtractMinutes(sleep, 30)
        val prepTomorrow = subtractMinutes(sleep, 15)

        val baseList = when (mode) {
            RoutineMode.TEMPLE_RESIDENT -> listOf(
                ScheduleItem(title = "Brahma Muhurta Wake Up & Bath", description = "Rise, freshen up & prepare for temple morning program", startTime = wake, endTime = addMinutes(wake, 30), category = ScheduleCategory.HEALTH.name, routineMode = mode.name, essential = true, sortOrder = 1),
                ScheduleItem(title = "Mangal Aarti & Nrsimha Prayers", description = "Morning deity darshan and temple prayers", startTime = "04:30", endTime = "05:00", category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 2),
                ScheduleItem(title = "Tulasi Aarti & Parikrama", description = "Offering prayers and circumambulation to Srimati Tulasi Devi", startTime = "05:00", endTime = "05:15", category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 3),
                ScheduleItem(title = "Japa Meditation (${profile.japaTargetRounds} Rounds)", description = "Attentive Hare Krishna Mahamantra chanting", startTime = "05:15", endTime = "07:00", category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 4),
                ScheduleItem(title = "Shringar Darshan & Guru Puja", description = "Greeting the Deities & Srila Prabhupada Guru Puja", startTime = "07:00", endTime = "08:00", category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 5),
                ScheduleItem(title = "Srimad Bhagavatam Class", description = "Morning scriptural hearing and discussion", startTime = "08:00", endTime = "09:00", category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 6),
                ScheduleItem(title = "Morning Prasadam", description = "Honor sanctified breakfast prasadam", startTime = "09:00", endTime = "09:30", category = ScheduleCategory.HEALTH.name, routineMode = mode.name, essential = false, sortOrder = 7),
                ScheduleItem(title = "Temple Seva & Assigned Duties", description = profile.responsibilities.firstOrNull() ?: "Morning temple seva and responsibilities", startTime = "09:30", endTime = "13:00", category = ScheduleCategory.SEVA.name, routineMode = mode.name, essential = false, sortOrder = 8),
                ScheduleItem(title = "Afternoon Prasadam & Rest", description = "Midday meal and brief recuperation", startTime = "13:00", endTime = "14:30", category = ScheduleCategory.REST.name, routineMode = mode.name, essential = false, sortOrder = 9),
                ScheduleItem(title = "Book Study & Afternoon Seva", description = "Prabhupada books & department service (${profile.readingTargetMinutes}m study)", startTime = "15:00", endTime = "17:30", category = ScheduleCategory.SEVA.name, routineMode = mode.name, essential = false, sortOrder = 10),
                ScheduleItem(title = "Sandhya Aarti & Evening Kirtan", description = "Gaura Aarti & Bhagavad-gita evening class", startTime = "18:30", endTime = "20:00", category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 11),
                ScheduleItem(title = "Finish Daily Duties", description = "Wrap up evening seva & hot milk prasadam", startTime = preWind, endTime = prepTomorrow, category = ScheduleCategory.REST.name, routineMode = mode.name, essential = false, sortOrder = 12),
                ScheduleItem(title = "Prepare Tomorrow's Schedule", description = "Review Sadhana card & set Brahma Muhurta alarm", startTime = prepTomorrow, endTime = sleep, category = ScheduleCategory.REST.name, routineMode = mode.name, essential = false, sortOrder = 13),
                ScheduleItem(title = "Rest & Lights Out", description = "Peaceful sleep for early morning Sadhana", startTime = sleep, endTime = wake, category = ScheduleCategory.REST.name, routineMode = mode.name, essential = true, sortOrder = 14)
            )

            RoutineMode.CONGREGATIONAL -> listOf(
                ScheduleItem(title = "Wake Up & Morning Bath", description = "Fresh start before dawn", startTime = wake, endTime = addMinutes(wake, 25), category = ScheduleCategory.HEALTH.name, routineMode = mode.name, essential = true, sortOrder = 1),
                ScheduleItem(
                    title = if (profile.attendOnlineMangalAarti) "Online Mangal Aarti & Tulasi Prayers" else "Morning Altar Prayers",
                    description = "Connect with Sri Mayapur or home altar prayers",
                    startTime = addMinutes(wake, 25),
                    endTime = addMinutes(wake, 55),
                    category = ScheduleCategory.SPIRITUAL.name,
                    routineMode = mode.name,
                    essential = true,
                    sortOrder = 2
                ),
                ScheduleItem(title = "Morning Japa (${profile.japaTargetRounds} Rounds)", description = "Peaceful chanting before household duties begin", startTime = addMinutes(wake, 55), endTime = addMinutes(wake, 165), category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 3),
                ScheduleItem(title = "Bhagavad Gita / Srimad Bhagavatam Reading", description = "${profile.readingTargetMinutes} min daily scriptural reading", startTime = "07:15", endTime = addMinutes("07:15", profile.readingTargetMinutes.toInt().coerceAtLeast(15)), category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 4),
                ScheduleItem(title = "Family Care & Prasadam Offering", description = "Prepare & offer morning meal, family responsibilities", startTime = "07:45", endTime = "09:00", category = ScheduleCategory.SEVA.name, routineMode = mode.name, essential = false, sortOrder = 5),
                ScheduleItem(title = "Work & Household Duties", description = profile.responsibilities.joinToString(", ").ifBlank { "Career, home & community duties" }, startTime = "09:00", endTime = "17:30", category = ScheduleCategory.WORK_STUDY.name, routineMode = mode.name, essential = false, sortOrder = 6),
                ScheduleItem(title = "Evening Sandhya Aarti & Family Kirtan", description = "Offer evening lamp and short kirtan at home", startTime = "18:45", endTime = "19:30", category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 7),
                ScheduleItem(title = "Hearing Devotional Lecture", description = "${profile.hearingTargetMinutes} min Prabhupada or senior Vaishnava class", startTime = "20:00", endTime = addMinutes("20:00", profile.hearingTargetMinutes.toInt().coerceAtLeast(20)), category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = false, sortOrder = 8),
                ScheduleItem(title = "Finish Evening Activities", description = "Put devices on night focus mode", startTime = preWind, endTime = prepTomorrow, category = ScheduleCategory.REST.name, routineMode = mode.name, essential = false, sortOrder = 9),
                ScheduleItem(title = "Prepare Tomorrow's Schedule", description = "Check Ekadashi / Vaishnava calendar & tomorrow's tasks", startTime = prepTomorrow, endTime = sleep, category = ScheduleCategory.REST.name, routineMode = mode.name, essential = false, sortOrder = 10),
                ScheduleItem(title = "Rest & Bedtime Focus", description = "Consistent sleep for tomorrow's Japa", startTime = sleep, endTime = wake, category = ScheduleCategory.REST.name, routineMode = mode.name, essential = true, sortOrder = 11)
            )

            RoutineMode.STUDENT_PRO -> listOf(
                ScheduleItem(title = "Brahma Muhurta Wake Up & Refresh", description = "Drink warm water, wash up & avoid checking phone", startTime = wake, endTime = addMinutes(wake, 20), category = ScheduleCategory.HEALTH.name, routineMode = mode.name, essential = true, sortOrder = 1),
                ScheduleItem(title = "Japa Meditation (${profile.japaTargetRounds} Rounds)", description = "Complete core chanting rounds during quiet morning hours", startTime = addMinutes(wake, 20), endTime = addMinutes(wake, 130), category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 2),
                ScheduleItem(title = "Devotional Reading & Mangal Aarti", description = "${profile.readingTargetMinutes} min Bhagavad-gita + brief morning prayers", startTime = "06:40", endTime = "07:15", category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 3),
                ScheduleItem(title = "Physical Exercise & Breakfast", description = "Yoga / walk / strength + sattvic breakfast", startTime = "07:15", endTime = "08:30", category = ScheduleCategory.HEALTH.name, routineMode = mode.name, essential = false, sortOrder = 4),
                ScheduleItem(title = "Deep Focus Study / Office Block 1", description = profile.responsibilities.firstOrNull() ?: "Primary academic or professional deep work (App Blocker ON)", startTime = "08:30", endTime = "12:30", category = ScheduleCategory.WORK_STUDY.name, routineMode = mode.name, essential = false, sortOrder = 5),
                ScheduleItem(title = "Lunch Prasadam & Midday Reset", description = "Mindful lunch + 15m rest", startTime = "12:30", endTime = "13:30", category = ScheduleCategory.HEALTH.name, routineMode = mode.name, essential = false, sortOrder = 6),
                ScheduleItem(title = "Afternoon Classes / Office Block 2", description = "Meetings, coursework & deliverables", startTime = "13:30", endTime = "17:30", category = ScheduleCategory.WORK_STUDY.name, routineMode = mode.name, essential = false, sortOrder = 7),
                ScheduleItem(title = "Evening Sandhya, Kirtan & Lecture", description = "Decompress with ${profile.hearingTargetMinutes}m devotional audio", startTime = "18:30", endTime = "19:30", category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 8),
                ScheduleItem(title = "Dinner & Personal Growth", description = "Light dinner, reading or reviewing notes", startTime = "19:30", endTime = preWind, category = ScheduleCategory.HEALTH.name, routineMode = mode.name, essential = false, sortOrder = 9),
                ScheduleItem(title = "Finish Activities & Prepare Tomorrow", description = "Wrap up tasks & lay out tomorrow's plan", startTime = preWind, endTime = sleep, category = ScheduleCategory.REST.name, routineMode = mode.name, essential = false, sortOrder = 10),
                ScheduleItem(title = "Bedtime & Night Focus Shield", description = "Restful sleep", startTime = sleep, endTime = wake, category = ScheduleCategory.REST.name, routineMode = mode.name, essential = true, sortOrder = 11)
            )
        }

        val withGayatri = if (profile.gayatriInitiated) {
            baseList + listOf(
                ScheduleItem(title = "Morning Gayatri Sandhya", description = "First Gayatri meditation", startTime = profile.gayatriMorningTime, endTime = addMinutes(profile.gayatriMorningTime, 15), category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 15),
                ScheduleItem(title = "Midday Gayatri Sandhya", description = "Noon Gayatri meditation", startTime = profile.gayatriAfternoonTime, endTime = addMinutes(profile.gayatriAfternoonTime, 15), category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 16),
                ScheduleItem(title = "Evening Gayatri Sandhya", description = "Sunset Gayatri meditation", startTime = profile.gayatriEveningTime, endTime = addMinutes(profile.gayatriEveningTime, 15), category = ScheduleCategory.SPIRITUAL.name, routineMode = mode.name, essential = true, sortOrder = 17)
            )
        } else baseList

        return withGayatri.sortedBy { it.startTime }
    }

    fun getFestivalModeSchedule(festivalName: String): List<ScheduleItem> {
        val lower = festivalName.lowercase()
        return when {
            "janmashtami" in lower -> listOf(
                ScheduleItem(title = "Janmashtami Morning Mangal Aarti & Bath", description = "Begin Sri Krishna Janmashtami nirjala/ekadashi-style fast with devotion", startTime = "04:30", endTime = "05:30", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 1),
                ScheduleItem(title = "Extra Japa & Krishna Book Reading", description = "Chant extra rounds and read Krishna's childhood pastimes", startTime = "05:30", endTime = "08:30", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 2),
                ScheduleItem(title = "Krishna Lila Katha & Bhajans", description = "Listen to Sri Krishna Janmashtami discourses & kirtans", startTime = "10:00", endTime = "12:00", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = false, sortOrder = 3),
                ScheduleItem(title = "Temple Decoration & Prasadam Seva", description = "Prepare midnight offering or assist at the local temple", startTime = "16:00", endTime = "19:30", category = ScheduleCategory.SEVA.name, routineMode = "FESTIVAL", essential = false, sortOrder = 4),
                ScheduleItem(title = "Maha-Abhisheka & Kirtan", description = "Evening abhisheka & ecstatic congregational chanting", startTime = "20:00", endTime = "23:45", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 5),
                ScheduleItem(title = "Midnight Maha-Aarti & Anukalpa Prasadam", description = "Celebrate Lord Sri Krishna's midnight appearance", startTime = "23:55", endTime = "00:45", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 6)
            )
            "radhastami" in lower -> listOf(
                ScheduleItem(title = "Radhastami Mangal Aarti & Tulasi Prayers", description = "Fast until noon in honor of Srimati Radharani's Appearance", startTime = "04:30", endTime = "05:15", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 1),
                ScheduleItem(title = "Extra Japa & Radhika Ashtakam", description = "Deep absorption in Holy Names & prayers to Srimati Radharani", startTime = "05:15", endTime = "08:00", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 2),
                ScheduleItem(title = "Radhastami Abhisheka & Katha", description = "Listen to glories of Srimati Radharani", startTime = "10:30", endTime = "12:00", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 3),
                ScheduleItem(title = "Noon Prasadam Feast", description = "Break half-day fast at midday after Pushpanjali", startTime = "12:15", endTime = "13:15", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = false, sortOrder = 4)
            )
            "gaura" in lower || "nityananda" in lower -> listOf(
                ScheduleItem(title = "Panchatattva Mangal Aarti", description = "Observe fast until moonrise / noon per festival observance", startTime = "04:30", endTime = "05:15", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 1),
                ScheduleItem(title = "Caitanya-caritamrita Reading & Japa", description = "Read Sri Chaitanya Mahaprabhu's pastimes & chant extra rounds", startTime = "05:15", endTime = "08:30", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 2),
                ScheduleItem(title = "Evening Abhisheka & Nagar Sankirtana", description = "Join temple evening kirtan & feast", startTime = "17:30", endTime = "20:00", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 3)
            )
            "kartik" in lower || "damodar" in lower -> listOf(
                ScheduleItem(title = "Kartik Brahma Muhurta Japa", description = "Chant extra rounds during the sacred month of Damodara", startTime = "04:30", endTime = "07:00", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 1),
                ScheduleItem(title = "Damodarashtakam & Ghee Lamp Offering", description = "Offer ghee lamp to Lord Damodara & recite Sri Damodarashtakam", startTime = "18:30", endTime = "19:15", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 2),
                ScheduleItem(title = "Nectar of Devotion / Krishna Book Reading", description = "Additional daily reading during Kartik vrata", startTime = "19:30", endTime = "20:15", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = false, sortOrder = 3)
            )
            else -> listOf(
                ScheduleItem(title = "Ekadashi Morning Japa (Extra Rounds)", description = "Increase chanting (24-64 rounds if possible) & abstain from grains/beans", startTime = "04:30", endTime = "07:30", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 1),
                ScheduleItem(title = "Ekadashi Mahatmya & Gita Reading", description = "Read glories of today's Ekadashi & extra Srimad Bhagavatam", startTime = "08:00", endTime = "09:00", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 2),
                ScheduleItem(title = "Simple Anukalpa Prasadam", description = "Light fruits, roots, or Ekadashi preparation without grains", startTime = "12:30", endTime = "13:15", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = false, sortOrder = 3),
                ScheduleItem(title = "Evening Kirtan & Hearing", description = "Focus evening hours on kirtan & Bhagavatam audio", startTime = "18:30", endTime = "20:00", category = ScheduleCategory.FESTIVAL.name, routineMode = "FESTIVAL", essential = true, sortOrder = 4)
            )
        }
    }

    fun addMinutes(hhmm: String, deltaMinutes: Int): String {
        val parts = hhmm.split(":")
        val h = parts.getOrNull(0)?.toIntOrNull() ?: 5
        val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
        val total = ((h * 60 + m + deltaMinutes) % 1440 + 1440) % 1440
        return String.format("%02d:%02d", total / 60, total % 60)
    }

    fun subtractMinutes(hhmm: String, deltaMinutes: Int): String = addMinutes(hhmm, -deltaMinutes)
}
