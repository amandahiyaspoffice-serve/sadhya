package com.example.data.model

enum class DevotionalMediaCategory(val label: String) {
    LIVE_TV("Mayapur TV"),
    MANGAL_AARTI("Mangal Aarti"),
    PRABHUPADA("Srila Prabhupada"),
    JAYAPATAKA_SWAMI("HH Jayapataka Swami"),
    GITA_CLASSES("Bhagavad Gita"),
    BHAGAVATAM("Srimad Bhagavatam"),
    KIRTANS("Kirtans & Bhajans"),
    SOUNDSCAPE("Offline Mantra")
}

data class DevotionalMediaItem(
    val id: String,
    val title: String,
    val speakerOrSource: String,
    val category: DevotionalMediaCategory,
    val durationLabel: String,
    val durationMinutes: Int,
    val streamUrl: String?, // Authorized external/open stream or portal URL
    val officialWebUrl: String,
    val isLiveStream: Boolean = false,
    val isBuiltInOfflineAudio: Boolean = false,
    val droneHz: Double = 130.81, // C3 sacred tanpura pitch
    val description: String
)

object DevotionalMediaCatalog {
    val items: List<DevotionalMediaItem> = listOf(
        DevotionalMediaItem(
            id = "mayapur_tv_live",
            title = "Mayapur TV — Sri Mayapur Chandrodaya Mandir Live",
            speakerOrSource = "Official ISKCON Mayapur Broadcast",
            category = DevotionalMediaCategory.LIVE_TV,
            durationLabel = "LIVE",
            durationMinutes = 30,
            streamUrl = "https://www.mayapur.tv/",
            officialWebUrl = "https://www.mayapur.tv/",
            isLiveStream = true,
            description = "Live Darshan, Mangal Aarti, Tulasi Aarti & Kirtan from Sri Dhama Mayapur. Note: third-party streams may display platform ads."
        ),
        DevotionalMediaItem(
            id = "offline_japa_tanpura",
            title = "Sacred Tanpura & Kartal Japa Drone (Offline Ad-Free)",
            speakerOrSource = "Built-in App Audio",
            category = DevotionalMediaCategory.SOUNDSCAPE,
            durationLabel = "Continuous",
            durationMinutes = 15,
            streamUrl = null,
            officialWebUrl = "https://vedabase.io/",
            isBuiltInOfflineAudio = true,
            droneHz = 130.81,
            description = "100% offline, ad-free warm Sa-Pa-Sa tanpura harmonic drone with gentle kartal pulse for attentive Japa & Gayatri."
        ),
        DevotionalMediaItem(
            id = "offline_kirtan_meditation",
            title = "Evening Sandhya Meditation Soundscape (Offline)",
            speakerOrSource = "Built-in App Audio",
            category = DevotionalMediaCategory.SOUNDSCAPE,
            durationLabel = "Continuous",
            durationMinutes = 20,
            streamUrl = null,
            officialWebUrl = "https://vedabase.io/",
            isBuiltInOfflineAudio = true,
            droneHz = 146.83,
            description = "Calm D-pitch devotional harmonic resonance for Bhagavad-gita reading & evening wind-down."
        ),
        DevotionalMediaItem(
            id = "mangal_aarti_samsara",
            title = "Sri Gurvashtakam — Mangal Aarti Prayers",
            speakerOrSource = "ISKCON Desire Tree Authorized Archive",
            category = DevotionalMediaCategory.MANGAL_AARTI,
            durationLabel = "14:20",
            durationMinutes = 14,
            streamUrl = "https://audio.iskcondesiretree.com/06_-_More/10_-_Songs_and_Bhajans/01_-_ISKCON_Morning_Program/01_-_Mangala_Arati_-_Samsara_Davanala_Lidhika.mp3",
            officialWebUrl = "https://audio.iskcondesiretree.com/",
            description = "Traditional morning Samsara Davanala Lidhika prayers sung during Mangal Aarti."
        ),
        DevotionalMediaItem(
            id = "prabhupada_bg_2_13",
            title = "Bhagavad-gita As It Is 2.13 — Understanding the Eternal Soul",
            speakerOrSource = "His Divine Grace A.C. Bhaktivedanta Swami Prabhupada",
            category = DevotionalMediaCategory.PRABHUPADA,
            durationLabel = "34:10",
            durationMinutes = 34,
            streamUrl = "https://prabhupadavani.org/transcriptions/",
            officialWebUrl = "https://prabhupadavani.org/",
            description = "Classic lecture by Srila Prabhupada on steady intelligence and spiritual identity."
        ),
        DevotionalMediaItem(
            id = "prabhupada_sb_1_2_6",
            title = "Srimad Bhagavatam 1.2.6 — The Supreme Occupation for Humanity",
            speakerOrSource = "His Divine Grace A.C. Bhaktivedanta Swami Prabhupada",
            category = DevotionalMediaCategory.PRABHUPADA,
            durationLabel = "41:00",
            durationMinutes = 41,
            streamUrl = "https://prabhupadavani.org/",
            officialWebUrl = "https://prabhupadavani.org/",
            description = "Authoritative Bhagavatam exposition on uninterrupted devotional service."
        ),
        DevotionalMediaItem(
            id = "jps_japa_class",
            title = "Deepening Attentive Japa & Morning Sadhana",
            speakerOrSource = "HH Jayapataka Swami Maharaj",
            category = DevotionalMediaCategory.JAYAPATAKA_SWAMI,
            durationLabel = "38:00",
            durationMinutes = 38,
            streamUrl = "https://www.jayapatakaswami.com/",
            officialWebUrl = "https://www.jayapatakaswami.com/",
            description = "Authorized discourse on cultivating enthusiasm and steadiness in daily chanting and seva."
        ),
        DevotionalMediaItem(
            id = "jps_gaura_katha",
            title = "Sri Navadvipa Dhama & Caitanya-caritamrita Class",
            speakerOrSource = "HH Jayapataka Swami Maharaj",
            category = DevotionalMediaCategory.JAYAPATAKA_SWAMI,
            durationLabel = "45:00",
            durationMinutes = 45,
            streamUrl = "https://www.jayapatakaswami.com/",
            officialWebUrl = "https://www.jayapatakaswami.com/",
            description = "Merciful pastimes of Sri Caitanya Mahaprabhu & Lord Nityananda in Mayapur."
        ),
        DevotionalMediaItem(
            id = "gita_overview_vedabase",
            title = "Bhagavad-gita As It Is — Official Text & Audio Study",
            speakerOrSource = "Bhaktivedanta Book Trust (Vedabase)",
            category = DevotionalMediaCategory.GITA_CLASSES,
            durationLabel = "Study",
            durationMinutes = 30,
            streamUrl = "https://vedabase.io/en/library/bg/",
            officialWebUrl = "https://vedabase.io/en/library/bg/",
            description = "Read & study Srila Prabhupada's authorized Bhagavad-gita As It Is directly."
        ),
        DevotionalMediaItem(
            id = "sb_vedabase",
            title = "Srimad Bhagavatam — Official Vedabase Archive",
            speakerOrSource = "Bhaktivedanta Book Trust (Vedabase)",
            category = DevotionalMediaCategory.BHAGAVATAM,
            durationLabel = "Study",
            durationMinutes = 30,
            streamUrl = "https://vedabase.io/en/library/sb/",
            officialWebUrl = "https://vedabase.io/en/library/sb/",
            description = "Authorized verse-by-verse Sanskrit, synonyms, translations, and purports."
        ),
        DevotionalMediaItem(
            id = "kirtan_radha_madhava",
            title = "Jaya Radha Madhava & Evening Tulasi Bhajan",
            speakerOrSource = "Mayapur & Vrindavan Temple Kirtan",
            category = DevotionalMediaCategory.KIRTANS,
            durationLabel = "18:00",
            durationMinutes = 18,
            streamUrl = "https://www.mayapur.tv/",
            officialWebUrl = "https://audio.iskcondesiretree.com/",
            description = "Soulful temple kirtan to uplift morning or evening meditation."
        )
    )
}
