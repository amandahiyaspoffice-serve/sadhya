package com.example.data.local

import android.content.Context
import com.example.data.model.DailyTask
import com.example.data.model.FocusLog
import com.example.data.model.RoutineMode
import com.example.data.model.RoutineTemplates
import com.example.data.model.SadhanaDailyLog
import com.example.data.model.ScheduleItem
import com.example.data.model.TaskPriority
import com.example.data.model.TaskRepeatFrequency
import com.example.data.model.TempleCommunity
import com.example.data.model.TemplePost
import com.example.data.model.TemplePostType
import com.example.data.model.UserProfile
import com.example.data.model.WakeUpMethod
import com.example.data.model.WakeUpStatus
import com.example.data.remote.SadhanaDataRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.UUID

class GuestLocalRepository private constructor(context: Context) : SadhanaDataRepository {

    companion object {
        const val GUEST_USER_ID = "guest_local_devotee"
        private const val PREF_NAME = "sadhya_guest_store"

        @Volatile
        private var instance: GuestLocalRepository? = null

        fun getInstance(context: Context): GuestLocalRepository {
            return instance ?: synchronized(this) {
                instance ?: GuestLocalRepository(context.applicationContext).also { instance = it }
            }
        }
    }

    private val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    private val _profileFlow = MutableStateFlow<UserProfile?>(null)
    private val _scheduleFlow = MutableStateFlow<List<ScheduleItem>>(emptyList())
    private val _tasksFlow = MutableStateFlow<List<DailyTask>>(emptyList())
    private val _logsFlow = MutableStateFlow<List<SadhanaDailyLog>>(emptyList())
    private val _focusLogsFlow = MutableStateFlow<List<FocusLog>>(emptyList())
    private val _templesFlow = MutableStateFlow<List<TempleCommunity>>(emptyList())
    private val _postsFlow = MutableStateFlow<List<TemplePost>>(emptyList())

    init {
        loadOrSeedAll()
    }

    private fun loadOrSeedAll() {
        val hasInitialized = prefs.getBoolean("initialized_v1", false)
        if (!hasInitialized) {
            seedStarterGuestData()
            return
        }
        _profileFlow.value = prefs.getString("profile", null)?.let(::decodeProfile) ?: defaultGuestProfile()
        _scheduleFlow.value = prefs.getString("schedule", null)?.let(::decodeScheduleList) ?: emptyList()
        _tasksFlow.value = prefs.getString("tasks", null)?.let(::decodeTaskList) ?: emptyList()
        _logsFlow.value = prefs.getString("logs", null)?.let(::decodeLogsList) ?: emptyList()
        _focusLogsFlow.value = prefs.getString("focus_logs", null)?.let(::decodeFocusList) ?: emptyList()
        _templesFlow.value = prefs.getString("temples", null)?.let(::decodeTemples) ?: defaultTemples()
        _postsFlow.value = prefs.getString("posts", null)?.let(::decodePosts) ?: defaultTemplePosts()
    }

    private fun defaultGuestProfile(): UserProfile = UserProfile(
        id = GUEST_USER_ID,
        userId = GUEST_USER_ID,
        displayName = "Guest Devotee",
        email = "",
        routineMode = RoutineMode.CONGREGATIONAL.name,
        wakeTime = "04:30",
        sleepTime = "22:00",
        japaTargetRounds = 16L,
        readingTargetMinutes = 30L,
        hearingTargetMinutes = 30L,
        attendOnlineMangalAarti = true,
        gayatriInitiated = false,
        responsibilities = listOf("Morning Sadhana", "Work & Family Seva"),
        followedTempleId = "temple_mayapur_demo",
        onboardingCompleted = true
    )

    private fun defaultTemples(): List<TempleCommunity> = listOf(
        TempleCommunity(
            id = "temple_mayapur_demo",
            name = "Sri Mayapur Chandrodaya Mandir",
            city = "Mayapur, West Bengal",
            tradition = "ISKCON",
            adminUid = "temple_admin_mayapur",
            adminName = "Mayapur Temple Office",
            mangalAartiTime = "04:30",
            tulasiAartiTime = "05:00",
            darshanTime = "07:15",
            bhagavatamClassTime = "08:00",
            sandhyaAartiTime = "18:30",
            description = "International Headquarters of ISKCON — daily live darshan, Srimad Bhagavatam classes, and festival broadcasts."
        ),
        TempleCommunity(
            id = "temple_vrindavan_demo",
            name = "Sri Sri Krishna Balaram Mandir",
            city = "Vrindavan, UP",
            tradition = "ISKCON",
            adminUid = "temple_admin_vrindavan",
            adminName = "Vrindavan Temple Office",
            mangalAartiTime = "04:10",
            tulasiAartiTime = "04:40",
            darshanTime = "07:15",
            bhagavatamClassTime = "08:00",
            sandhyaAartiTime = "18:30",
            description = "24-hour kirtan and Vrindavan temple schedule in Raman Reti."
        )
    )

    private fun defaultTemplePosts(): List<TemplePost> {
        val today = LocalDate.now().toString()
        return listOf(
            TemplePost(
                id = "post_seva_1",
                templeId = "temple_mayapur_demo",
                authorUid = "temple_admin_mayapur",
                authorName = "Mayapur Temple Office",
                postType = TemplePostType.SEVA.name,
                title = "Sunday Feast Flower Garland & Altar Seva",
                body = "Devotees needed for morning garland stringing and lamp preparation before Shringar Darshan.",
                eventDate = today,
                eventTime = "06:00",
                sevaSlotsTotal = 8L,
                volunteerUids = listOf("devotee_1", "devotee_2")
            ),
            TemplePost(
                id = "post_lect_1",
                templeId = "temple_mayapur_demo",
                authorUid = "temple_admin_mayapur",
                authorName = "Mayapur Temple Office",
                postType = TemplePostType.LECTURE.name,
                title = "Morning Srimad Bhagavatam Discourse",
                body = "Join morning Bhagavatam class at 08:00 AM IST or watch via Mayapur TV in the Sadhana tab.",
                eventDate = today,
                eventTime = "08:00",
                sevaSlotsTotal = 0L,
                volunteerUids = emptyList()
            ),
            TemplePost(
                id = "post_fest_1",
                templeId = "temple_vrindavan_demo",
                authorUid = "temple_admin_vrindavan",
                authorName = "Vrindavan Temple Office",
                postType = TemplePostType.FESTIVAL.name,
                title = "Upcoming Ekadashi Kirtan Mela",
                body = "Extended evening harinama sankirtan and anukalpa prasadam distribution.",
                eventDate = LocalDate.now().plusDays(3).toString(),
                eventTime = "17:30",
                sevaSlotsTotal = 0L,
                volunteerUids = emptyList()
            )
        )
    }

    private fun seedStarterGuestData() {
        val today = LocalDate.now()
        val profile = defaultGuestProfile()
        val schedule = RoutineTemplates.generateDefaultSchedule(profile).mapIndexed { idx, item ->
            item.copy(id = "guest_sched_${idx + 1}", userId = GUEST_USER_ID, sortOrder = (idx + 1).toLong())
        }
        val tasks = listOf(
            DailyTask(
                id = "guest_task_1",
                userId = GUEST_USER_ID,
                title = "Read Bhagavad-gita Chapter 2",
                description = "Reflect on karma-yoga verses and take brief notes.",
                dateIso = today.toString(),
                startTime = "07:15",
                endTime = "07:45",
                repeatFrequency = TaskRepeatFrequency.DAILY.name,
                priority = TaskPriority.HIGH.name,
                completed = false
            ),
            DailyTask(
                id = "guest_task_2",
                userId = GUEST_USER_ID,
                title = "Check upcoming Ekadashi & Parana window",
                description = "Review fasting preparation in the Calendar tab.",
                dateIso = today.toString(),
                startTime = "21:45",
                endTime = "",
                repeatFrequency = TaskRepeatFrequency.ONCE.name,
                priority = TaskPriority.MEDIUM.name,
                completed = false
            )
        )
        val logs = listOf(
            SadhanaDailyLog(
                id = today.toString(),
                userId = GUEST_USER_ID,
                dateIso = today.toString(),
                roundsChanted = 4L,
                targetRounds = 16L,
                readingMinutes = 15L,
                hearingMinutes = 10L,
                mangalAartiAttended = true,
                wakeUpStatus = WakeUpStatus.ON_TIME.name,
                wakeUpActualTime = "04:28",
                wakeUpMethod = WakeUpMethod.MANTRA_CHECKIN.name
            ),
            SadhanaDailyLog(
                id = today.minusDays(1).toString(),
                userId = GUEST_USER_ID,
                dateIso = today.minusDays(1).toString(),
                roundsChanted = 16L,
                targetRounds = 16L,
                readingMinutes = 30L,
                hearingMinutes = 35L,
                mangalAartiAttended = true,
                wakeUpStatus = WakeUpStatus.ON_TIME.name,
                wakeUpActualTime = "04:25"
            ),
            SadhanaDailyLog(
                id = today.minusDays(2).toString(),
                userId = GUEST_USER_ID,
                dateIso = today.minusDays(2).toString(),
                roundsChanted = 14L,
                targetRounds = 16L,
                readingMinutes = 25L,
                hearingMinutes = 20L,
                mangalAartiAttended = true,
                wakeUpStatus = WakeUpStatus.LATE.name,
                wakeUpActualTime = "05:05"
            ),
            SadhanaDailyLog(
                id = today.minusDays(3).toString(),
                userId = GUEST_USER_ID,
                dateIso = today.minusDays(3).toString(),
                roundsChanted = 16L,
                targetRounds = 16L,
                readingMinutes = 30L,
                hearingMinutes = 30L,
                mangalAartiAttended = true,
                wakeUpStatus = WakeUpStatus.ON_TIME.name,
                wakeUpActualTime = "04:30"
            )
        )
        val temples = defaultTemples()
        val posts = defaultTemplePosts()

        _profileFlow.value = profile
        _scheduleFlow.value = schedule
        _tasksFlow.value = tasks
        _logsFlow.value = logs
        _focusLogsFlow.value = emptyList()
        _templesFlow.value = temples
        _postsFlow.value = posts

        prefs.edit()
            .putBoolean("initialized_v1", true)
            .putString("profile", encodeProfile(profile))
            .putString("schedule", encodeScheduleList(schedule))
            .putString("tasks", encodeTaskList(tasks))
            .putString("logs", encodeLogsList(logs))
            .putString("focus_logs", "[]")
            .putString("temples", encodeTemples(temples))
            .putString("posts", encodePosts(posts))
            .apply()
    }

    override fun observeUserProfile(userId: String): Flow<UserProfile?> = _profileFlow

    override suspend fun ensureUserProfileExists(
        userId: String,
        displayName: String,
        email: String
    ): Result<UserProfile> {
        val current = _profileFlow.value ?: defaultGuestProfile().also {
            _profileFlow.value = it
            persistProfile(it)
        }
        return Result.success(current)
    }

    override suspend fun updateUserProfileFields(userId: String, updates: Map<String, Any>): Result<Unit> {
        var cur = _profileFlow.value ?: defaultGuestProfile()
        updates["displayName"]?.let { cur = cur.copy(displayName = it.toString()) }
        updates["routineMode"]?.let { cur = cur.copy(routineMode = it.toString()) }
        updates["wakeTime"]?.let { cur = cur.copy(wakeTime = it.toString()) }
        updates["sleepTime"]?.let { cur = cur.copy(sleepTime = it.toString()) }
        updates["japaTargetRounds"]?.let { cur = cur.copy(japaTargetRounds = (it as Number).toLong()) }
        updates["readingTargetMinutes"]?.let { cur = cur.copy(readingTargetMinutes = (it as Number).toLong()) }
        updates["hearingTargetMinutes"]?.let { cur = cur.copy(hearingTargetMinutes = (it as Number).toLong()) }
        updates["attendOnlineMangalAarti"]?.let { cur = cur.copy(attendOnlineMangalAarti = it as Boolean) }
        updates["gayatriInitiated"]?.let { cur = cur.copy(gayatriInitiated = it as Boolean) }
        updates["gayatriMorningTime"]?.let { cur = cur.copy(gayatriMorningTime = it.toString()) }
        updates["gayatriAfternoonTime"]?.let { cur = cur.copy(gayatriAfternoonTime = it.toString()) }
        updates["gayatriEveningTime"]?.let { cur = cur.copy(gayatriEveningTime = it.toString()) }
        @Suppress("UNCHECKED_CAST")
        (updates["responsibilities"] as? List<String>)?.let { cur = cur.copy(responsibilities = it) }
        @Suppress("UNCHECKED_CAST")
        (updates["distractingPackages"] as? List<String>)?.let { cur = cur.copy(distractingPackages = it) }
        updates["focusStrictness"]?.let { cur = cur.copy(focusStrictness = it.toString()) }
        updates["calendarTradition"]?.let { cur = cur.copy(calendarTradition = it.toString()) }
        updates["locationName"]?.let { cur = cur.copy(locationName = it.toString()) }
        updates["latitude"]?.let { cur = cur.copy(latitude = (it as Number).toDouble()) }
        updates["longitude"]?.let { cur = cur.copy(longitude = (it as Number).toDouble()) }
        updates["timezoneId"]?.let { cur = cur.copy(timezoneId = it.toString()) }
        updates["followedTempleId"]?.let { cur = cur.copy(followedTempleId = it.toString()) }
        updates["activeFestivalMode"]?.let { cur = cur.copy(activeFestivalMode = it.toString()) }
        updates["themeStyle"]?.let { cur = cur.copy(themeStyle = it.toString()) }
        updates["darkModePreference"]?.let { cur = cur.copy(darkModePreference = it.toString()) }
        updates["fontScaleLevel"]?.let { cur = cur.copy(fontScaleLevel = it.toString()) }
        updates["bedtimeModeEnabled"]?.let { cur = cur.copy(bedtimeModeEnabled = it as Boolean) }
        updates["onboardingCompleted"]?.let { cur = cur.copy(onboardingCompleted = it as Boolean) }
        _profileFlow.value = cur
        persistProfile(cur)
        return Result.success(Unit)
    }

    override fun observeScheduleItems(userId: String): Flow<List<ScheduleItem>> = _scheduleFlow

    override suspend fun seedScheduleForProfile(userId: String, profile: UserProfile): Result<Unit> {
        val items = RoutineTemplates.generateDefaultSchedule(profile)
        return replaceScheduleItems(userId, items, keepEssentialExisting = false)
    }

    override suspend fun replaceScheduleItems(
        userId: String,
        newItems: List<ScheduleItem>,
        keepEssentialExisting: Boolean
    ): Result<Unit> {
        val kept = if (keepEssentialExisting) _scheduleFlow.value.filter { it.essential } else emptyList()
        val mapped = newItems.mapIndexed { idx, item ->
            item.copy(
                id = "guest_sched_${UUID.randomUUID().toString().take(8)}",
                userId = GUEST_USER_ID,
                sortOrder = (idx + 1).toLong()
            )
        }
        val combined = (kept + mapped).sortedBy { it.startTime }
        _scheduleFlow.value = combined
        prefs.edit().putString("schedule", encodeScheduleList(combined)).apply()
        return Result.success(Unit)
    }

    override suspend fun addScheduleItem(userId: String, item: ScheduleItem): Result<Unit> {
        val newItem = item.copy(
            id = "guest_sched_${UUID.randomUUID().toString().take(8)}",
            userId = GUEST_USER_ID
        )
        val next = (_scheduleFlow.value + newItem).sortedBy { it.startTime }
        _scheduleFlow.value = next
        prefs.edit().putString("schedule", encodeScheduleList(next)).apply()
        return Result.success(Unit)
    }

    override suspend fun updateScheduleItem(userId: String, itemId: String, updates: Map<String, Any>): Result<Unit> {
        val next = _scheduleFlow.value.map { item ->
            if (item.id != itemId) item
            else {
                var u = item
                updates["completedToday"]?.let { u = u.copy(completedToday = it as Boolean) }
                updates["lastCompletedDate"]?.let { u = u.copy(lastCompletedDate = it.toString()) }
                updates["startTime"]?.let { u = u.copy(startTime = it.toString()) }
                updates["endTime"]?.let { u = u.copy(endTime = it.toString()) }
                u
            }
        }.sortedBy { it.startTime }
        _scheduleFlow.value = next
        prefs.edit().putString("schedule", encodeScheduleList(next)).apply()
        return Result.success(Unit)
    }

    override suspend fun deleteScheduleItem(userId: String, itemId: String): Result<Unit> {
        val next = _scheduleFlow.value.filterNot { it.id == itemId }
        _scheduleFlow.value = next
        prefs.edit().putString("schedule", encodeScheduleList(next)).apply()
        return Result.success(Unit)
    }

    override fun observeTasks(userId: String): Flow<List<DailyTask>> = _tasksFlow

    override suspend fun addTask(userId: String, task: DailyTask): Result<String> {
        val id = "guest_task_${UUID.randomUUID().toString().take(8)}"
        val saved = task.copy(id = id, userId = GUEST_USER_ID)
        val next = (_tasksFlow.value + saved).sortedBy { it.dateIso }
        _tasksFlow.value = next
        prefs.edit().putString("tasks", encodeTaskList(next)).apply()
        return Result.success(id)
    }

    override suspend fun updateTask(userId: String, taskId: String, updates: Map<String, Any>): Result<Unit> {
        val next = _tasksFlow.value.map { task ->
            if (task.id != taskId) task
            else {
                var u = task
                updates["completed"]?.let { u = u.copy(completed = it as Boolean) }
                u
            }
        }
        _tasksFlow.value = next
        prefs.edit().putString("tasks", encodeTaskList(next)).apply()
        return Result.success(Unit)
    }

    override suspend fun deleteTask(userId: String, taskId: String): Result<Unit> {
        val next = _tasksFlow.value.filterNot { it.id == taskId }
        _tasksFlow.value = next
        prefs.edit().putString("tasks", encodeTaskList(next)).apply()
        return Result.success(Unit)
    }

    override fun observeSadhanaLogs(userId: String): Flow<List<SadhanaDailyLog>> = _logsFlow

    override suspend fun upsertSadhanaLog(userId: String, dateIso: String, log: SadhanaDailyLog): Result<Unit> {
        val clean = log.copy(id = dateIso, userId = GUEST_USER_ID, dateIso = dateIso)
        val without = _logsFlow.value.filterNot { it.dateIso == dateIso }
        val next = (listOf(clean) + without).sortedByDescending { it.dateIso }.take(31)
        _logsFlow.value = next
        prefs.edit().putString("logs", encodeLogsList(next)).apply()
        return Result.success(Unit)
    }

    override fun observeFocusLogs(userId: String): Flow<List<FocusLog>> = _focusLogsFlow

    override suspend fun addFocusLog(userId: String, log: FocusLog): Result<Unit> {
        val saved = log.copy(id = "guest_focus_${UUID.randomUUID().toString().take(8)}", userId = GUEST_USER_ID)
        val next = (listOf(saved) + _focusLogsFlow.value).take(50)
        _focusLogsFlow.value = next
        prefs.edit().putString("focus_logs", encodeFocusList(next)).apply()
        return Result.success(Unit)
    }

    override fun observeTemples(userId: String): Flow<List<TempleCommunity>> = _templesFlow

    override fun observeTemplePosts(userId: String, templeId: String): Flow<List<TemplePost>> =
        _postsFlow.map { posts -> posts.filter { it.templeId == templeId } }

    override suspend fun createTemple(temple: TempleCommunity): Result<String> {
        val id = "guest_temple_${UUID.randomUUID().toString().take(8)}"
        val saved = temple.copy(id = id, adminUid = GUEST_USER_ID)
        val next = (_templesFlow.value + saved).sortedBy { it.name }
        _templesFlow.value = next
        prefs.edit().putString("temples", encodeTemples(next)).apply()
        return Result.success(id)
    }

    override suspend fun updateTempleTimings(templeId: String, updates: Map<String, Any>): Result<Unit> {
        val next = _templesFlow.value.map { temple ->
            if (temple.id != templeId) temple
            else temple.copy(
                mangalAartiTime = updates["mangalAartiTime"]?.toString() ?: temple.mangalAartiTime,
                sandhyaAartiTime = updates["sandhyaAartiTime"]?.toString() ?: temple.sandhyaAartiTime
            )
        }
        _templesFlow.value = next
        prefs.edit().putString("temples", encodeTemples(next)).apply()
        return Result.success(Unit)
    }

    override suspend fun createTemplePost(templeId: String, post: TemplePost): Result<Unit> {
        val saved = post.copy(
            id = "guest_post_${UUID.randomUUID().toString().take(8)}",
            templeId = templeId,
            authorUid = GUEST_USER_ID
        )
        val next = listOf(saved) + _postsFlow.value
        _postsFlow.value = next
        prefs.edit().putString("posts", encodePosts(next)).apply()
        return Result.success(Unit)
    }

    override suspend fun toggleSevaVolunteer(templeId: String, post: TemplePost): Result<Unit> {
        val next = _postsFlow.value.map { p ->
            if (p.id != post.id) p
            else {
                val updatedList = if (GUEST_USER_ID in p.volunteerUids) p.volunteerUids - GUEST_USER_ID
                else (p.volunteerUids + GUEST_USER_ID).take(50)
                p.copy(volunteerUids = updatedList)
            }
        }
        _postsFlow.value = next
        prefs.edit().putString("posts", encodePosts(next)).apply()
        return Result.success(Unit)
    }

    // --- JSON SERIALIZATION HELPERS ---
    private fun persistProfile(p: UserProfile) {
        prefs.edit().putString("profile", encodeProfile(p)).apply()
    }

    private fun encodeProfile(p: UserProfile): String = JSONObject().apply {
        put("userId", p.userId)
        put("displayName", p.displayName)
        put("routineMode", p.routineMode)
        put("wakeTime", p.wakeTime)
        put("sleepTime", p.sleepTime)
        put("japaTargetRounds", p.japaTargetRounds)
        put("readingTargetMinutes", p.readingTargetMinutes)
        put("hearingTargetMinutes", p.hearingTargetMinutes)
        put("attendOnlineMangalAarti", p.attendOnlineMangalAarti)
        put("gayatriInitiated", p.gayatriInitiated)
        put("gayatriMorningTime", p.gayatriMorningTime)
        put("gayatriAfternoonTime", p.gayatriAfternoonTime)
        put("gayatriEveningTime", p.gayatriEveningTime)
        put("responsibilities", JSONArray(p.responsibilities))
        put("distractingPackages", JSONArray(p.distractingPackages))
        put("focusStrictness", p.focusStrictness)
        put("calendarTradition", p.calendarTradition)
        put("locationName", p.locationName)
        put("latitude", p.latitude)
        put("longitude", p.longitude)
        put("timezoneId", p.timezoneId)
        put("followedTempleId", p.followedTempleId)
        put("activeFestivalMode", p.activeFestivalMode)
        put("themeStyle", p.themeStyle)
        put("darkModePreference", p.darkModePreference)
        put("fontScaleLevel", p.fontScaleLevel)
        put("bedtimeModeEnabled", p.bedtimeModeEnabled)
        put("onboardingCompleted", p.onboardingCompleted)
    }.toString()

    private fun decodeProfile(raw: String): UserProfile? = runCatching {
        val o = JSONObject(raw)
        UserProfile(
            id = GUEST_USER_ID,
            userId = GUEST_USER_ID,
            displayName = o.optString("displayName", "Guest Devotee"),
            routineMode = o.optString("routineMode", RoutineMode.CONGREGATIONAL.name),
            wakeTime = o.optString("wakeTime", "04:30"),
            sleepTime = o.optString("sleepTime", "22:00"),
            japaTargetRounds = o.optLong("japaTargetRounds", 16L),
            readingTargetMinutes = o.optLong("readingTargetMinutes", 30L),
            hearingTargetMinutes = o.optLong("hearingTargetMinutes", 30L),
            attendOnlineMangalAarti = o.optBoolean("attendOnlineMangalAarti", true),
            gayatriInitiated = o.optBoolean("gayatriInitiated", false),
            gayatriMorningTime = o.optString("gayatriMorningTime", "06:00"),
            gayatriAfternoonTime = o.optString("gayatriAfternoonTime", "12:15"),
            gayatriEveningTime = o.optString("gayatriEveningTime", "18:15"),
            responsibilities = o.optJSONArray("responsibilities")?.toStringList() ?: emptyList(),
            distractingPackages = o.optJSONArray("distractingPackages")?.toStringList() ?: emptyList(),
            focusStrictness = o.optString("focusStrictness", "BALANCED"),
            calendarTradition = o.optString("calendarTradition", "ISKCON_MAYAPUR"),
            locationName = o.optString("locationName", "Sri Mayapur, India"),
            latitude = o.optDouble("latitude", 23.4231),
            longitude = o.optDouble("longitude", 88.3880),
            timezoneId = o.optString("timezoneId", java.util.TimeZone.getDefault().id),
            followedTempleId = o.optString("followedTempleId", ""),
            activeFestivalMode = o.optString("activeFestivalMode", ""),
            themeStyle = o.optString("themeStyle", "IVORY_MAROON"),
            darkModePreference = o.optString("darkModePreference", "SYSTEM"),
            fontScaleLevel = o.optString("fontScaleLevel", "NORMAL"),
            bedtimeModeEnabled = o.optBoolean("bedtimeModeEnabled", true),
            onboardingCompleted = o.optBoolean("onboardingCompleted", true)
        )
    }.getOrNull()

    private fun encodeScheduleList(list: List<ScheduleItem>): String = JSONArray().apply {
        list.forEach { s ->
            put(JSONObject().apply {
                put("id", s.id)
                put("title", s.title)
                put("description", s.description)
                put("startTime", s.startTime)
                put("endTime", s.endTime)
                put("category", s.category)
                put("routineMode", s.routineMode)
                put("essential", s.essential)
                put("reminderEnabled", s.reminderEnabled)
                put("completedToday", s.completedToday)
                put("lastCompletedDate", s.lastCompletedDate)
                put("sortOrder", s.sortOrder)
            })
        }
    }.toString()

    private fun decodeScheduleList(raw: String): List<ScheduleItem> = runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ScheduleItem(
                id = o.optString("id"),
                userId = GUEST_USER_ID,
                title = o.optString("title"),
                description = o.optString("description"),
                startTime = o.optString("startTime", "05:00"),
                endTime = o.optString("endTime", "06:00"),
                category = o.optString("category", "SPIRITUAL"),
                routineMode = o.optString("routineMode", RoutineMode.CONGREGATIONAL.name),
                essential = o.optBoolean("essential", false),
                reminderEnabled = o.optBoolean("reminderEnabled", true),
                completedToday = o.optBoolean("completedToday", false),
                lastCompletedDate = o.optString("lastCompletedDate"),
                sortOrder = o.optLong("sortOrder", i.toLong())
            )
        }
    }.getOrElse { emptyList() }

    private fun encodeTaskList(list: List<DailyTask>): String = JSONArray().apply {
        list.forEach { t ->
            put(JSONObject().apply {
                put("id", t.id)
                put("title", t.title)
                put("description", t.description)
                put("dateIso", t.dateIso)
                put("startTime", t.startTime)
                put("endTime", t.endTime)
                put("repeatFrequency", t.repeatFrequency)
                put("reminderEnabled", t.reminderEnabled)
                put("priority", t.priority)
                put("completed", t.completed)
            })
        }
    }.toString()

    private fun decodeTaskList(raw: String): List<DailyTask> = runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            DailyTask(
                id = o.optString("id"),
                userId = GUEST_USER_ID,
                title = o.optString("title"),
                description = o.optString("description"),
                dateIso = o.optString("dateIso"),
                startTime = o.optString("startTime"),
                endTime = o.optString("endTime"),
                repeatFrequency = o.optString("repeatFrequency", "ONCE"),
                reminderEnabled = o.optBoolean("reminderEnabled", true),
                priority = o.optString("priority", "MEDIUM"),
                completed = o.optBoolean("completed", false)
            )
        }
    }.getOrElse { emptyList() }

    private fun encodeLogsList(list: List<SadhanaDailyLog>): String = JSONArray().apply {
        list.forEach { l ->
            put(JSONObject().apply {
                put("dateIso", l.dateIso)
                put("roundsChanted", l.roundsChanted)
                put("targetRounds", l.targetRounds)
                put("readingMinutes", l.readingMinutes)
                put("hearingMinutes", l.hearingMinutes)
                put("mangalAartiAttended", l.mangalAartiAttended)
                put("gayatriMorningDone", l.gayatriMorningDone)
                put("gayatriAfternoonDone", l.gayatriAfternoonDone)
                put("gayatriEveningDone", l.gayatriEveningDone)
                put("sevaMinutes", l.sevaMinutes)
                put("sevaNotes", l.sevaNotes)
                put("wakeUpStatus", l.wakeUpStatus)
                put("wakeUpActualTime", l.wakeUpActualTime)
                put("wakeUpMethod", l.wakeUpMethod)
                put("wakeUpReflection", l.wakeUpReflection)
                put("focusMinutes", l.focusMinutes)
                put("distractionsBlocked", l.distractionsBlocked)
            })
        }
    }.toString()

    private fun decodeLogsList(raw: String): List<SadhanaDailyLog> = runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val date = o.optString("dateIso")
            SadhanaDailyLog(
                id = date,
                userId = GUEST_USER_ID,
                dateIso = date,
                roundsChanted = o.optLong("roundsChanted", 0L),
                targetRounds = o.optLong("targetRounds", 16L),
                readingMinutes = o.optLong("readingMinutes", 0L),
                hearingMinutes = o.optLong("hearingMinutes", 0L),
                mangalAartiAttended = o.optBoolean("mangalAartiAttended", false),
                gayatriMorningDone = o.optBoolean("gayatriMorningDone", false),
                gayatriAfternoonDone = o.optBoolean("gayatriAfternoonDone", false),
                gayatriEveningDone = o.optBoolean("gayatriEveningDone", false),
                sevaMinutes = o.optLong("sevaMinutes", 0L),
                sevaNotes = o.optString("sevaNotes"),
                wakeUpStatus = o.optString("wakeUpStatus", "PENDING"),
                wakeUpActualTime = o.optString("wakeUpActualTime"),
                wakeUpMethod = o.optString("wakeUpMethod", "NONE"),
                wakeUpReflection = o.optString("wakeUpReflection"),
                focusMinutes = o.optLong("focusMinutes", 0L),
                distractionsBlocked = o.optLong("distractionsBlocked", 0L)
            )
        }
    }.getOrElse { emptyList() }

    private fun encodeFocusList(list: List<FocusLog>): String = JSONArray().apply {
        list.forEach { f ->
            put(JSONObject().apply {
                put("id", f.id)
                put("packageName", f.packageName)
                put("appName", f.appName)
                put("scheduledActivity", f.scheduledActivity)
                put("userReason", f.userReason)
                put("outcome", f.outcome)
                put("durationMinutes", f.durationMinutes)
                put("dateIso", f.dateIso)
            })
        }
    }.toString()

    private fun decodeFocusList(raw: String): List<FocusLog> = runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            FocusLog(
                id = o.optString("id"),
                userId = GUEST_USER_ID,
                packageName = o.optString("packageName"),
                appName = o.optString("appName"),
                scheduledActivity = o.optString("scheduledActivity"),
                userReason = o.optString("userReason"),
                outcome = o.optString("outcome", "RETURNED"),
                durationMinutes = o.optLong("durationMinutes", 0L),
                dateIso = o.optString("dateIso")
            )
        }
    }.getOrElse { emptyList() }

    private fun encodeTemples(list: List<TempleCommunity>): String = JSONArray().apply {
        list.forEach { t ->
            put(JSONObject().apply {
                put("id", t.id)
                put("name", t.name)
                put("city", t.city)
                put("tradition", t.tradition)
                put("adminUid", t.adminUid)
                put("adminName", t.adminName)
                put("mangalAartiTime", t.mangalAartiTime)
                put("tulasiAartiTime", t.tulasiAartiTime)
                put("darshanTime", t.darshanTime)
                put("bhagavatamClassTime", t.bhagavatamClassTime)
                put("sandhyaAartiTime", t.sandhyaAartiTime)
                put("description", t.description)
            })
        }
    }.toString()

    private fun decodeTemples(raw: String): List<TempleCommunity> = runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            TempleCommunity(
                id = o.optString("id"),
                name = o.optString("name"),
                city = o.optString("city"),
                tradition = o.optString("tradition", "ISKCON"),
                adminUid = o.optString("adminUid"),
                adminName = o.optString("adminName"),
                mangalAartiTime = o.optString("mangalAartiTime", "04:30"),
                tulasiAartiTime = o.optString("tulasiAartiTime", "05:00"),
                darshanTime = o.optString("darshanTime", "07:15"),
                bhagavatamClassTime = o.optString("bhagavatamClassTime", "08:00"),
                sandhyaAartiTime = o.optString("sandhyaAartiTime", "18:30"),
                description = o.optString("description")
            )
        }
    }.getOrElse { defaultTemples() }

    private fun encodePosts(list: List<TemplePost>): String = JSONArray().apply {
        list.forEach { p ->
            put(JSONObject().apply {
                put("id", p.id)
                put("templeId", p.templeId)
                put("authorUid", p.authorUid)
                put("authorName", p.authorName)
                put("postType", p.postType)
                put("title", p.title)
                put("body", p.body)
                put("eventDate", p.eventDate)
                put("eventTime", p.eventTime)
                put("sevaSlotsTotal", p.sevaSlotsTotal)
                put("volunteerUids", JSONArray(p.volunteerUids))
            })
        }
    }.toString()

    private fun decodePosts(raw: String): List<TemplePost> = runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            TemplePost(
                id = o.optString("id"),
                templeId = o.optString("templeId"),
                authorUid = o.optString("authorUid"),
                authorName = o.optString("authorName"),
                postType = o.optString("postType", "ANNOUNCEMENT"),
                title = o.optString("title"),
                body = o.optString("body"),
                eventDate = o.optString("eventDate"),
                eventTime = o.optString("eventTime"),
                sevaSlotsTotal = o.optLong("sevaSlotsTotal", 0L),
                volunteerUids = o.optJSONArray("volunteerUids")?.toStringList() ?: emptyList()
            )
        }
    }.getOrElse { defaultTemplePosts() }

    private fun JSONArray.toStringList(): List<String> =
        (0 until length()).mapNotNull { optString(it).takeIf { s -> s.isNotBlank() } }
}
