package com.example.data.remote

import android.util.Log
import com.example.data.model.DailyTask
import com.example.data.model.RoutineMode
import com.example.data.model.SadhanaDailyLog
import com.example.data.model.ScheduleCategory
import com.example.data.model.ScheduleItem
import com.example.data.model.TaskPriority
import com.example.data.model.TaskRepeatFrequency
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

class GeminiAssistantRepository {

    private companion object {
        const val TAG = "GeminiAssistant"
        const val MODEL_NAME = "gemini-3.8-flash"
        const val TIMEOUT_MS = 60_000L
    }

    private val scheduleSchema = Schema.obj(
        properties = mapOf(
            "summaryNote" to Schema.string(description = "Brief encouraging summary of the generated timetable"),
            "items" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "title" to Schema.string(description = "Activity title"),
                        "description" to Schema.string(description = "Short helpful description"),
                        "startTime" to Schema.string(description = "24-hour HH:mm start time e.g. 04:30"),
                        "endTime" to Schema.string(description = "24-hour HH:mm end time e.g. 05:00"),
                        "category" to Schema.enumeration(
                            values = listOf("SPIRITUAL", "SEVA", "WORK_STUDY", "HEALTH", "REST", "FESTIVAL"),
                            description = "Activity category"
                        ),
                        "essential" to Schema.boolean(description = "True if core spiritual commitment like Japa, Mangal Aarti, Gayatri, or rest")
                    )
                ),
                description = "Chronologically ordered daily schedule items"
            )
        )
    )

    private val taskSchema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string(description = "Concise task title"),
            "description" to Schema.string(description = "Optional task details"),
            "dateIso" to Schema.string(description = "Date in yyyy-MM-dd format"),
            "startTime" to Schema.string(description = "Optional HH:mm start time or empty string"),
            "endTime" to Schema.string(description = "Optional HH:mm end time or empty string"),
            "repeatFrequency" to Schema.enumeration(
                values = listOf("ONCE", "DAILY", "WEEKLY", "EKADASHI"),
                description = "Repeat cadence"
            ),
            "priority" to Schema.enumeration(
                values = listOf("LOW", "MEDIUM", "HIGH"),
                description = "Task priority"
            )
        )
    )

    private val scheduleModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = scheduleSchema
            },
            systemInstruction = content {
                text(
                    "You are a gentle, practical daily schedule planner for Vaishnava devotees. " +
                        "Respect spiritual commitments (wake-up, Mangal Aarti, Japa, Gayatri, reading, sleep) as essential=true " +
                        "and never omit or alter existing essential spiritual commitments unless the user explicitly asks to change them. " +
                        "Produce realistic, non-overlapping 24-hour HH:mm blocks."
                )
            }
        )
    }

    private val taskModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = taskSchema
            }
        )
    }

    private val coachModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            systemInstruction = content {
                text(
                    "You are a humble, encouraging, non-judgemental personal productivity and Sadhana routine assistant. " +
                        "Help devotees gently understand missed chanting targets, late wake-ups, incomplete reading, excessive screen time, " +
                        "and weekly routine adjustments. Do NOT pretend to be a spiritual guru or authority, and NEVER invent or fabricate " +
                        "scriptural quotes or Sanskrit verses. Keep suggestions practical, warm, and actionable."
                )
            }
        )
    }

    suspend fun generateScheduleFromPrompt(
        userPrompt: String,
        profile: UserProfile,
        existingEssentials: List<ScheduleItem>
    ): Result<Pair<String, List<ScheduleItem>>> {
        return try {
            val essentialsSummary = if (existingEssentials.isEmpty()) {
                "None specified yet."
            } else {
                existingEssentials.joinToString("\n") {
                    "- ${it.startTime}-${it.endTime}: ${it.title} (essential=${it.essential})"
                }
            }
            val fullPrompt = """
                User request: "$userPrompt"
                
                Profile context:
                - Mode: ${profile.routineMode}
                - Preferred wake: ${profile.wakeTime}, sleep: ${profile.sleepTime}
                - Daily Japa target: ${profile.japaTargetRounds} rounds
                - Reading target: ${profile.readingTargetMinutes} min, Hearing: ${profile.hearingTargetMinutes} min
                - Gayatri initiated: ${profile.gayatriInitiated}
                
                Existing essential spiritual commitments to preserve unless explicitly asked to change:
                $essentialsSummary
                
                Generate a balanced, realistic full-day timetable in JSON.
            """.trimIndent()

            val response = withTimeout(TIMEOUT_MS) {
                scheduleModel.generateContent(fullPrompt)
            }
            val jsonStr = response.text ?: throw IllegalStateException("Gemini returned an empty schedule.")
            val json = JSONObject(jsonStr)
            val note = json.optString("summaryNote", "Balanced schedule prepared.")
            val arr = json.getJSONArray("items")
            val items = (0 until arr.length()).map { idx ->
                val obj = arr.getJSONObject(idx)
                val catStr = obj.optString("category", ScheduleCategory.SPIRITUAL.name)
                ScheduleItem(
                    title = obj.getString("title").take(120),
                    description = obj.optString("description", "").take(500),
                    startTime = normalizeTime(obj.optString("startTime", "05:00")),
                    endTime = normalizeTime(obj.optString("endTime", "06:00")),
                    category = catStr,
                    routineMode = profile.routineMode,
                    essential = obj.optBoolean("essential", false),
                    reminderEnabled = true,
                    completedToday = false,
                    sortOrder = (idx + 1).toLong()
                )
            }.sortedBy { it.startTime }
            Result.success(note to items)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Schedule generation timed out", e)
            Result.failure(Exception("Gemini request timed out after 60s. Your offline schedule templates remain available."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Schedule generation failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Unable to generate schedule right now."))
        }
    }

    suspend fun parseNaturalLanguageTask(
        userPrompt: String,
        todayIso: String
    ): Result<DailyTask> {
        return try {
            val prompt = """
                Today's date is $todayIso.
                Convert this request into a single task JSON object:
                "$userPrompt"
            """.trimIndent()
            val response = withTimeout(TIMEOUT_MS) {
                taskModel.generateContent(prompt)
            }
            val jsonStr = response.text ?: throw IllegalStateException("Gemini returned an empty task.")
            val obj = JSONObject(jsonStr)
            val task = DailyTask(
                title = obj.getString("title").take(140),
                description = obj.optString("description", "").take(600),
                dateIso = obj.optString("dateIso", todayIso).ifBlank { todayIso },
                startTime = obj.optString("startTime", "").take(8),
                endTime = obj.optString("endTime", "").take(8),
                repeatFrequency = obj.optString("repeatFrequency", TaskRepeatFrequency.ONCE.name),
                reminderEnabled = true,
                priority = obj.optString("priority", TaskPriority.MEDIUM.name),
                completed = false
            )
            Result.success(task)
        } catch (e: TimeoutCancellationException) {
            Result.failure(Exception("Task parsing timed out. You can still add tasks manually below."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Task parsing failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Failed to parse task."))
        }
    }

    fun streamAccountabilityReply(
        userMessage: String,
        historyMessages: List<Pair<String, String>>,
        profile: UserProfile,
        recentLogs: List<SadhanaDailyLog>
    ): Flow<String> = flow {
        val avgRounds = if (recentLogs.isEmpty()) 0 else recentLogs.map { it.roundsChanted }.average().toInt()
        val onTimeWakes = recentLogs.count { it.wakeUpStatus == "ON_TIME" }
        val totalReading = recentLogs.sumOf { it.readingMinutes }
        val totalBlocked = recentLogs.sumOf { it.distractionsBlocked }

        val contextBlock = """
            [User Sadhana Context - last ${recentLogs.size} logged days]
            Mode: ${profile.routineMode}, Wake target: ${profile.wakeTime}, Sleep target: ${profile.sleepTime}
            Daily target: ${profile.japaTargetRounds} rounds, ${profile.readingTargetMinutes}m reading, ${profile.hearingTargetMinutes}m hearing
            Recent average rounds/day: $avgRounds
            On-time wake-ups: $onTimeWakes / ${recentLogs.size}
            Total reading minutes logged recently: $totalReading
            Distractions blocked: $totalBlocked
        """.trimIndent()

        val history: List<Content> = historyMessages.takeLast(8).map { (role, text) ->
            content(role) { text(text) }
        }

        val chat = coachModel.startChat(history = history)
        val prompt = "$contextBlock\n\nDevotee says: $userMessage"
        val accumulated = StringBuilder()
        withTimeout(TIMEOUT_MS) {
            chat.sendMessageStream(prompt).collect { chunk ->
                val part = chunk.text.orEmpty()
                if (part.isNotEmpty()) {
                    accumulated.append(part)
                    emit(accumulated.toString())
                }
            }
        }
        if (accumulated.isBlank()) {
            throw IllegalStateException("Gemini returned an empty response.")
        }
    }

    suspend fun analyzeWakeUpMiss(
        profile: UserProfile,
        actualTime: String,
        userNote: String
    ): Result<String> {
        return try {
            val prompt = """
                The devotee aimed to wake up at ${profile.wakeTime} (bedtime target ${profile.sleepTime}) but checked in at $actualTime.
                Their note: "${userNote.ifBlank { "No reason shared" }}"
                Give 3 concise, encouraging, practical suggestions for tonight's wind-down and tomorrow's Brahma Muhurta wake-up.
            """.trimIndent()
            val response = withTimeout(TIMEOUT_MS) {
                coachModel.generateContent(prompt)
            }
            val text = response.text ?: throw IllegalStateException("Empty reflection response.")
            Result.success(text)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Wake-up reflection failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Unable to connect to Gemini right now."))
        }
    }

    private fun normalizeTime(raw: String): String {
        val clean = raw.trim()
        val match = Regex("""(\d{1,2}):(\d{2})""").find(clean)
        return if (match != null) {
            val h = match.groupValues[1].toIntOrNull()?.coerceIn(0, 23) ?: 5
            val m = match.groupValues[2].toIntOrNull()?.coerceIn(0, 59) ?: 0
            String.format("%02d:%02d", h, m)
        } else "06:00"
    }
}
