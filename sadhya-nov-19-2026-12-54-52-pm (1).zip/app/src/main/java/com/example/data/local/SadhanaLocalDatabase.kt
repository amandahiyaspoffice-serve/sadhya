package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PrivateCheckInEntity::class,
        FocusRuleEntity::class,
        ImportedCalendarEventEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SadhanaLocalDatabase : RoomDatabase() {
    abstract fun sadhanaDao(): SadhanaDao

    companion object {
        @Volatile
        private var instance: SadhanaLocalDatabase? = null

        fun getInstance(context: Context): SadhanaLocalDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    SadhanaLocalDatabase::class.java,
                    "sadhana_local.db"
                ).build().also { instance = it }
            }
        }
    }
}
