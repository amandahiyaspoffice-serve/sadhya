package com.example.media

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.util.Log
import com.example.data.model.DevotionalMediaItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

data class AudioPlaybackState(
    val activeItem: DevotionalMediaItem? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val elapsedSeconds: Int = 0,
    val errorMessage: String? = null
)

class DevotionalAudioPlayer {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var mediaPlayer: MediaPlayer? = null
    private var synthJob: Job? = null
    private var timerJob: Job? = null

    private val _state = MutableStateFlow(AudioPlaybackState())
    val state: StateFlow<AudioPlaybackState> = _state.asStateFlow()

    fun playItem(item: DevotionalMediaItem, onFallbackOpenExternal: (String) -> Unit) {
        stopInternal()
        _state.value = AudioPlaybackState(
            activeItem = item,
            isPlaying = false,
            isBuffering = !item.isBuiltInOfflineAudio,
            elapsedSeconds = 0,
            errorMessage = null
        )

        if (item.isBuiltInOfflineAudio) {
            startOfflineDrone(item.droneHz)
            _state.value = _state.value.copy(isPlaying = true, isBuffering = false)
            startTimer()
            return
        }

        val url = item.streamUrl
        if (url.isNullOrBlank() || (!url.endsWith(".mp3", true) && !url.endsWith(".m3u8", true))) {
            // Official web broadcast / Vedabase portal -> open cleanly in external viewer
            _state.value = AudioPlaybackState(activeItem = item, isPlaying = false, isBuffering = false)
            onFallbackOpenExternal(item.officialWebUrl)
            return
        }

        try {
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                setOnPreparedListener { player ->
                    player.start()
                    _state.value = _state.value.copy(isPlaying = true, isBuffering = false)
                    startTimer()
                }
                setOnCompletionListener {
                    stop()
                }
                setOnErrorListener { _, what, extra ->
                    Log.w("DevotionalAudio", "Stream playback error ($what/$extra), opening official portal")
                    _state.value = _state.value.copy(
                        isPlaying = false,
                        isBuffering = false,
                        errorMessage = "Stream unavailable directly — opened official source."
                    )
                    onFallbackOpenExternal(item.officialWebUrl)
                    true
                }
                prepareAsync()
            }
            mediaPlayer = mp
        } catch (e: Exception) {
            Log.e("DevotionalAudio", "Failed to start MediaPlayer", e)
            _state.value = _state.value.copy(
                isPlaying = false,
                isBuffering = false,
                errorMessage = "Opened official devotional source in browser."
            )
            onFallbackOpenExternal(item.officialWebUrl)
        }
    }

    fun togglePlayPause() {
        val current = _state.value
        val item = current.activeItem ?: return
        if (item.isBuiltInOfflineAudio) {
            if (current.isPlaying) {
                synthJob?.cancel()
                timerJob?.cancel()
                _state.value = current.copy(isPlaying = false)
            } else {
                startOfflineDrone(item.droneHz)
                _state.value = current.copy(isPlaying = true)
                startTimer()
            }
        } else {
            val mp = mediaPlayer ?: return
            if (mp.isPlaying) {
                mp.pause()
                timerJob?.cancel()
                _state.value = current.copy(isPlaying = false)
            } else {
                mp.start()
                _state.value = current.copy(isPlaying = true)
                startTimer()
            }
        }
    }

    fun stop() {
        stopInternal()
        _state.value = AudioPlaybackState()
    }

    private fun stopInternal() {
        timerJob?.cancel()
        synthJob?.cancel()
        runCatching {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        }
        mediaPlayer = null
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = scope.launch {
            while (isActive) {
                delay(1000L)
                _state.value = _state.value.copy(elapsedSeconds = _state.value.elapsedSeconds + 1)
            }
        }
    }

    private fun startOfflineDrone(baseHz: Double) {
        synthJob?.cancel()
        synthJob = scope.launch {
            val sampleRate = 22050
            val bufSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(2048)

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            val buffer = ShortArray(bufSize / 2)
            var phase1 = 0.0
            var phase2 = 0.0
            var phase3 = 0.0
            var lfo = 0.0
            val paHz = baseHz * 1.5
            val upperSaHz = baseHz * 2.0

            runCatching {
                track.play()
                while (isActive) {
                    for (i in buffer.indices) {
                        val env = 0.72 + 0.28 * sin(lfo)
                        val wave = (
                            0.50 * sin(phase1) +
                                0.30 * sin(phase2) +
                                0.20 * sin(phase3)
                            ) * env
                        buffer[i] = (wave * 5500.0).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                        phase1 += 2.0 * PI * baseHz / sampleRate
                        phase2 += 2.0 * PI * paHz / sampleRate
                        phase3 += 2.0 * PI * upperSaHz / sampleRate
                        lfo += 2.0 * PI * 0.25 / sampleRate
                        if (phase1 > 2.0 * PI) phase1 -= 2.0 * PI
                        if (phase2 > 2.0 * PI) phase2 -= 2.0 * PI
                        if (phase3 > 2.0 * PI) phase3 -= 2.0 * PI
                        if (lfo > 2.0 * PI) lfo -= 2.0 * PI
                    }
                    track.write(buffer, 0, buffer.size)
                }
            }
            runCatching {
                track.stop()
                track.release()
            }
        }
    }
}
