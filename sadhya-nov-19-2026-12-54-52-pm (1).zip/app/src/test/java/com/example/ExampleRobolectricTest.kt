package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.FocusRuleEntity
import com.example.data.local.GuestLocalRepository
import com.example.data.local.SadhanaLocalDatabase
import com.example.data.model.DailyTask
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app identity and firestore database config exist`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        val dbId = context.getString(R.string.firestore_database_id)
        assertEquals("Sadhya", appName)
        assertTrue(dbId.isNotBlank())
    }

    @Test
    fun `room database persists local focus rules`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, SadhanaLocalDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.sadhanaDao()
        dao.upsertFocusRule(FocusRuleEntity("com.instagram.android", "Instagram", true, true))
        val blocked = dao.getBlockedFocusRulesSync()
        assertEquals(1, blocked.size)
        assertEquals("Instagram", blocked.first().appName)
        db.close()
    }

    @Test
    fun `guest local repository provides full offline feature access`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val guestRepo = GuestLocalRepository.getInstance(context)
        val profile = guestRepo.ensureUserProfileExists(GuestLocalRepository.GUEST_USER_ID, "Guest", "").getOrThrow()
        assertTrue(profile.onboardingCompleted)

        val schedule = guestRepo.observeScheduleItems(GuestLocalRepository.GUEST_USER_ID).first()
        assertTrue(schedule.isNotEmpty())

        val temples = guestRepo.observeTemples(GuestLocalRepository.GUEST_USER_ID).first()
        assertTrue(temples.isNotEmpty())

        val taskRes = guestRepo.addTask(
            GuestLocalRepository.GUEST_USER_ID,
            DailyTask(title = "Guest Seva Task", dateIso = "2026-11-18")
        )
        assertTrue(taskRes.isSuccess)
    }
}
