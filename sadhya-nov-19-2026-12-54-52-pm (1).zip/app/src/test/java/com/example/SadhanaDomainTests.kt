package com.example

import com.example.calendar.IcsCalendarParser
import com.example.calendar.VaishnavaCalendarEngine
import com.example.data.model.CalendarTradition
import com.example.data.model.RoutineMode
import com.example.data.model.RoutineTemplates
import com.example.data.model.ThemeStyle
import com.example.data.model.UserProfile
import com.example.data.model.safeEnumValueOf
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SadhanaDomainTests {

    @Test
    fun `vaishnava calendar computes ekadashis and parana windows accurately`() {
        val mayapur = VaishnavaCalendarEngine.cityPresets.first { it.name.contains("Mayapur") }
        val novDays = VaishnavaCalendarEngine.computeMonth(
            year = 2026,
            month = 11,
            latitude = mayapur.latitude,
            longitude = mayapur.longitude,
            timezoneId = mayapur.timezoneId,
            tradition = CalendarTradition.ISKCON_MAYAPUR
        )
        assertEquals(30, novDays.size)

        val ekadashis = novDays.filter { it.isEkadashiFast }
        assertTrue("Expected at least 2 Ekadashi fast days in Nov 2026", ekadashis.size >= 2)
        ekadashis.forEach { day ->
            assertFalse(day.ekadashiName.isNullOrBlank())
        }

        val paranaDays = novDays.filter { it.isParanaDay }
        assertTrue("Expected Parana windows after Ekadashis", paranaDays.isNotEmpty())
        paranaDays.forEach { day ->
            assertNotNull(day.paranaWindow)
            assertTrue(day.paranaWindow!!.contains("–"))
        }
    }

    @Test
    fun `vaishnava calendar adjusts sunrise for distant timezones`() {
        val london = VaishnavaCalendarEngine.cityPresets.first { it.name.contains("London") }
        val ny = VaishnavaCalendarEngine.cityPresets.first { it.name.contains("New York") }

        val londonNov = VaishnavaCalendarEngine.computeMonth(
            2026, 11, london.latitude, london.longitude, london.timezoneId, CalendarTradition.ISKCON_MAYAPUR
        )
        val nyNov = VaishnavaCalendarEngine.computeMonth(
            2026, 11, ny.latitude, ny.longitude, ny.timezoneId, CalendarTradition.ISKCON_MAYAPUR
        )
        assertEquals(30, londonNov.size)
        assertEquals(30, nyNov.size)
        // Sunrise in London in November (~07:00+) vs New York (~06:30+)
        assertTrue(londonNov.first().sunriseTime != nyNov.first().sunriseTime)
    }

    @Test
    fun `ics calendar parser reads folded events and parana info`() {
        val sampleIcs = """
            BEGIN:VCALENDAR
            VERSION:2.0
            BEGIN:VEVENT
            DTSTART;VALUE=DATE:20261120
            SUMMARY:Utthana Ekadashi
            DESCRIPTION:Fasting from grains and beans.
             Parana 06:15 - 09:45 next day.
            END:VEVENT
            END:VCALENDAR
        """.trimIndent()

        val events = IcsCalendarParser.parseIcsStream(sampleIcs, "GCal Export")
        assertEquals(1, events.size)
        assertEquals("2026-11-20", events.first().dateIso)
        assertEquals("Utthana Ekadashi", events.first().title)
        assertTrue(events.first().paranaInfo.contains("Parana", ignoreCase = true))
    }

    @Test
    fun `routine templates and time arithmetic cover all modes and festivals`() {
        RoutineMode.entries.forEach { mode ->
            val profile = UserProfile(routineMode = mode.name, gayatriInitiated = true)
            val items = RoutineTemplates.generateDefaultSchedule(profile)
            assertTrue("Expected schedule items for $mode", items.size >= 6)
            assertTrue(items.any { item -> item.essential })
        }

        val janmashtami = RoutineTemplates.getFestivalModeSchedule("Sri Krishna Janmashtami")
        assertTrue(janmashtami.any { it.title.contains("Abhisheka", ignoreCase = true) })

        assertEquals("21:30", RoutineTemplates.subtractMinutes("22:00", 30))
        assertEquals("23:45", RoutineTemplates.subtractMinutes("00:15", 30))
        assertEquals("05:15", RoutineTemplates.addMinutes("04:30", 45))
    }

    @Test
    fun `safe enum fallback handles unknown firestore strings`() {
        val theme = safeEnumValueOf("UNKNOWN_THEME", ThemeStyle.IVORY_MAROON)
        assertEquals(ThemeStyle.IVORY_MAROON, theme)
    }
}
